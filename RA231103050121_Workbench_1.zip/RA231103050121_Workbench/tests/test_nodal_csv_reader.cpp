#include "core/io/nodal_csv_reader.hpp"
#include "core/io/text_utils.hpp"
#include "test_framework.hpp"

using wb::io::InputError;

namespace {
wb::io::NodalTemperatureField load(const char* name) {
    return wb::io::readNodalTemperatureCsv(wbtest::findPath(std::string("tests/data/csv/") + name));
}
}  // namespace

TEST_CASE(csv_valid_small_parses) {
    const auto f = load("valid_small.csv");
    CHECK(f.size() == 4);
    CHECK(f.nodeIds[2] == 3);
    CHECK_NEAR(f.xyz[3 * 2 + 1], 0.01, 0.0);
    CHECK_NEAR(f.temperature[2], 30.25, 0.0);
    CHECK_NEAR(f.minTemperature, 20.5, 0.0);
    CHECK_NEAR(f.maxTemperature, 30.25, 0.0);
    CHECK(f.declaredSynthetic);
    CHECK(f.comments.size() == 1);
}

TEST_CASE(csv_bom_crlf_and_header_case_accepted) {
    const auto f = load("bom_crlf_mixed_case.csv");
    CHECK(f.size() == 2);
    CHECK_NEAR(f.xyz[4], 2e-3, 1e-15);
}

TEST_CASE(csv_example_dataset_parses) {
    const auto f = wb::io::readNodalTemperatureCsv(wbtest::findPath("data/results/synthetic_plate_temperatures.csv"));
    CHECK(f.size() == 21 * 11 * 3);
    CHECK(f.declaredSynthetic);
    CHECK(f.maxTemperature > f.minTemperature);
}

TEST_CASE(csv_empty_inputs_are_explained) {
    CHECK_THROWS_WITH(load("empty.csv"), InputError, "empty (0 bytes)");
    CHECK_THROWS_WITH(load("comments_only.csv"), InputError, "no header or data");
    CHECK_THROWS_WITH(load("header_only.csv"), InputError, "no data rows");
}

TEST_CASE(csv_header_problems) {
    CHECK_THROWS_WITH(load("missing_column.csv"), InputError, "missing column(s): z_m");
    CHECK_THROWS_WITH(load("no_header.csv"), InputError, "looks like data");
    const auto f = load("extra_column.csv");
    CHECK(f.size() == 2);
    CHECK(f.warnings.size() == 1);
    CHECK(f.warnings[0].find("extra column") != std::string::npos);
}

TEST_CASE(csv_non_finite_and_physical_checks) {
    CHECK_THROWS_WITH(load("nan_temperature.csv"), InputError, "non-finite");
    CHECK_THROWS_WITH(load("inf_coordinate.csv"), InputError, "non-finite");
    CHECK_THROWS_WITH(load("below_absolute_zero.csv"), InputError, "below absolute zero");
}

TEST_CASE(csv_row_problems_report_line) {
    try {
        load("duplicate_node_id.csv");
        WB_FAIL("expected an error");
    } catch (const InputError& e) {
        CHECK(e.line() == 4);
        CHECK(std::string(e.what()).find("first seen on line 2") != std::string::npos);
    }
    CHECK_THROWS_WITH(load("wrong_field_count.csv"), InputError, "expected 5 values but found 4");
    CHECK_THROWS_WITH(load("bad_node_id.csv"), InputError, "not an integer");
    CHECK_THROWS_WITH(load("zero_node_id.csv"), InputError, "positive integer");
}

TEST_CASE(csv_node_limit_enforced) {
    wb::io::NodalCsvLimits limits;
    limits.maxNodes = 3;
    CHECK_THROWS_WITH(wb::io::readNodalTemperatureCsv(wbtest::findPath("tests/data/csv/valid_small.csv"), limits),
                      InputError, "tested limit");
}
