#include "test_framework.hpp"

#include <chrono>
#include <cstring>
#include <iostream>

namespace wbtest {

std::vector<TestCase>& registry() {
    static std::vector<TestCase> tests;
    return tests;
}

std::filesystem::path findPath(const std::string& relative) {
    for (const char* prefix : {"", "../", "../../", "../../../"}) {
        const std::filesystem::path candidate = std::filesystem::path(prefix) / relative;
        if (std::filesystem::exists(candidate)) return candidate;
    }
    throw std::runtime_error("Test file not found: " + relative + " (run from the project root)");
}

}  // namespace wbtest

int main(int argc, char** argv) {
    const char* filter = argc > 1 ? argv[1] : nullptr;
    int passed = 0, failed = 0;
    const auto start = std::chrono::steady_clock::now();
    for (const auto& test : wbtest::registry()) {
        if (filter && std::strstr(test.name, filter) == nullptr) continue;
        try {
            test.fn();
            ++passed;
            std::cout << "[ PASS ] " << test.name << "\n";
        } catch (const std::exception& e) {
            ++failed;
            std::cout << "[ FAIL ] " << test.name << "\n         " << e.what() << "\n";
        }
    }
    const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    std::cout << "\n" << passed << " passed, " << failed << " failed (" << s << " s)\n";
    return failed == 0 ? 0 : 1;
}
