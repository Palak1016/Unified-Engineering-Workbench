#pragma once

// Small self-contained test harness (no external framework needed).

#include <cmath>
#include <filesystem>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace wbtest {

struct TestCase {
    const char* name;
    void (*fn)();
};

std::vector<TestCase>& registry();

struct Registrar {
    Registrar(const char* name, void (*fn)()) { registry().push_back({name, fn}); }
};

struct Failure : std::runtime_error {
    using std::runtime_error::runtime_error;
};

// Finds a file under tests/data or data/ whether the tests run from the
// project root (CTest) or from a build folder.
std::filesystem::path findPath(const std::string& relative);

}  // namespace wbtest

#define WB_CONCAT_INNER(a, b) a##b
#define WB_CONCAT(a, b) WB_CONCAT_INNER(a, b)

#define TEST_CASE(name)                                                   \
    static void name();                                                   \
    static ::wbtest::Registrar WB_CONCAT(registrar_, name)(#name, &name); \
    static void name()

#define WB_FAIL(msg)                                                               \
    do {                                                                           \
        std::ostringstream wb_os;                                                  \
        wb_os << __FILE__ << ":" << __LINE__ << ": " << msg;                       \
        throw ::wbtest::Failure(wb_os.str());                                      \
    } while (0)

#define CHECK(cond)                                  \
    do {                                             \
        if (!(cond)) WB_FAIL("CHECK(" #cond ") failed"); \
    } while (0)

#define CHECK_NEAR(actual, expected, tol)                                                          \
    do {                                                                                           \
        const double wb_a = (actual), wb_e = (expected), wb_t = (tol);                             \
        if (!(std::fabs(wb_a - wb_e) <= wb_t))                                                     \
            WB_FAIL(#actual " = " << wb_a << ", expected " << wb_e << " +/- " << wb_t);            \
    } while (0)

#define CHECK_THROWS_AS(expr, type)                                            \
    do {                                                                       \
        bool wb_caught = false;                                                \
        try {                                                                  \
            (void)(expr);                                                      \
        } catch (const type&) {                                                \
            wb_caught = true;                                                  \
        } catch (...) {                                                        \
            WB_FAIL(#expr " threw an unexpected exception type");              \
        }                                                                      \
        if (!wb_caught) WB_FAIL(#expr " did not throw " #type);                \
    } while (0)

// Checks that the expression throws `type` and that its message contains `text`.
#define CHECK_THROWS_WITH(expr, type, text)                                              \
    do {                                                                                 \
        bool wb_caught = false;                                                          \
        try {                                                                            \
            (void)(expr);                                                                \
        } catch (const type& wb_e) {                                                     \
            wb_caught = true;                                                            \
            if (std::string(wb_e.what()).find(text) == std::string::npos)                \
                WB_FAIL("message '" << wb_e.what() << "' does not contain '" << text << "'"); \
        }                                                                                \
        if (!wb_caught) WB_FAIL(#expr " did not throw " #type);                          \
    } while (0)
