// Tests for the transport mapping layer: request validation and response shape.

#include "server/csv_export.hpp"
#include "server/json_mapping.hpp"
#include "test_framework.hpp"

using namespace wb::server;

TEST_CASE(api_rod_problem_defaults_and_validation) {
    const auto p = rodProblemFromJson(json::object());
    CHECK(p.length == 1.0 && p.conductivity == 10.0);
    CHECK_THROWS_WITH(rodProblemFromJson(json{{"conductivity", "ten"}}), ApiError, "must be a number");
    CHECK_THROWS_WITH(rodProblemFromJson(json{{"conductivity", -5}}), ApiError, "greater than zero");
    CHECK_THROWS_WITH(meshListFromJson(json{{"meshes", json::array()}}), ApiError, "1 to 12");
    CHECK_THROWS_WITH(meshListFromJson(json{{"meshes", {10, 0}}}), ApiError, "between 1 and 20000");
}

TEST_CASE(api_convergence_json_shape) {
    const auto study = wb::fea::runConvergenceStudy(wb::fea::RodProblem{}, {10, 20});
    const auto j = convergenceStudyToJson(study, 100);
    CHECK(j["meshes"].size() == 2);
    CHECK(j["meshes"][0]["x"].size() == 11);
    CHECK(j["meshes"][0]["midError"].size() == 10);
    CHECK(j["exact"]["x"].size() == 101);
    CHECK(j["units"]["T"] == "C");
}

TEST_CASE(api_benchmark_config_validation) {
    CHECK_THROWS_WITH(benchmarkConfigFromJson(json{{"cases", 1.5}}), ApiError, "whole number");
    CHECK_THROWS_WITH(benchmarkConfigFromJson(json{{"seed", -3}}), ApiError, "non-negative");
    CHECK_THROWS_WITH(benchmarkConfigFromJson(json{{"measuredRuns", 0}}), ApiError, "Measured runs");
    const auto c = benchmarkConfigFromJson(json{{"cases", 10}, {"elements", 100}, {"seed", 7}});
    CHECK(c.batch.caseCount == 10 && c.batch.elements == 100 && c.batch.seed == 7u);
}

TEST_CASE(api_stl_json_is_valid_json) {
    const auto mesh = wb::io::parseAsciiStl("solid a\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\nvertex 0.1 0 0\n"
                                            "vertex 0 0.1 0\nendloop\nendfacet\nendsolid a\n");
    const auto parsed = json::parse(stlMeshToJsonText(mesh, "a.stl", 10, 0.5));
    CHECK(parsed["triangleCount"] == 1);
    CHECK(parsed["vertices"].size() == 9);
    CHECK_NEAR(parsed["vertices"][3].get<double>(), 0.1, 1e-7);
}

TEST_CASE(api_backprop_json) {
    const auto j = backpropToJson(backpropRequestFromJson(json::object()));
    CHECK(j["gradientCheckPassed"] == true);
    CHECK(j["history"]["loss"].size() == 102);  // start + hand-checked step + 100 subsequent
    CHECK_THROWS_AS(backpropRequestFromJson(json{{"learningRate", 0}}), ApiError);
}

TEST_CASE(api_csv_exports_have_headers) {
    const auto study = wb::fea::runConvergenceStudy(wb::fea::RodProblem{}, {10});
    const std::string csv = feaConvergenceCsv(study);
    CHECK(csv.find("elements,h_m,max_nodal_error_C,max_midpoint_error_C") != std::string::npos);
    CHECK(feaNodalCsv(study).find("\n10,10,1,20,20,0\n") != std::string::npos);
}
