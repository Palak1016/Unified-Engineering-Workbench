#include "core/io/stl_reader.hpp"
#include "core/io/text_utils.hpp"
#include "test_framework.hpp"

using wb::io::InputError;
using wb::io::readAsciiStlFile;

namespace {
wb::io::StlMesh load(const char* name) { return readAsciiStlFile(wbtest::findPath(std::string("tests/data/stl/") + name)); }
}  // namespace

TEST_CASE(stl_valid_tetrahedron_parses) {
    const auto mesh = load("valid_tetrahedron.stl");
    CHECK(mesh.triangleCount() == 4);
    CHECK(mesh.solidName == "tetrahedron");
    CHECK_NEAR(mesh.bounds.min[0], 0.0, 0.0);
    CHECK_NEAR(mesh.bounds.max[2], 1.0, 0.0);
    CHECK(mesh.degenerateTriangles == 0);
    CHECK(mesh.normalMismatches == 0);
}

TEST_CASE(stl_example_heat_sink_parses) {
    const auto mesh = readAsciiStlFile(wbtest::findPath("data/geometry/heat_sink_7fin_mm.stl"));
    CHECK(mesh.triangleCount() == 12 * 8);
    CHECK_NEAR(mesh.bounds.max[0], 60.0, 1e-9);
    CHECK_NEAR(mesh.bounds.max[2], 30.0, 1e-9);
}

TEST_CASE(stl_empty_file_is_explained) {
    CHECK_THROWS_WITH(load("empty.stl"), InputError, "empty (0 bytes)");
    CHECK_THROWS_WITH(load("whitespace_only.stl"), InputError, "only whitespace");
    CHECK_THROWS_WITH(load("no_facets.stl"), InputError, "no facets");
}

TEST_CASE(stl_non_finite_values_rejected) {
    CHECK_THROWS_WITH(load("nan_vertex.stl"), InputError, "non-finite");
    CHECK_THROWS_WITH(load("inf_vertex.stl"), InputError, "non-finite");
}

TEST_CASE(stl_structural_errors_report_line) {
    try {
        load("two_vertices.stl");
        WB_FAIL("expected an error");
    } catch (const InputError& e) {
        CHECK(e.line() == 6);
        CHECK(std::string(e.what()).find("only 2 vertices") != std::string::npos);
    }
    CHECK_THROWS_WITH(load("missing_endloop.stl"), InputError, "expected 'endloop'");
    CHECK_THROWS_WITH(load("truncated.stl"), InputError, "truncated");
    CHECK_THROWS_WITH(load("bad_number.stl"), InputError, "not a valid number");
}

TEST_CASE(stl_binary_file_detected_despite_solid_header) {
    CHECK_THROWS_WITH(load("binary_misleading_header.stl"), InputError, "binary STL");
}

TEST_CASE(stl_size_and_triangle_limits_enforced) {
    wb::io::StlLimits limits;
    limits.maxTriangles = 3;
    CHECK_THROWS_WITH(readAsciiStlFile(wbtest::findPath("tests/data/stl/valid_tetrahedron.stl"), limits), InputError,
                      "tested limit");
    limits = {};
    limits.maxBytes = 100;
    CHECK_THROWS_WITH(readAsciiStlFile(wbtest::findPath("tests/data/stl/valid_tetrahedron.stl"), limits), InputError,
                      "tested limit");
}

TEST_CASE(stl_quality_warnings) {
    const std::string text =
        "solid q\n facet normal 0 0 -1\n outer loop\n vertex 0 0 0\n vertex 1 0 0\n vertex 0 1 0\n endloop\n endfacet\n"
        " facet normal 0 0 1\n outer loop\n vertex 0 0 0\n vertex 1 0 0\n vertex 2 0 0\n endloop\n endfacet\nendsolid q\n";
    const auto mesh = wb::io::parseAsciiStl(text);
    CHECK(mesh.triangleCount() == 2);
    CHECK(mesh.degenerateTriangles == 1);   // collinear vertices
    CHECK(mesh.normalMismatches == 1);      // normal opposite to winding
    CHECK(mesh.warnings.size() == 2);
}

TEST_CASE(stl_missing_file_reported) {
    CHECK_THROWS_WITH(readAsciiStlFile("does/not/exist.stl"), InputError, "not found");
}
