#include "core/hardware/hardware_manager.hpp"
#include "test_framework.hpp"

using namespace wb::hardware;

namespace {
HardwareManager fastManager() {
    std::vector<std::unique_ptr<DeviceAdapter>> adapters;
    adapters.push_back(makeMockMicrocontroller("mcu-0", 1));
    adapters.push_back(makeMockFpga("fpga-0", 2));
    adapters.push_back(makeMockJtagAdapter("jtag-0", 3));
    return HardwareManager(std::move(adapters), {std::chrono::milliseconds(30), std::chrono::milliseconds(20)});
}
}  // namespace

TEST_CASE(hw_discovery_lists_three_simulated_kinds) {
    auto m = fastManager();
    const auto list = m.discover();
    CHECK(list.size() == 3);
    CHECK(list[0].descriptor.kind == DeviceKind::Microcontroller);
    CHECK(list[1].descriptor.kind == DeviceKind::Fpga);
    CHECK(list[2].descriptor.kind == DeviceKind::JtagAdapter);
    for (const auto& d : list) {
        CHECK(d.descriptor.simulated);
        CHECK(d.state == ConnectionState::Disconnected);
        CHECK(!d.capabilities.empty());
    }
}

TEST_CASE(hw_connect_telemetry_disconnect) {
    auto m = fastManager();
    for (const char* id : {"mcu-0", "fpga-0", "jtag-0"}) {
        CHECK(m.connect(id).state == ConnectionState::Connected);
        const auto t1 = m.readTelemetry(id);
        const auto t2 = m.readTelemetry(id);
        CHECK(t1.ok && t2.ok);
        CHECK(t1.message.simulated);
        CHECK(t2.message.sequence == t1.message.sequence + 1);
        CHECK(!t1.message.fields.empty());
        CHECK(m.disconnect(id).state == ConnectionState::Disconnected);
    }
}

TEST_CASE(hw_telemetry_requires_connection) {
    auto m = fastManager();
    const auto r = m.readTelemetry("mcu-0");
    CHECK(!r.ok);
    CHECK(r.status.state == ConnectionState::Disconnected);
}

TEST_CASE(hw_connect_timeout_is_recoverable) {
    auto m = fastManager();
    m.injectFault("fpga-0", FaultKind::ConnectTimeout);
    const auto failed = m.connect("fpga-0");
    CHECK(failed.state == ConnectionState::Faulted);
    CHECK(failed.lastError.find("timeout") != std::string::npos);
    const auto recovered = m.connect("fpga-0");
    CHECK(recovered.state == ConnectionState::Connected);
    CHECK(recovered.lastError.empty());
    bool sawRecovery = false;
    for (const auto& e : m.events()) sawRecovery |= e.message.find("recovered") != std::string::npos;
    CHECK(sawRecovery);
}

TEST_CASE(hw_telemetry_timeout_is_recoverable) {
    auto m = fastManager();
    m.connect("jtag-0");
    m.injectFault("jtag-0", FaultKind::TelemetryTimeout);
    const auto r = m.readTelemetry("jtag-0");
    CHECK(!r.ok);
    CHECK(r.status.state == ConnectionState::Faulted);
    CHECK(m.connect("jtag-0").state == ConnectionState::Connected);
    CHECK(m.readTelemetry("jtag-0").ok);
}

TEST_CASE(hw_unknown_device_rejected) {
    auto m = fastManager();
    CHECK_THROWS_AS(m.connect("dsp-9"), std::out_of_range);
}

TEST_CASE(hw_jtag_reports_debug_role) {
    auto m = fastManager();
    bool found = false;
    for (const auto& cap : m.status("jtag-0").capabilities) {
        if (cap.name == "role") found = cap.value.find("does not run user workloads") != std::string::npos;
    }
    CHECK(found);
}
