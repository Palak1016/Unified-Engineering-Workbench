#include "core/fea/rod_fea.hpp"
#include "test_framework.hpp"

#include <stdexcept>

using namespace wb::fea;

TEST_CASE(fea_boundary_conditions_imposed_exactly) {
    const auto s = solveRod(RodProblem{}, 10);
    CHECK(s.T.size() == 11);
    CHECK(s.T.front() == 100.0);
    CHECK(s.T.back() == 20.0);
}

TEST_CASE(fea_nodal_values_match_exact_solution) {
    // For 1D linear elements with exactly integrated uniform load, nodal
    // values coincide with the exact solution up to round-off.
    for (int n : {10, 20, 40, 80}) {
        const auto s = solveRod(RodProblem{}, n);
        CHECK(evaluateErrors(RodProblem{}, s).maxNodalError < 1e-10);
    }
}

TEST_CASE(fea_midpoint_error_matches_theory) {
    // Exact solution is quadratic; the linear interpolant between exact nodal
    // values is off by q h^2 / (8k) at every midpoint.
    const RodProblem p;
    for (int n : {10, 20, 40, 80}) {
        const auto err = evaluateErrors(p, solveRod(p, n));
        const double h = p.length / n;
        CHECK_NEAR(err.maxMidpointError, p.heatGeneration * h * h / (8.0 * p.conductivity), 1e-9);
    }
}

TEST_CASE(fea_convergence_is_second_order) {
    const auto study = runConvergenceStudy(RodProblem{}, {10, 20, 40, 80});
    CHECK(study.rows.size() == 4);
    CHECK_NEAR(study.rows[0].maxMidpointError, 1.25, 1e-9);
    for (std::size_t i = 1; i < study.rows.size(); ++i) {
        CHECK_NEAR(study.rows[i].observedOrder, 2.0, 1e-6);
    }
}

TEST_CASE(fea_exact_solution_values) {
    const RodProblem p;
    CHECK_NEAR(exactTemperature(p, 0.0), 100.0, 1e-12);
    CHECK_NEAR(exactTemperature(p, 1.0), 20.0, 1e-12);
    CHECK_NEAR(exactTemperature(p, 0.5), 100.0 - 40.0 + 500.0 * 0.25, 1e-12);  // 185 C
}

TEST_CASE(fea_area_cancels_out) {
    RodProblem p;
    const auto a = solveRod(p, 40);
    p.area = 3.7e-3;
    const auto b = solveRod(p, 40);
    for (std::size_t i = 0; i < a.T.size(); ++i) CHECK_NEAR(a.T[i], b.T[i], 1e-9);
}

TEST_CASE(fea_no_heat_generation_gives_linear_profile) {
    RodProblem p;
    p.heatGeneration = 0.0;
    const auto s = solveRod(p, 7);
    for (std::size_t i = 0; i < s.x.size(); ++i) CHECK_NEAR(s.T[i], 100.0 - 80.0 * s.x[i], 1e-10);
    CHECK(evaluateErrors(p, s).maxMidpointError < 1e-10);
}

TEST_CASE(fea_single_element_and_two_elements) {
    const auto one = solveRod(RodProblem{}, 1);
    CHECK(one.T.size() == 2);
    const auto two = solveRod(RodProblem{}, 2);
    CHECK_NEAR(two.T[1], exactTemperature(RodProblem{}, 0.5), 1e-10);
}

TEST_CASE(fea_interpolation_is_linear_between_nodes) {
    const auto s = solveRod(RodProblem{}, 4);
    CHECK_NEAR(interpolate(s, 0.125), 0.5 * (s.T[0] + s.T[1]), 1e-12);
    CHECK_NEAR(interpolate(s, 0.0), 100.0, 0.0);
    CHECK_NEAR(interpolate(s, 1.0), 20.0, 0.0);
}

TEST_CASE(fea_invalid_inputs_rejected) {
    RodProblem p;
    p.conductivity = 0.0;
    CHECK_THROWS_WITH(solveRod(p, 10), std::invalid_argument, "Conductivity");
    p = RodProblem{};
    p.length = -1.0;
    CHECK_THROWS_AS(solveRod(p, 10), std::invalid_argument);
    p = RodProblem{};
    p.heatGeneration = std::nan("");
    CHECK_THROWS_AS(solveRod(p, 10), std::invalid_argument);
    p = RodProblem{};
    p.tLeft = -300.0;
    CHECK_THROWS_WITH(solveRod(p, 10), std::invalid_argument, "absolute zero");
    CHECK_THROWS_AS(solveRod(RodProblem{}, 0), std::invalid_argument);
}
