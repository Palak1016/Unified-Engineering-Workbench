#include "core/ml/backprop.hpp"
#include "test_framework.hpp"

#include <cmath>

using namespace wb::ml;

TEST_CASE(bp_forward_pass_values) {
    const auto f = forward(Parameters{}, Sample{});
    CHECK_NEAR(f.z, 0.5, 0.0);
    CHECK_NEAR(f.h, std::tanh(0.5), 1e-15);
    CHECK_NEAR(f.h, 0.46211715726, 1e-10);
    CHECK_NEAR(f.error, 0.46211715726 - 2.0, 1e-10);
    CHECK_NEAR(f.loss, 0.5 * f.error * f.error, 0.0);
}

TEST_CASE(bp_analytic_gradients_hand_values) {
    // Values worked by hand (see docs/backprop_worked_solution.md).
    const auto g = analyticGradients(Parameters{}, Sample{});
    CHECK_NEAR(g.dc, -1.5378828427, 1e-9);
    CHECK_NEAR(g.dv, -0.7106820475, 1e-9);
    CHECK_NEAR(g.dw, -1.2094644752, 1e-9);
    CHECK_NEAR(g.db, g.dw, 0.0);  // x = 1
}

TEST_CASE(bp_gradients_match_central_differences) {
    const Parameters p;
    const Sample s;
    const auto g = analyticGradients(p, s);
    const auto fd = finiteDifferenceGradients(p, s, 1e-6);
    CHECK_NEAR(g.dw, fd.dw, 1e-5);
    CHECK_NEAR(g.db, fd.db, 1e-5);
    CHECK_NEAR(g.dv, fd.dv, 1e-5);
    CHECK_NEAR(g.dc, fd.dc, 1e-5);
    // And away from the starting point.
    const Parameters q{-0.7, 0.3, 1.9, -0.4};
    const auto g2 = analyticGradients(q, s);
    const auto fd2 = finiteDifferenceGradients(q, s, 1e-6);
    CHECK_NEAR(g2.dw, fd2.dw, 1e-5);
    CHECK_NEAR(g2.dv, fd2.dv, 1e-5);
}

TEST_CASE(bp_first_update_is_simultaneous) {
    const Parameters p;
    const auto g = analyticGradients(p, Sample{});
    const auto p1 = gradientStep(p, g, 0.1);
    CHECK_NEAR(p1.w, 0.5 - 0.1 * g.dw, 0.0);
    CHECK_NEAR(p1.b, 0.0 - 0.1 * g.db, 0.0);
    CHECK_NEAR(p1.v, 1.0 - 0.1 * g.dv, 0.0);
    CHECK_NEAR(p1.c, 0.0 - 0.1 * g.dc, 0.0);
    CHECK(forward(p1, Sample{}).loss < forward(p, Sample{}).loss);
}

TEST_CASE(bp_training_decreases_loss) {
    const auto history = train(Parameters{}, Sample{}, 0.1, 101);
    CHECK(history.size() == 102);
    for (std::size_t i = 1; i < history.size(); ++i) CHECK(history[i].loss <= history[i - 1].loss + 1e-15);
    CHECK(history.back().loss < 1e-4);
}

TEST_CASE(bp_invalid_settings_rejected) {
    CHECK_THROWS_AS(train(Parameters{}, Sample{}, -0.1, 10), std::invalid_argument);
    CHECK_THROWS_AS(finiteDifferenceGradients(Parameters{}, Sample{}, 0.0), std::invalid_argument);
}
