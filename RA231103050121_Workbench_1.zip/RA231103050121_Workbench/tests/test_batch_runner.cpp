#include "core/parallel/batch_runner.hpp"
#include "test_framework.hpp"

#include <algorithm>
#include <random>
#include <thread>

using namespace wb::parallel;

TEST_CASE(batch_generator_is_reproducible) {
    BatchConfig c;
    c.caseCount = 50;
    c.elements = 20;
    const auto a = generateBatch(c);
    const auto b = generateBatch(c);
    for (std::size_t i = 0; i < a.size(); ++i) {
        CHECK(a[i].conductivity == b[i].conductivity);
        CHECK(a[i].heatGeneration == b[i].heatGeneration);
        CHECK(a[i].conductivity >= c.kMin && a[i].conductivity < c.kMax);
        CHECK(a[i].heatGeneration >= c.qMin && a[i].heatGeneration < c.qMax);
    }
    c.seed += 1;
    CHECK(generateBatch(c)[0].conductivity != a[0].conductivity);
}

TEST_CASE(batch_generator_first_values_are_pinned) {
    // Guards against accidental changes to the generator: these values are
    // what std::mt19937_64(20260101) must produce on every platform.
    BatchConfig c;
    c.caseCount = 2;
    c.elements = 10;
    const auto cases = generateBatch(c);
    std::mt19937_64 rng(20260101);
    const double u0 = static_cast<double>(rng() >> 11) / 9007199254740992.0;
    CHECK_NEAR(cases[0].conductivity, c.kMin + (c.kMax - c.kMin) * u0, 0.0);
}

TEST_CASE(batch_serial_and_parallel_agree) {
    BatchConfig c;
    c.caseCount = 37;  // not a multiple of the chunk size or worker count
    c.elements = 200;
    const auto cases = generateBatch(c);
    BatchResult serial, parallel;
    serial.resize(c.caseCount, c.elements);
    parallel.resize(c.caseCount, c.elements);
    solveSerial(cases, c.elements, serial);
    for (std::size_t workers : {1u, 2u, 3u, 4u}) {
        WorkerPool pool(workers);
        std::fill(parallel.temperatures.begin(), parallel.temperatures.end(), -1.0);
        solveParallel(cases, c.elements, pool, parallel);
        CHECK(maxAbsDifference(serial, parallel) <= 1e-8);
        for (std::size_t i = 0; i < serial.maxMidpointError.size(); ++i) {
            CHECK(serial.maxMidpointError[i] == parallel.maxMidpointError[i]);
        }
    }
}

TEST_CASE(batch_results_in_input_order) {
    BatchConfig c;
    c.caseCount = 16;
    c.elements = 10;
    const auto cases = generateBatch(c);
    BatchResult r;
    r.resize(c.caseCount, c.elements);
    WorkerPool pool(4);
    solveParallel(cases, c.elements, pool, r);
    for (int i = 0; i < c.caseCount; ++i) {
        const double* slice = r.temperatures.data() + i * r.nodesPerCase;
        const auto& p = cases[static_cast<std::size_t>(i)];
        CHECK_NEAR(slice[5], wb::fea::exactTemperature(p, 0.5), 1e-9);  // node 5 of 10 is x = 0.5
    }
}

TEST_CASE(batch_cancellation_stops_work) {
    BatchConfig c;
    c.caseCount = 64;
    c.elements = 50;
    const auto cases = generateBatch(c);
    BatchResult r;
    r.resize(c.caseCount, c.elements);
    CancelToken token;
    token.request();
    WorkerPool pool(2);
    CHECK_THROWS_AS(solveParallel(cases, c.elements, pool, r, &token), Cancelled);
    CHECK_THROWS_AS(solveSerial(cases, c.elements, r, &token), Cancelled);
}

TEST_CASE(batch_benchmark_report_is_consistent) {
    BenchmarkConfig c;
    c.batch.caseCount = 40;
    c.batch.elements = 500;
    c.measuredRuns = 3;
    c.warmupRuns = 1;
    c.maxWorkers = 2;
    double lastProgress = 0.0;
    const auto report = runBenchmark(c, [&](double f, const std::string&) {
        CHECK(f >= lastProgress);
        lastProgress = f;
    });
    CHECK_NEAR(lastProgress, 1.0, 1e-12);
    CHECK(report.agreementPassed);
    CHECK(report.rows.front().label == "serial");
    for (const auto& row : report.rows) {
        CHECK(row.runMs.size() == 3);
        CHECK(row.medianMs > 0.0);
    }
    const unsigned expected = std::min(2u, std::max(1u, report.system.logicalCores));
    CHECK(report.rows.size() == 1 + expected);
    CHECK_NEAR(report.rows[1].speedup, 1.0, 1e-12);  // T1/T1
}

TEST_CASE(batch_invalid_config_rejected) {
    BatchConfig c;
    c.caseCount = 0;
    CHECK_THROWS_AS(generateBatch(c), std::invalid_argument);
    c = BatchConfig{};
    c.kMin = -1.0;
    CHECK_THROWS_AS(generateBatch(c), std::invalid_argument);
    c = BatchConfig{};
    c.caseCount = 100000;
    c.elements = 1000;
    CHECK_THROWS_WITH(generateBatch(c), std::invalid_argument, "memory limit");
    BenchmarkConfig b;
    b.measuredRuns = 0;
    CHECK_THROWS_AS(runBenchmark(b), std::invalid_argument);
}
