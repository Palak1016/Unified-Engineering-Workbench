// Performance view: serial vs worker-pool batch benchmark run as a backend job.

import { api } from '../api.js';
import { renderPlot } from '../plot.js';
import { $, downloadBlob, fmt, readNumbers, reportError, setFacts, setList, setStatus, toast } from '../ui.js';

const RULES = {
  cases: { integer: true, min: 1, max: 100000, label: 'Cases' },
  elements: { integer: true, min: 1, max: 2000000, label: 'Elements per case' },
  seed: { integer: true, min: 0, label: 'Seed' },
  maxWorkers: { integer: true, min: 1, max: 64, label: 'Max workers' },
  warmupRuns: { integer: true, min: 0, max: 10, label: 'Warm-up runs' },
  measuredRuns: { integer: true, min: 1, max: 50, label: 'Measured runs' },
};

let jobId = null;
let completedJobId = null; // export always refers to the last finished run
let pollTimer = null;

export async function loadSystemInfo() {
  try {
    const s = await api.get('/api/system');
    setFacts($('#sys-facts'), [
      ['CPU', s.cpuModel],
      ['Cores', `${s.physicalCores || '?'} physical / ${s.logicalCores} logical`],
      ['RAM', `${s.totalRamGiB.toFixed(1)} GiB`],
      ['OS', s.operatingSystem],
      ['Compiler', s.compiler],
      ['Flags', `${s.compilerFlags || '(none)'} [${s.buildType}]`],
      ['Launch-to-ready', s.launchToReadyMs ? `${s.launchToReadyMs.toFixed(0)} ms (process start → server listening)` : 'n/a'],
      ['UI ready', s.uiReadyMs ? `${s.uiReadyMs.toFixed(0)} ms (page load → interactive)` : 'pending'],
      ['Log file', `logs/${s.logFile}`],
    ]);
    return s;
  } catch (err) {
    reportError(err, 'Could not read system information');
    return null;
  }
}

function setRunning(running) {
  $('#bench-run').disabled = running;
  $('#bench-cancel').disabled = !running;
  $('#bench-progress').hidden = !running && !jobId;
}

function showProgress(fraction, text) {
  $('#bench-progress').hidden = false;
  $('#bench-progress .progress-bar span').style.width = `${(fraction * 100).toFixed(1)}%`;
  $('#bench-progress .progress-text').textContent = text;
}

function showReport(report) {
  const body = $('#bench-table tbody');
  body.innerHTML = report.rows.map((row) => {
    const name = row.workers === 0 ? 'Serial loop (no threads)' : `Worker pool, p = ${row.workers}`;
    return `<tr><td>${name}</td><td>${row.runMs.map((v) => v.toFixed(1)).join(', ')}</td>
      <td><strong>${row.medianMs.toFixed(2)}</strong></td>
      <td>${row.workers ? row.speedup.toFixed(3) : '–'}</td>
      <td>${row.workers ? (row.efficiency * 100).toFixed(1) + ' %' : '–'}</td>
      <td>${row.workers ? row.maxAbsDiffC.toExponential(2) : 'reference'}</td></tr>`;
  }).join('');
  const ok = report.agreementPassed;
  $('#bench-agreement').innerHTML = `<span class="badge ${ok ? 'badge-ok' : 'badge-bad'}">${ok ? 'Serial/parallel agree ≤ 1e-8 °C' : 'Agreement check FAILED'}</span>`;

  const c = report.config;
  const notes = [
    `Workload: ${c.cases} cases × ${c.elements} elements (seed ${c.seed}), ${c.warmupRuns} warm-up + ${c.measuredRuns} measured runs per configuration; batch generation ${report.generationMs.toFixed(1)} ms (not timed).`,
    ...report.notes,
  ];
  setList($('#bench-notes'), notes, 'info');

  const pool = report.rows.filter((r) => r.workers > 0);
  const p = pool.map((r) => r.workers);
  renderPlot($('#bench-plot-speedup'), {
    xLabel: 'Workers p', yLabel: 'Speedup T1/Tp', legend: 'tl', xMin: 0.8, xMax: Math.max(...p) + 0.2, yMin: 0,
    series: [
      { name: 'ideal (= p)', x: p, y: p, color: '#868e96', dash: '4 4', width: 1.2 },
      { name: 'measured', x: p, y: pool.map((r) => r.speedup), markers: true, markerSize: 4, color: '#1f5fae' },
    ],
  });
  const serial = report.rows.find((r) => r.workers === 0);
  renderPlot($('#bench-plot-time'), {
    xLabel: 'Workers p', yLabel: 'Median compute time [ms]', legend: 'tr', xMin: 0.8, xMax: Math.max(...p) + 0.2, yMin: 0,
    series: [
      { name: 'worker pool', x: p, y: pool.map((r) => r.medianMs), markers: true, markerSize: 4, color: '#d9480f' },
      { name: 'serial loop', x: [Math.min(...p), Math.max(...p)], y: [serial.medianMs, serial.medianMs], color: '#2b8a3e', dash: '6 3', width: 1.2 },
    ],
  });
  $('#bench-export').disabled = false;
}

async function poll() {
  if (!jobId) return;
  try {
    const job = await api.get(`/api/jobs/${jobId}`, { timeoutMs: 10000 });
    showProgress(job.progress, `${job.stage} · ${job.elapsedS.toFixed(1)} s`);
    if (job.state === 'running') {
      pollTimer = setTimeout(poll, 300);
      return;
    }
    setRunning(false);
    if (job.state === 'completed') {
      completedJobId = jobId;
      showReport(job.report);
      setStatus(`Benchmark finished in ${job.elapsedS.toFixed(1)} s. Agreement ${job.report.agreementPassed ? 'passed' : 'FAILED'}.`);
      toast('Benchmark finished.', 'ok');
    } else if (job.state === 'cancelled') {
      setStatus('Benchmark cancelled. Previous results (if any) were left unchanged.');
      toast('Benchmark cancelled.');
    } else {
      reportError(new Error(job.error || 'unknown error'), 'Benchmark failed');
    }
  } catch (err) {
    setRunning(false);
    reportError(err, 'Lost contact with the benchmark job');
  }
}

async function start(event) {
  event.preventDefault();
  let config;
  try {
    config = readNumbers($('#bench-form'), RULES);
    if (config.cases * (config.elements + 1) > 16_000_000) {
      throw new Error('Cases × (elements + 1) must stay below 16,000,000 nodes. Reduce one of them.');
    }
  } catch (err) {
    setStatus(err.message, true);
    toast(err.message, 'error');
    return;
  }
  try {
    const { id } = await api.post('/api/jobs/benchmark', { json: config });
    jobId = id;
    setRunning(true);
    showProgress(0, 'Starting…');
    setStatus('Benchmark running in the background. The interface stays usable.');
    poll();
  } catch (err) {
    reportError(err, 'Could not start the benchmark');
  }
}

async function cancel() {
  if (!jobId) return;
  $('#bench-cancel').disabled = true;
  try {
    await api.post(`/api/jobs/${jobId}/cancel`);
    setStatus('Cancelling… the current solve finishes first.');
  } catch (err) {
    reportError(err, 'Cancel failed');
  }
}

async function exportCsv() {
  if (!completedJobId) return;
  try {
    const { blob, fileName } = await api.get(`/api/jobs/${completedJobId}/export`);
    downloadBlob(blob, fileName);
  } catch (err) {
    reportError(err, 'Export failed');
  }
}

export function initPerformance() {
  $('#bench-form').addEventListener('submit', start);
  $('#bench-cancel').addEventListener('click', cancel);
  $('#bench-export').addEventListener('click', exportCsv);
}

export function stopPolling() {
  clearTimeout(pollTimer);
}
