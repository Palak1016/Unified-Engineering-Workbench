// Thermal Analysis view: 1D rod FEA, analytical comparison and convergence.

import { api } from '../api.js';
import { renderPlot, COLORS } from '../plot.js';
import { $, $all, downloadBlob, fmt, readNumbers, reportError, setStatus, toast } from '../ui.js';

const RULES = {
  length: { positive: true, label: 'Length L' },
  area: { positive: true, label: 'Area A' },
  conductivity: { positive: true, label: 'Conductivity k' },
  heatGeneration: { label: 'Heat generation q' },
  tLeft: { min: -273.15, label: 'T(0)' },
  tRight: { min: -273.15, label: 'T(L)' },
};
const DEFAULTS = { length: '1', area: '1e-4', conductivity: '10', heatGeneration: '10000', tLeft: '100', tRight: '20' };

let lastRequest = null;

function collectRequest() {
  const form = $('#fea-form');
  const values = readNumbers(form, RULES);
  const meshes = $all('#fea-meshes input:checked').map((c) => Number(c.value));
  const extraInput = $('#fea-extra');
  const extra = extraInput.value.split(/[,\s]+/).filter(Boolean);
  for (const token of extra) {
    const n = Number(token);
    if (!Number.isInteger(n) || n < 1 || n > 20000) {
      extraInput.classList.add('invalid');
      throw new Error(`Extra mesh size "${token}" must be a whole number from 1 to 20000.`);
    }
    meshes.push(n);
  }
  extraInput.classList.remove('invalid');
  const unique = [...new Set(meshes)].sort((a, b) => a - b);
  if (!unique.length) throw new Error('Select at least one mesh size.');
  if (unique.length > 12) throw new Error('Use at most 12 mesh sizes at once.');
  return { ...values, meshes: unique };
}

function drawResults(r) {
  const series = [
    { name: 'Exact T(x)', x: r.exact.x, y: r.exact.T, color: '#1d2733', width: 2.2 },
  ];
  r.meshes.forEach((m, i) => {
    series.push({
      name: `FE, N = ${m.elements}`, x: m.x, y: m.T, color: COLORS[(i + 1) % COLORS.length],
      line: true, markers: m.elements <= 40, width: 1.2, dash: '5 3',
    });
  });
  renderPlot($('#fea-plot-T'), { xLabel: 'Position x [m]', yLabel: 'Temperature T [°C]', series, legend: 'tr' });

  renderPlot($('#fea-plot-err'), {
    xLabel: 'Element midpoint x [m]', yLabel: '|T_FE − T_exact| [°C]', yLog: true, legend: 'br',
    series: r.meshes.map((m, i) => ({ name: `N = ${m.elements}`, x: m.midX, y: m.midError, color: COLORS[(i + 1) % COLORS.length], markers: m.elements <= 20, line: true })),
  });

  const rows = r.convergence;
  const h = rows.map((row) => row.h);
  const e = rows.map((row) => row.maxMidpointError);
  const convSeries = [{ name: 'max midpoint error (FE)', x: h, y: e, markers: true, color: '#1f5fae', markerSize: 4 }];
  if (rows.length >= 1 && e[0] > 0) {
    const ref = h.map((hv) => e[0] * (hv / h[0]) ** 2);
    convSeries.push({ name: 'slope 2 reference', x: h, y: ref, color: '#868e96', dash: '4 4', width: 1.2 });
  }
  const nodal = rows.map((row) => Math.max(row.maxNodalError, 1e-16));
  convSeries.push({ name: 'max nodal error', x: h, y: nodal, color: '#d9480f', markers: true, line: true, dash: '2 3' });
  renderPlot($('#fea-plot-conv'), { xLabel: 'Element size h [m]', yLabel: 'max |error| [°C]', xLog: true, yLog: true, series: convSeries, legend: 'br' });

  const body = $('#fea-table tbody');
  body.innerHTML = rows.map((row) => `<tr>
      <td>${row.elements}</td><td>${fmt(row.h, 5)}</td><td>${row.maxNodalError.toExponential(2)}</td>
      <td>${row.maxMidpointError.toExponential(6)}</td><td>${row.predictedMidpointError.toExponential(6)}</td>
      <td>${row.observedOrder ? row.observedOrder.toFixed(4) : '–'}</td></tr>`).join('');

  const p = r.problem;
  const tMax = Math.max(...r.exact.T);
  const xAtMax = r.exact.x[r.exact.T.indexOf(tMax)];
  $('#fea-insight').textContent =
    `Nodal values agree with the exact solution to round-off (≤ ${Math.max(...nodal).toExponential(1)} °C), so the error lives between nodes. ` +
    `Midpoint error follows q·h²/(8k) and halves twice for every halving of h (observed order ≈ 2). ` +
    `Peak temperature ≈ ${tMax.toFixed(2)} °C near x = ${xAtMax.toFixed(3)} m for q = ${fmt(p.heatGeneration)} W/m³.`;
}

async function solve(event) {
  event?.preventDefault();
  let request;
  try {
    request = collectRequest();
  } catch (err) {
    setStatus(err.message, true);
    toast(err.message, 'error');
    return;
  }
  const button = $('#fea-solve');
  button.disabled = true;
  setStatus('Solving in the C++ backend…');
  const started = performance.now();
  try {
    const result = await api.post('/api/fea/solve', { json: request });
    lastRequest = request;
    drawResults(result);
    $all('[data-fea-export]').forEach((b) => (b.disabled = false));
    setStatus(`Solved ${request.meshes.length} mesh(es) in ${(performance.now() - started).toFixed(0)} ms (round trip).`);
  } catch (err) {
    reportError(err, 'FEA solve failed');
  } finally {
    button.disabled = false;
  }
}

async function exportCsv(kind) {
  if (!lastRequest) return;
  try {
    const { blob, fileName } = await api.post('/api/fea/export', { json: lastRequest, query: { kind } });
    downloadBlob(blob, fileName);
    setStatus(`Exported ${fileName}.`);
  } catch (err) {
    reportError(err, 'Export failed');
  }
}

export function initThermal() {
  $('#fea-form').addEventListener('submit', solve);
  $('#fea-defaults').addEventListener('click', () => {
    const form = $('#fea-form');
    for (const [k, v] of Object.entries(DEFAULTS)) form.querySelector(`[name="${k}"]`).value = v;
    $all('#fea-meshes input').forEach((c) => (c.checked = true));
    $('#fea-extra').value = '';
    solve();
  });
  $all('[data-fea-export]').forEach((b) => b.addEventListener('click', () => exportCsv(b.dataset.feaExport)));
}

export { solve as solveFea };
