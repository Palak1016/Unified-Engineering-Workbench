// ANSYS nodal temperature CSV import, shown as a coloured point cloud.

import { api } from '../api.js';
import { $, MAX_UPLOAD_BYTES, fmt, fmtBytes, reportError, setFacts, setList, setStatus, toast, wireFileDrop } from '../ui.js';
import { Viewer3D } from '../viewer3d.js';

let viewer = null;

function ensureViewer() {
  if (!viewer) {
    viewer = new Viewer3D($('#csv-viewer'));
    viewer.onPick = (node) => {
      setFacts($('#csv-node'), [
        ['node_id', String(node.nodeId)],
        ['x', `${fmt(node.x, 6)} m`],
        ['y', `${fmt(node.y, 6)} m`],
        ['z', `${fmt(node.z, 6)} m`],
        ['Temperature', `${fmt(node.t, 6)} °C`],
      ]);
      setStatus(`Node ${node.nodeId}: ${node.t.toFixed(3)} °C at (${fmt(node.x)}, ${fmt(node.y)}, ${fmt(node.z)}) m`);
    };
  }
  return viewer;
}

function show(r) {
  const v = ensureViewer();
  v.setPointCloud(r.xyz, r.temperature, r.temperatureMinC, r.temperatureMaxC, r.nodeIds);
  v.setPointSize(Number($('#csv-size').value));
  const size = r.bounds.size;
  setFacts($('#csv-facts'), [
    ['File', r.fileName],
    ['Size on disk', fmtBytes(r.fileBytes)],
    ['Nodes', r.nodeCount.toLocaleString()],
    ['T min', `${fmt(r.temperatureMinC, 6)} °C`],
    ['T max', `${fmt(r.temperatureMaxC, 6)} °C`],
    ['Extent', `${fmt(size[0], 4)} × ${fmt(size[1], 4)} × ${fmt(size[2], 4)} m`],
    ['Data origin', r.declaredSynthetic ? 'SYNTHETIC (declared in file)' : 'not declared'],
    ['Parse time (C++)', `${r.parseMs.toFixed(1)} ms`],
  ]);
  setFacts($('#csv-node'), [['–', 'click a point']]);
  const notes = [...r.warnings];
  setList($('#csv-warnings'), notes);
  if (r.comments.length) {
    const ul = $('#csv-warnings');
    for (const c of r.comments) {
      const li = document.createElement('li');
      li.className = 'info';
      li.textContent = c;
      ul.appendChild(li);
    }
  }
  v.setOverlay(`${r.fileName} · ${r.nodeCount.toLocaleString()} nodes${r.declaredSynthetic ? ' · SYNTHETIC' : ''}`);
  setStatus(`Loaded ${r.fileName}: ${r.nodeCount.toLocaleString()} nodes, ${r.temperatureMinC.toFixed(2)} to ${r.temperatureMaxC.toFixed(2)} °C.`);
}

function showFailure(err, name) {
  setFacts($('#csv-facts'), [['Status', 'Import failed'], ['File', name]]);
  setList($('#csv-warnings'), [err.message + (err.line ? ` (line ${err.line})` : '')]);
  reportError(err, `Could not import ${name}`);
}

async function loadFile(file) {
  if (file.size > MAX_UPLOAD_BYTES) {
    showFailure(new Error(`File is ${fmtBytes(file.size)}; the tested limit is 64 MB.`), file.name);
    return;
  }
  setStatus(`Reading ${file.name}…`);
  try {
    const text = await file.text();
    setStatus(`Parsing ${file.name} in the backend…`);
    show(await api.post('/api/results/nodal', { text, query: { name: file.name }, timeoutMs: 120000 }));
  } catch (err) {
    showFailure(err, file.name);
  }
}

async function loadExample() {
  const name = $('#csv-example').value;
  if (!name) return toast('No bundled CSV example was found in the data folder.', 'error');
  try {
    show(await api.get('/api/examples/nodal', { query: { name } }));
  } catch (err) {
    showFailure(err, name);
  }
}

export function initAnsys(examples) {
  $('#csv-example').innerHTML = examples
    .filter((e) => e.kind === 'nodal-csv')
    .map((e) => `<option value="${e.name}">${e.name}</option>`)
    .join('');
  wireFileDrop($('#csv-drop'), $('#csv-file'), loadFile);
  $('#csv-example-load').addEventListener('click', loadExample);
  $('#csv-fit').addEventListener('click', () => viewer?.fitToView());
  $('#csv-reset').addEventListener('click', () => viewer?.resetView());
  $('#csv-size').addEventListener('input', (e) => viewer?.setPointSize(Number(e.target.value)));
}
