// Hardware view: simulated MCU, FPGA and JTAG adapters driven through the C++ HardwareManager.

import { api } from '../api.js';
import { $, reportError, setStatus, toast } from '../ui.js';

const KIND_LABEL = { microcontroller: 'Microcontroller board', fpga: 'FPGA board', 'jtag-adapter': 'JTAG debug adapter' };
const STATE_BADGE = { connected: 'badge-ok', disconnected: 'badge-idle', faulted: 'badge-bad' };

let devices = [];
let streamTimer = null;

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function card(d) {
  const caps = d.capabilities.map((c) => `<tr><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.value)}</td></tr>`).join('');
  return `<div class="panel device" data-id="${d.id}">
    <div class="device-head">
      <div>
        <div class="device-kind">${KIND_LABEL[d.kind] || d.kind} · ${d.id}</div>
        <div class="device-model">${escapeHtml(d.model)}</div>
        <div class="device-link">${escapeHtml(d.hostLink)} · port ${escapeHtml(d.port)}</div>
      </div>
      <div style="text-align:right">
        <span class="badge ${STATE_BADGE[d.state] || 'badge-idle'}" data-role="state">${d.state}</span><br>
        ${d.simulated ? '<span class="tag tag-sim">SIMULATED</span>' : ''}
      </div>
    </div>
    <div class="device-error" data-role="error" ${d.lastError ? '' : 'hidden'}>${escapeHtml(d.lastError)}</div>
    <div class="btn-row">
      <button class="btn btn-small" data-act="connect">${d.state === 'faulted' ? 'Retry connect' : 'Connect'}</button>
      <button class="btn btn-small" data-act="disconnect">Disconnect</button>
      <button class="btn btn-small" data-act="telemetry">Read telemetry</button>
    </div>
    <div class="row">
      <select data-role="fault" aria-label="Fault to inject">
        <option value="connect-timeout">Next connect times out</option>
        <option value="telemetry-timeout">Next telemetry read times out</option>
      </select>
      <button class="btn btn-small btn-danger" data-act="fault">Inject fault</button>
    </div>
    <div class="telemetry"><table class="data compact" data-role="telemetry"><tbody><tr><td class="muted">No telemetry yet.</td></tr></tbody></table></div>
    <details><summary>Capabilities</summary><table class="data compact"><tbody>${caps}</tbody></table></details>
  </div>`;
}

function updateCard(status) {
  const root = document.querySelector(`.device[data-id="${status.id}"]`);
  if (!root) return;
  const badge = root.querySelector('[data-role="state"]');
  badge.textContent = status.state;
  badge.className = `badge ${STATE_BADGE[status.state] || 'badge-idle'}`;
  const error = root.querySelector('[data-role="error"]');
  error.hidden = !status.lastError;
  error.textContent = status.lastError;
  root.querySelector('[data-act="connect"]').textContent = status.state === 'faulted' ? 'Retry connect' : 'Connect';
  const d = devices.find((x) => x.id === status.id);
  if (d) Object.assign(d, status);
}

function showTelemetry(id, message) {
  const table = document.querySelector(`.device[data-id="${id}"] [data-role="telemetry"]`);
  const rows = message.fields.map((f) => `<tr><td>${escapeHtml(f.name)}</td><td>${Number.isInteger(f.value) && f.value > 255 ? '0x' + f.value.toString(16).toUpperCase() : f.value.toFixed(3)} ${escapeHtml(f.unit)}</td></tr>`).join('');
  table.innerHTML = `<tbody><tr><td>seq / t</td><td>#${message.sequence} · ${message.hostTimeS.toFixed(2)} s</td></tr>${rows}
    <tr><td>note</td><td>${escapeHtml(message.note)}</td></tr></tbody>`;
}

async function act(id, action, button) {
  const root = document.querySelector(`.device[data-id="${id}"]`);
  if (button) button.disabled = true;
  try {
    if (action === 'connect') {
      setStatus(`Connecting to ${id} (simulated)…`);
      const s = await api.post(`/api/hardware/${id}/connect`);
      updateCard(s);
      setStatus(s.state === 'connected' ? `${id} connected.` : `${id}: ${s.lastError}`, s.state !== 'connected');
    } else if (action === 'disconnect') {
      updateCard(await api.post(`/api/hardware/${id}/disconnect`));
      setStatus(`${id} disconnected.`);
    } else if (action === 'telemetry') {
      await readTelemetry(id, true);
    } else if (action === 'fault') {
      const kind = root.querySelector('[data-role="fault"]').value;
      updateCard(await api.post(`/api/hardware/${id}/fault`, { json: { kind } }));
      toast(`Fault armed on ${id}: ${kind}. Trigger it with the matching action.`);
    }
  } catch (err) {
    reportError(err, `${id} ${action}`);
  } finally {
    if (button) button.disabled = false;
    refreshLog();
  }
}

async function readTelemetry(id, verbose) {
  const r = await api.get(`/api/hardware/${id}/telemetry`);
  updateCard(r.status);
  if (r.ok) {
    showTelemetry(id, r.message);
    if (verbose) setStatus(`Telemetry #${r.message.sequence} from ${id} (simulated).`);
  } else if (verbose) {
    setStatus(`${id}: ${r.status.lastError || 'not connected; connect first.'}`, true);
  }
}

async function streamTick() {
  for (const d of devices.filter((x) => x.state === 'connected')) {
    try {
      await readTelemetry(d.id, false);
    } catch (err) {
      reportError(err, 'Telemetry poll');
    }
  }
  refreshLog();
  if ($('#hw-stream').checked) streamTimer = setTimeout(streamTick, 1000);
}

export async function discover() {
  try {
    devices = await api.get('/api/hardware/devices');
    $('#hw-devices').innerHTML = devices.map(card).join('');
    setStatus(`Discovered ${devices.length} simulated devices.`);
    refreshLog();
  } catch (err) {
    reportError(err, 'Discovery failed');
  }
}

export async function refreshLog() {
  try {
    const events = await api.get('/api/hardware/events');
    const log = $('#hw-log');
    log.innerHTML = events
      .map((e) => `<div class="lvl-${e.level}"><span class="t">${e.timeS.toFixed(2)} s</span> ${e.deviceId ? '[' + e.deviceId + '] ' : ''}${escapeHtml(e.message)}</div>`)
      .join('');
    log.scrollTop = log.scrollHeight;
  } catch (err) {
    /* log refresh is best effort */
  }
}

export async function initHardware() {
  $('#hw-discover').addEventListener('click', discover);
  $('#hw-log-refresh').addEventListener('click', refreshLog);
  $('#hw-devices').addEventListener('click', (e) => {
    const button = e.target.closest('button[data-act]');
    if (!button) return;
    act(button.closest('.device').dataset.id, button.dataset.act, button);
  });
  $('#hw-stream').addEventListener('change', (e) => {
    clearTimeout(streamTimer);
    if (e.target.checked) streamTick();
  });
  try {
    const svg = await fetch('assets/block_diagram.svg').then((r) => r.text());
    $('#hw-diagram').innerHTML = svg;
  } catch {
    $('#hw-diagram').textContent = 'Block diagram file missing (assets/block_diagram.svg).';
  }
}
