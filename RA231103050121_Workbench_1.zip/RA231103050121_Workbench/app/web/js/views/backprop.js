// Backprop view: hand-coded gradients, finite-difference check and loss curve.

import { api } from '../api.js';
import { renderPlot } from '../plot.js';
import { $, $all, downloadBlob, readNumbers, reportError, setStatus, toast } from '../ui.js';

const RULES = {
  x: { label: 'x' }, y: { label: 'y' }, w: { label: 'w' }, b: { label: 'b' }, v: { label: 'v' }, c: { label: 'c' },
  learningRate: { positive: true, max: 10, label: 'Learning rate' },
  epsilon: { positive: true, max: 0.01, label: 'FD epsilon' },
  steps: { integer: true, min: 1, max: 10000, label: 'Subsequent steps' },
};
let lastRequest = null;

const n = (v) => (Math.abs(v) < 1e-4 && v !== 0 ? v.toExponential(6) : v.toFixed(10));

function show(r) {
  const f = r.forward;
  $('#bp-forward tbody').innerHTML = `
    <tr><td>z = w·x + b</td><td>${n(f.z)}</td></tr>
    <tr><td>h = tanh(z)</td><td>${n(f.h)}</td></tr>
    <tr><td>ŷ = v·h + c</td><td>${n(f.yHat)}</td></tr>
    <tr><td>e = ŷ − y</td><td>${n(f.error)}</td></tr>
    <tr><td>J = ½e²</td><td>${n(f.loss)}</td></tr>`;
  const p0 = r.initial;
  const p1 = r.afterFirstUpdate;
  $('#bp-update tbody').innerHTML = ['w', 'b', 'v', 'c']
    .map((k) => `<tr><td>${k}: ${p0[k]} → </td><td>${n(p1[k])}</td></tr>`)
    .join('') + `<tr><td>J after update</td><td>${n(r.forwardAfterFirstUpdate.loss)}</td></tr>`;

  $('#bp-grad tbody').innerHTML = r.gradientCheck
    .map((g) => `<tr><td>∂J/∂${g.parameter}</td><td>${n(g.analytic)}</td><td>${n(g.finiteDifference)}</td>
      <td><span class="badge ${g.pass ? 'badge-ok' : 'badge-bad'}">${g.absError.toExponential(1)}</span></td></tr>`)
    .join('');
  $('#bp-check-badge').innerHTML = `<span class="badge ${r.gradientCheckPassed ? 'badge-ok' : 'badge-bad'}">${r.gradientCheckPassed ? 'all ≤ 1e-5' : 'check failed'}</span>`;
  $('#bp-direction').textContent =
    'All four gradients are negative because ŷ is below the target (e < 0). Gradient descent moves each parameter ' +
    'against its gradient, so w, b, v and c all increase, which raises ŷ toward y. ∂J/∂w equals ∂J/∂b here only because x = 1.';

  const steps = r.history.step;
  const loss = r.history.loss.map((v) => Math.max(v, 1e-300));
  renderPlot($('#bp-plot'), {
    xLabel: 'Gradient-descent step (0 = initial, 1 = hand-checked update)', yLabel: 'Loss J', yLog: true, legend: 'tr', xMin: 0, xMax: steps[steps.length - 1],
    series: [{ name: `loss, learning rate ${r.inputs.learningRate}`, x: steps, y: loss, color: '#1f5fae', markers: steps.length <= 120, markerSize: 2 }],
  });
  const last = r.finalLoss;
  $('#bp-summary').textContent =
    `J falls from ${f.loss.toFixed(4)} to ${last.toExponential(2)} after ${r.inputs.subsequentSteps} further steps. ` +
    'With one sample and four free parameters the network can fit y exactly, so the loss keeps shrinking towards zero; ' +
    'the straight tail on the log scale shows linear convergence near the minimum.';
}

async function run(event) {
  event?.preventDefault();
  let request;
  try {
    request = readNumbers($('#bp-form'), RULES);
  } catch (err) {
    setStatus(err.message, true);
    toast(err.message, 'error');
    return;
  }
  try {
    show(await api.post('/api/backprop', { json: request }));
    lastRequest = request;
    $all('[data-bp-export]').forEach((b) => (b.disabled = false));
    setStatus('Backprop check computed in C++.');
  } catch (err) {
    reportError(err, 'Backprop check failed');
  }
}

async function exportCsv(kind) {
  if (!lastRequest) return;
  try {
    const { blob, fileName } = await api.post('/api/backprop/export', { json: lastRequest, query: { kind } });
    downloadBlob(blob, fileName);
  } catch (err) {
    reportError(err, 'Export failed');
  }
}

export function initBackprop() {
  $('#bp-form').addEventListener('submit', run);
  $all('[data-bp-export]').forEach((b) => b.addEventListener('click', () => exportCsv(b.dataset.bpExport)));
}

export { run as runBackprop };
