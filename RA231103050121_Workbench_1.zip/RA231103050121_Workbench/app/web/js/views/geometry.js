// Geometry view: ASCII STL import and display.

import { api } from '../api.js';
import { $, MAX_UPLOAD_BYTES, fmt, fmtBytes, reportError, setFacts, setList, setStatus, toast, wireFileDrop } from '../ui.js';
import { Viewer3D } from '../viewer3d.js';

const UNIT_LABEL = { mm: 'mm', m: 'm', in: 'in' };
let viewer = null;
let current = null;
let wireframe = false;

function ensureViewer() {
  if (!viewer) viewer = new Viewer3D($('#stl-viewer'));
  return viewer;
}

function describe() {
  if (!current) return;
  const unit = UNIT_LABEL[$('#stl-unit').value];
  const size = current.bounds.size;
  setFacts($('#stl-facts'), [
    ['File', current.fileName],
    ['Size on disk', fmtBytes(current.fileBytes)],
    ['Solid name', current.solidName || '(none)'],
    ['Triangles', current.triangleCount.toLocaleString()],
    ['Extent X', `${fmt(size[0], 5)} ${unit}`],
    ['Extent Y', `${fmt(size[1], 5)} ${unit}`],
    ['Extent Z', `${fmt(size[2], 5)} ${unit}`],
    ['Min corner', current.bounds.min.map((v) => fmt(v, 4)).join(', ')],
    ['Max corner', current.bounds.max.map((v) => fmt(v, 4)).join(', ')],
    ['Parse time (C++)', `${current.parseMs.toFixed(1)} ms`],
  ]);
  viewer?.setOverlay(`${current.fileName} · ${current.triangleCount.toLocaleString()} triangles · ${fmt(size[0], 4)} × ${fmt(size[1], 4)} × ${fmt(size[2], 4)} ${unit}`);
}

function show(result) {
  current = result;
  const v = ensureViewer();
  v.setMesh(new Float32Array(result.vertices));
  v.setWireframe(wireframe);
  describe();
  setList($('#stl-warnings'), result.warnings);
  setStatus(`Loaded ${result.fileName}: ${result.triangleCount.toLocaleString()} triangles (parsed in ${result.parseMs.toFixed(1)} ms).`);
}

function showFailure(err, name) {
  setFacts($('#stl-facts'), [['Status', 'Import failed'], ['File', name]]);
  setList($('#stl-warnings'), [err.message + (err.line ? ` (line ${err.line})` : '')]);
  reportError(err, `Could not import ${name}`);
}

async function loadFile(file) {
  if (file.size > MAX_UPLOAD_BYTES) {
    showFailure(new Error(`File is ${fmtBytes(file.size)}; the tested limit is 64 MB.`), file.name);
    return;
  }
  setStatus(`Reading ${file.name}…`);
  try {
    const text = await file.text();
    setStatus(`Parsing ${file.name} in the backend…`);
    show(await api.post('/api/geometry/stl', { text, query: { name: file.name }, timeoutMs: 120000 }));
  } catch (err) {
    showFailure(err, file.name);
  }
}

async function loadExample() {
  const name = $('#stl-example').value;
  if (!name) return toast('No bundled STL example was found in the data folder.', 'error');
  setStatus(`Opening example ${name}…`);
  try {
    show(await api.get('/api/examples/stl', { query: { name } }));
  } catch (err) {
    showFailure(err, name);
  }
}

export function initGeometry(examples) {
  const select = $('#stl-example');
  select.innerHTML = examples.filter((e) => e.kind === 'stl').map((e) => `<option value="${e.name}">${e.name}</option>`).join('');
  wireFileDrop($('#stl-drop'), $('#stl-file'), loadFile);
  $('#stl-example-load').addEventListener('click', loadExample);
  $('#stl-unit').addEventListener('change', describe);
  $('#stl-fit').addEventListener('click', () => viewer?.fitToView());
  $('#stl-reset').addEventListener('click', () => viewer?.resetView());
  $('#stl-wire').addEventListener('click', () => {
    wireframe = !wireframe;
    $('#stl-wire').classList.toggle('btn-primary', wireframe);
    viewer?.setWireframe(wireframe);
  });
}

export function geometryLoadExampleForDemo() {
  return loadExample();
}
