// Thin wrapper around fetch for the local C++ backend. Every failure is turned
// into an Error whose message can be shown to the user as-is.

export class ApiError extends Error {
  constructor(message, status, line) {
    super(message);
    this.status = status;
    this.line = line;
  }
}

async function request(method, path, { json, text, timeoutMs = 60000, query } = {}) {
  const url = new URL(path, window.location.origin);
  if (query) Object.entries(query).forEach(([k, v]) => url.searchParams.set(k, v));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const init = { method, signal: controller.signal, headers: {} };
  if (json !== undefined) {
    init.body = JSON.stringify(json);
    init.headers['Content-Type'] = 'application/json';
  } else if (text !== undefined) {
    init.body = text;
    init.headers['Content-Type'] = 'text/plain; charset=utf-8';
  }
  let response;
  try {
    response = await fetch(url, init);
  } catch (err) {
    if (err.name === 'AbortError') throw new ApiError(`The backend did not answer within ${timeoutMs / 1000} s.`, 0);
    throw new ApiError('Cannot reach the workbench backend. Is Launch.exe still running?', 0);
  } finally {
    clearTimeout(timer);
  }
  const type = response.headers.get('Content-Type') || '';
  if (!response.ok) {
    let message = `Request failed (${response.status}).`;
    let line;
    if (type.includes('application/json')) {
      const body = await response.json().catch(() => null);
      if (body && body.error) message = body.error;
      if (body && body.line) line = body.line;
    }
    throw new ApiError(message, response.status, line);
  }
  if (type.includes('application/json')) return response.json();
  if (type.includes('text/csv')) {
    const disposition = response.headers.get('Content-Disposition') || '';
    const match = /filename="([^"]+)"/.exec(disposition);
    return { blob: await response.blob(), fileName: match ? match[1] : 'export.csv' };
  }
  return response.text();
}

export const api = {
  get: (path, opts) => request('GET', path, opts),
  post: (path, opts) => request('POST', path, opts),
};
