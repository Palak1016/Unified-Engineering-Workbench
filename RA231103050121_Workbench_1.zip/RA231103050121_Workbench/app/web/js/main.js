// Entry point: tab switching, backend health check and view initialisation.

import { api } from './api.js';
import { exportSvg } from './plot.js';
import { $, $all, reportError, setStatus, toast } from './ui.js';
import { initGeometry } from './views/geometry.js';
import { initAnsys } from './views/ansys.js';
import { initThermal, solveFea } from './views/thermal.js';
import { initPerformance, loadSystemInfo } from './views/performance.js';
import { discover, initHardware } from './views/hardware.js';
import { initBackprop, runBackprop } from './views/backprop.js';

const firstVisit = new Set();

function showView(name) {
  $all('.tab').forEach((t) => t.classList.toggle('active', t.dataset.view === name));
  $all('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${name}`));
  try {
    localStorage.setItem('wb.view', name);
  } catch {
    /* storage unavailable: ignore */
  }
  if (!firstVisit.has(name)) {
    firstVisit.add(name);
    if (name === 'thermal') solveFea();
    if (name === 'hardware') discover();
    if (name === 'backprop') runBackprop();
    if (name === 'performance') loadSystemInfo();
  }
  window.dispatchEvent(new Event('resize'));
}

function wireTabs() {
  $all('.tab').forEach((tab) => tab.addEventListener('click', () => showView(tab.dataset.view)));
  $all('.subtab').forEach((tab) =>
    tab.addEventListener('click', () => {
      $all('.subtab').forEach((t) => t.classList.toggle('active', t === tab));
      $all('.sub').forEach((s) => s.classList.toggle('active', s.id === `sub-${tab.dataset.sub}`));
      window.dispatchEvent(new Event('resize'));
    }),
  );
  $all('[data-plot-export]').forEach((b) =>
    b.addEventListener('click', () => {
      const id = b.dataset.plotExport;
      const title = b.closest('.panel').querySelector('h2')?.textContent || id;
      if (!exportSvg($(`#${id}`), `${id}.svg`, title)) toast('Nothing to export yet.', 'error');
    }),
  );
}

async function checkBackend() {
  const pill = $('#backend-status');
  try {
    const health = await api.get('/api/health', { timeoutMs: 5000 });
    pill.textContent = 'Backend online';
    pill.className = 'pill pill-ok';
    $('#status-right').textContent = health.launchToReadyMs ? `Backend launch-to-ready ${health.launchToReadyMs.toFixed(0)} ms` : '';
    return true;
  } catch (err) {
    pill.textContent = 'Backend offline';
    pill.className = 'pill pill-bad';
    setStatus('The backend is not responding. Start Launch.exe again.', true);
    return false;
  }
}

async function main() {
  wireTabs();
  initThermal();
  initPerformance();
  initBackprop();
  await initHardware();
  const online = await checkBackend();
  let examples = [];
  if (online) {
    try {
      examples = await api.get('/api/examples');
    } catch (err) {
      reportError(err, 'Could not list example files');
    }
  }
  initGeometry(examples);
  initAnsys(examples);

  $('#exit-button').addEventListener('click', async () => {
    if (!window.confirm('Stop the workbench server? You can start it again with Launch.exe.')) return;
    try {
      await api.post('/api/shutdown');
    } catch {
      /* server may close the connection while answering */
    }
    document.body.innerHTML = '<main><div class="panel" style="max-width:520px;margin:80px auto"><h1>Workbench stopped</h1><p>The local server has shut down. You can close this tab. Run Launch.exe to start again.</p></div></main>';
  });

  setInterval(checkBackend, 15000);

  let saved = null;
  try {
    saved = localStorage.getItem('wb.view');
  } catch {
    saved = null;
  }
  const initial = new URLSearchParams(location.search).get('view') || saved || 'geometry';
  showView($(`.tab[data-view="${initial}"]`) ? initial : 'geometry');

  const readyMs = performance.now();
  setStatus(online ? `Ready. Interface loaded in ${readyMs.toFixed(0)} ms.` : 'Backend offline.', !online);
  if (online) api.post('/api/ui-ready', { json: { ms: readyMs } }).catch(() => {});
}

main().catch((err) => reportError(err, 'Start-up failed'));
