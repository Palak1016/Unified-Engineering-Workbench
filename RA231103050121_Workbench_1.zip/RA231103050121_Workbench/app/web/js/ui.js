// Shared interface helpers: status bar, toasts, form validation, downloads.

export function $(selector, root = document) {
  return root.querySelector(selector);
}
export function $all(selector, root = document) {
  return Array.from(root.querySelectorAll(selector));
}

export function setStatus(message, isError = false) {
  const el = $('#status-text');
  el.textContent = message;
  el.classList.toggle('error', isError);
}

export function toast(message, kind = '') {
  const host = $('#toast-host');
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = message;
  host.appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 8000 : 4000);
}

export function reportError(err, context) {
  const where = err.line ? ` (line ${err.line})` : '';
  const message = `${context}: ${err.message}${where}`;
  setStatus(message, true);
  toast(message, 'error');
  console.error(message);
}

// Validates text inputs against simple rules and returns parsed numbers.
// rules: { name: { min, max, integer, positive, label } }
export function readNumbers(form, rules) {
  const values = {};
  let firstBad = null;
  for (const [name, rule] of Object.entries(rules)) {
    // querySelector, not form.elements[name]: a field called "length" would
    // otherwise resolve to the collection's length property.
    const input = form.querySelector(`[name="${name}"]`);
    const raw = input.value.trim();
    const value = Number(raw);
    let problem = null;
    if (raw === '' || !Number.isFinite(value)) problem = 'Enter a finite number.';
    else if (rule.integer && !Number.isInteger(value)) problem = 'Enter a whole number.';
    else if (rule.positive && value <= 0) problem = 'Must be greater than zero.';
    else if (rule.min !== undefined && value < rule.min) problem = `Must be at least ${rule.min}.`;
    else if (rule.max !== undefined && value > rule.max) problem = `Must be at most ${rule.max}.`;
    markField(input, problem);
    if (problem && !firstBad) firstBad = `${rule.label || name}: ${problem}`;
    values[name] = value;
  }
  if (firstBad) throw new Error(firstBad);
  return values;
}

export function markField(input, problem) {
  input.classList.toggle('invalid', !!problem);
  let note = input.parentElement.querySelector('.field-error');
  if (problem) {
    if (!note) {
      note = document.createElement('div');
      note.className = 'field-error';
      input.parentElement.appendChild(note);
    }
    note.textContent = problem;
  } else if (note) {
    note.remove();
  }
}

export function downloadBlob(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function fmt(value, digits = 4) {
  if (value === null || value === undefined || Number.isNaN(value)) return '–';
  if (value === 0) return '0';
  const abs = Math.abs(value);
  if (abs >= 1e5 || abs < 1e-3) return value.toExponential(digits - 1);
  return Number(value.toPrecision(digits)).toString();
}

export function fmtBytes(bytes) {
  if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${bytes} B`;
}

export function setFacts(dl, entries) {
  dl.innerHTML = '';
  for (const [key, value] of entries) {
    const dt = document.createElement('dt');
    dt.textContent = key;
    const dd = document.createElement('dd');
    dd.textContent = value;
    dl.append(dt, dd);
  }
}

export function setList(ul, items, cls = '') {
  ul.innerHTML = '';
  for (const item of items) {
    const li = document.createElement('li');
    if (cls) li.className = cls;
    li.textContent = item;
    ul.appendChild(li);
  }
}

// Wires a .file-drop label for both click-to-browse and drag-and-drop.
export function wireFileDrop(label, input, onFile) {
  input.addEventListener('change', () => {
    if (input.files.length) onFile(input.files[0]);
    input.value = '';
  });
  label.addEventListener('dragover', (e) => {
    e.preventDefault();
    label.classList.add('dragging');
  });
  label.addEventListener('dragleave', () => label.classList.remove('dragging'));
  label.addEventListener('drop', (e) => {
    e.preventDefault();
    label.classList.remove('dragging');
    if (e.dataTransfer.files.length) onFile(e.dataTransfer.files[0]);
  });
}

export const MAX_UPLOAD_BYTES = 64 * 1024 * 1024;
