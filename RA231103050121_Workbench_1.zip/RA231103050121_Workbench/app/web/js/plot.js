// Small SVG line/scatter plotter with linear or log axes, legend, hover
// read-out and standalone SVG export. Written for this project to avoid a
// large charting dependency; styling is done with attributes so exported
// files look the same outside the app.

const NS = 'http://www.w3.org/2000/svg';
export const COLORS = ['#1f5fae', '#d9480f', '#2b8a3e', '#7048e8', '#c2255c', '#0b7285', '#5c940d', '#495057'];

const SUPERSCRIPT = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };

function el(name, attrs = {}, parent) {
  const node = document.createElementNS(NS, name);
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  if (parent) parent.appendChild(node);
  return node;
}

function niceStep(range, target) {
  const raw = range / Math.max(1, target);
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const nice = norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10;
  return nice * mag;
}

function linearTicks(min, max, target) {
  const step = niceStep(max - min, target);
  const ticks = [];
  for (let v = Math.ceil(min / step - 1e-9) * step; v <= max + step * 1e-9; v += step) {
    ticks.push(Math.abs(v) < step * 1e-9 ? 0 : v);
  }
  return ticks;
}

function formatLinear(v, step) {
  const decimals = Math.max(0, -Math.floor(Math.log10(step) + 1e-9));
  if (Math.abs(v) >= 1e5 || (Math.abs(v) < 1e-3 && v !== 0)) return v.toExponential(1);
  return v.toFixed(Math.min(decimals, 6));
}

function formatPower(exp) {
  return '10' + String(exp).split('').map((c) => SUPERSCRIPT[c] ?? c).join('');
}

function extent(values, log) {
  let lo = Infinity;
  let hi = -Infinity;
  for (const v of values) {
    if (!Number.isFinite(v) || (log && v <= 0)) continue;
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  return [lo, hi];
}

function makeScale(min, max, log, pixelMin, pixelMax) {
  if (log) {
    const a = Math.log10(min);
    const b = Math.log10(max);
    return (v) => pixelMin + ((Math.log10(v) - a) / (b - a)) * (pixelMax - pixelMin);
  }
  return (v) => pixelMin + ((v - min) / (max - min)) * (pixelMax - pixelMin);
}

function domain(values, log, forcedMin, forcedMax, pad) {
  let [lo, hi] = extent(values, log);
  if (!Number.isFinite(lo)) return log ? [1, 10] : [0, 1];
  if (forcedMin !== undefined) lo = forcedMin;
  if (forcedMax !== undefined) hi = forcedMax;
  if (log) {
    return [Math.pow(10, Math.floor(Math.log10(lo))), Math.pow(10, Math.ceil(Math.log10(hi)))];
  }
  if (lo === hi) {
    lo -= 1;
    hi += 1;
  }
  const span = hi - lo;
  if (pad) {
    if (forcedMin === undefined) lo -= span * 0.04;
    if (forcedMax === undefined) hi += span * 0.04;
  }
  const step = niceStep(hi - lo, 6);
  return [
    forcedMin !== undefined ? lo : Math.floor(lo / step) * step,
    forcedMax !== undefined ? hi : Math.ceil(hi / step) * step,
  ];
}

/**
 * Draws a plot into `container`, replacing previous content.
 * spec: { xLabel, yLabel, xLog, yLog, xMin, xMax, yMin, yMax, legend: 'tr'|'tl'|'br'|'bl'|'none',
 *         series: [{ name, x: [], y: [], color, line: true, markers: false, dash, width }] }
 */
export function renderPlot(container, spec) {
  container.__plotSpec = spec;
  if (!container.__observer) {
    let frame = 0;
    container.__observer = new ResizeObserver(() => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => container.__plotSpec && draw(container, container.__plotSpec));
    });
    container.__observer.observe(container);
  }
  draw(container, spec);
}

function draw(container, spec) {
  const width = Math.max(320, container.clientWidth);
  const height = Math.max(200, container.clientHeight);
  container.innerHTML = '';
  const svg = el('svg', { viewBox: `0 0 ${width} ${height}`, width, height, xmlns: NS, 'font-family': 'Segoe UI, Arial, sans-serif' }, container);
  el('rect', { x: 0, y: 0, width, height, fill: '#ffffff' }, svg);

  const m = { left: 66, right: 16, top: 14, bottom: 46 };
  const pw = width - m.left - m.right;
  const ph = height - m.top - m.bottom;

  const allX = spec.series.flatMap((s) => s.x);
  const allY = spec.series.flatMap((s) => s.y);
  const [x0, x1] = domain(allX, spec.xLog, spec.xMin, spec.xMax, false);
  const [y0, y1] = domain(allY, spec.yLog, spec.yMin, spec.yMax, true);
  const sx = makeScale(x0, x1, spec.xLog, m.left, m.left + pw);
  const sy = makeScale(y0, y1, spec.yLog, m.top + ph, m.top);

  // Grid and ticks
  const grid = el('g', { stroke: '#e9edf2', 'stroke-width': 1 }, svg);
  const labels = el('g', { fill: '#4a5868', 'font-size': 11 }, svg);
  const xt = spec.xLog ? logTicks(x0, x1, Math.max(3, Math.floor(pw / 60))) : linearTicks(x0, x1, Math.max(3, Math.floor(pw / 90)));
  const yt = spec.yLog ? logTicks(y0, y1, Math.max(3, Math.floor(ph / 28))) : linearTicks(y0, y1, Math.max(3, Math.floor(ph / 50)));
  const xStep = xt.length > 1 ? xt[1] - xt[0] : 1;
  const yStep = yt.length > 1 ? yt[1] - yt[0] : 1;
  for (const t of xt) {
    const x = sx(t);
    el('line', { x1: x, x2: x, y1: m.top, y2: m.top + ph }, grid);
    const label = el('text', { x, y: m.top + ph + 16, 'text-anchor': 'middle' }, labels);
    label.textContent = spec.xLog ? formatPower(Math.round(Math.log10(t))) : formatLinear(t, xStep);
  }
  for (const t of yt) {
    const y = sy(t);
    el('line', { x1: m.left, x2: m.left + pw, y1: y, y2: y }, grid);
    const label = el('text', { x: m.left - 7, y: y + 4, 'text-anchor': 'end' }, labels);
    label.textContent = spec.yLog ? formatPower(Math.round(Math.log10(t))) : formatLinear(t, yStep);
  }
  el('rect', { x: m.left, y: m.top, width: pw, height: ph, fill: 'none', stroke: '#9aa6b5', 'stroke-width': 1 }, svg);

  const xl = el('text', { x: m.left + pw / 2, y: height - 8, 'text-anchor': 'middle', 'font-size': 12, fill: '#1d2733' }, svg);
  xl.textContent = spec.xLabel || '';
  const yl = el('text', {
    x: 0, y: 0, transform: `translate(15 ${m.top + ph / 2}) rotate(-90)`, 'text-anchor': 'middle', 'font-size': 12, fill: '#1d2733',
  }, svg);
  yl.textContent = spec.yLabel || '';

  // Data
  const clipId = `clip${Math.random().toString(36).slice(2, 8)}`;
  const defs = el('defs', {}, svg);
  const clip = el('clipPath', { id: clipId }, defs);
  el('rect', { x: m.left, y: m.top, width: pw, height: ph }, clip);
  const plotArea = el('g', { 'clip-path': `url(#${clipId})` }, svg);
  const points = [];
  spec.series.forEach((s, i) => {
    const color = s.color || COLORS[i % COLORS.length];
    const valid = [];
    for (let k = 0; k < s.x.length; k++) {
      const xv = s.x[k];
      const yv = s.y[k];
      if (!Number.isFinite(xv) || !Number.isFinite(yv)) continue;
      if ((spec.xLog && xv <= 0) || (spec.yLog && yv <= 0)) continue;
      valid.push([sx(xv), sy(yv), xv, yv]);
    }
    if (s.line !== false && valid.length > 1) {
      el('polyline', {
        points: valid.map((p) => `${p[0].toFixed(2)},${p[1].toFixed(2)}`).join(' '),
        fill: 'none', stroke: color, 'stroke-width': s.width || 1.8, 'stroke-dasharray': s.dash || '',
        'stroke-linejoin': 'round',
      }, plotArea);
    }
    if (s.markers) {
      const g = el('g', { fill: '#ffffff', stroke: color, 'stroke-width': 1.5 }, plotArea);
      const r = s.markerSize || 3;
      for (const p of valid) el('circle', { cx: p[0].toFixed(2), cy: p[1].toFixed(2), r }, g);
    }
    for (const p of valid) points.push({ px: p[0], py: p[1], x: p[2], y: p[3], name: s.name, color });
  });

  // Legend
  const named = spec.series.filter((s) => s.name && !s.hideInLegend);
  if (named.length && spec.legend !== 'none') {
    const rowH = 17;
    const boxW = Math.min(240, 34 + Math.max(...named.map((s) => s.name.length)) * 6.4);
    const boxH = named.length * rowH + 8;
    const pos = spec.legend || 'tr';
    const lx = pos.includes('l') ? m.left + 8 : m.left + pw - boxW - 8;
    const ly = pos.includes('b') ? m.top + ph - boxH - 8 : m.top + 8;
    const g = el('g', { 'font-size': 11, fill: '#1d2733' }, svg);
    el('rect', { x: lx, y: ly, width: boxW, height: boxH, fill: '#ffffff', 'fill-opacity': 0.92, stroke: '#dde3ea', rx: 4 }, g);
    named.forEach((s) => {
      const i = spec.series.indexOf(s);
      const color = s.color || COLORS[i % COLORS.length];
      const k = named.indexOf(s);
      const y = ly + 4 + rowH * k + rowH / 2;
      if (s.line !== false) el('line', { x1: lx + 8, x2: lx + 26, y1: y, y2: y, stroke: color, 'stroke-width': 2, 'stroke-dasharray': s.dash || '' }, g);
      if (s.markers) el('circle', { cx: lx + 17, cy: y, r: 3, fill: '#fff', stroke: color, 'stroke-width': 1.5 }, g);
      const t = el('text', { x: lx + 32, y: y + 4 }, g);
      t.textContent = s.name;
    });
  }

  // Hover read-out
  const tip = document.createElement('div');
  tip.className = 'tooltip';
  container.appendChild(tip);
  const marker = el('circle', { r: 5, fill: 'none', stroke: '#1d2733', 'stroke-width': 1.5, visibility: 'hidden' }, svg);
  svg.addEventListener('mousemove', (event) => {
    const rect = svg.getBoundingClientRect();
    const mx = ((event.clientX - rect.left) / rect.width) * width;
    const my = ((event.clientY - rect.top) / rect.height) * height;
    let best = null;
    let bestD = 900; // 30 px radius
    for (const p of points) {
      const d = (p.px - mx) ** 2 + (p.py - my) ** 2;
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    if (!best) {
      tip.style.display = 'none';
      marker.setAttribute('visibility', 'hidden');
      return;
    }
    marker.setAttribute('cx', best.px);
    marker.setAttribute('cy', best.py);
    marker.setAttribute('visibility', 'visible');
    tip.style.display = 'block';
    tip.style.left = `${(best.px / width) * rect.width}px`;
    tip.style.top = `${(best.py / height) * rect.height}px`;
    tip.textContent = `${best.name ? best.name + ': ' : ''}x=${fmtTip(best.x)}, y=${fmtTip(best.y)}`;
  });
  svg.addEventListener('mouseleave', () => {
    tip.style.display = 'none';
    marker.setAttribute('visibility', 'hidden');
  });
  return svg;
}

function fmtTip(v) {
  const a = Math.abs(v);
  return a !== 0 && (a < 1e-3 || a >= 1e5) ? v.toExponential(4) : Number(v.toPrecision(6)).toString();
}

function logTicks(min, max, maxTicks = 8) {
  const lo = Math.round(Math.log10(min));
  const hi = Math.round(Math.log10(max));
  const every = Math.max(1, Math.ceil((hi - lo + 1) / maxTicks)); // thin labels on wide ranges
  const ticks = [];
  for (let e = lo; e <= hi; e++) if ((e - lo) % every === 0) ticks.push(Math.pow(10, e));
  return ticks;
}

export function exportSvg(container, fileName, title) {
  const svg = container.querySelector('svg');
  if (!svg) return false;
  const clone = svg.cloneNode(true);
  if (title) {
    const t = document.createElementNS(NS, 'title');
    t.textContent = title;
    clone.insertBefore(t, clone.firstChild);
  }
  const text = '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(clone);
  const blob = new Blob([text], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return true;
}
