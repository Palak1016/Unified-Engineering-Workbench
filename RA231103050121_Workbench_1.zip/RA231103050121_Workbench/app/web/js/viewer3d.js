// three.js wrapper used by the Geometry and ANSYS-results views.
// Rendering only: all parsing and validation happened in the C++ backend.

import * as THREE from 'three';
import { OrbitControls } from '../vendor/three/OrbitControls.js';

// Blue -> cyan -> green -> yellow -> red, similar to the default contour map
// in most FE post-processors so the picture reads as expected.
const STOPS = [
  [0.0, [0.13, 0.25, 0.80]],
  [0.25, [0.10, 0.70, 0.90]],
  [0.5, [0.25, 0.80, 0.30]],
  [0.75, [0.98, 0.82, 0.10]],
  [1.0, [0.86, 0.15, 0.10]],
];

export function colormap(t) {
  t = Math.min(1, Math.max(0, t));
  for (let i = 1; i < STOPS.length; i++) {
    if (t <= STOPS[i][0]) {
      const [t0, c0] = STOPS[i - 1];
      const [t1, c1] = STOPS[i];
      const f = (t - t0) / (t1 - t0);
      return [c0[0] + f * (c1[0] - c0[0]), c0[1] + f * (c1[1] - c0[1]), c0[2] + f * (c1[2] - c0[2])];
    }
  }
  return STOPS[STOPS.length - 1][1];
}

export function colormapCss() {
  return `linear-gradient(to top, ${STOPS.map(([t, c]) => `rgb(${c.map((v) => Math.round(v * 255)).join(',')}) ${t * 100}%`).join(', ')})`;
}

export class Viewer3D {
  constructor(container) {
    this.container = container;
    this.object = null;
    this.onPick = null;
    try {
      this.renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    } catch (err) {
      container.innerHTML = '<div class="viewer-empty">WebGL is not available in this browser, so the 3D view cannot be shown. Try an up-to-date Edge or Chrome.</div>';
      this.failed = true;
      return;
    }
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0xfbfcfd);
    container.innerHTML = '';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(40, 1, 0.01, 1000);
    this.scene.add(this.camera);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.6));
    const key = new THREE.DirectionalLight(0xffffff, 1.4);
    key.position.set(1, 2, 3);
    this.camera.add(key); // light follows the camera so every side is readable

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = false;
    this.controls.screenSpacePanning = true;
    this.controls.addEventListener('change', () => this.render());

    this.overlay = document.createElement('div');
    this.overlay.className = 'viewer-overlay';
    this.overlay.hidden = true;
    container.appendChild(this.overlay);

    this.raycaster = new THREE.Raycaster();
    this.renderer.domElement.addEventListener('pointerdown', (e) => (this.downAt = [e.clientX, e.clientY]));
    this.renderer.domElement.addEventListener('pointerup', (e) => this.handleClick(e));

    new ResizeObserver(() => this.resize()).observe(container);
    this.resize();
  }

  resize() {
    if (this.failed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.render();
  }

  render() {
    if (!this.failed) this.renderer.render(this.scene, this.camera);
  }

  clear() {
    if (this.object) {
      this.scene.remove(this.object);
      this.object.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) o.material.dispose();
      });
      this.object = null;
    }
    if (this.highlight) {
      this.scene.remove(this.highlight);
      this.highlight = null;
    }
    if (this.axes) {
      this.scene.remove(this.axes);
      this.axes = null;
    }
    this.removeLegend();
  }

  setMesh(vertices) {
    if (this.failed) return;
    this.clear();
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.computeVertexNormals(); // non-indexed, so this gives flat facet normals
    geometry.computeBoundingSphere();
    const material = new THREE.MeshStandardMaterial({
      color: 0x8fa9c8, metalness: 0.15, roughness: 0.6, side: THREE.DoubleSide,
      polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1,
    });
    const group = new THREE.Group();
    group.add(new THREE.Mesh(geometry, material));
    // Feature edges help read the shape; skip them for very large meshes.
    if (vertices.length / 9 <= 200000) {
      const edges = new THREE.EdgesGeometry(geometry, 25);
      group.add(new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x33475e })));
    }
    this.object = group;
    this.mesh = group.children[0];
    this.scene.add(group);
    this.addAxes(geometry);
    this.resetView();
  }

  setWireframe(on) {
    if (this.mesh) {
      this.mesh.material.wireframe = on;
      this.render();
    }
  }

  setPointCloud(xyz, temperature, tMin, tMax, nodeIds) {
    if (this.failed) return;
    this.clear();
    const n = temperature.length;
    const positions = new Float32Array(n * 3);
    const colors = new Float32Array(n * 3);
    const span = tMax - tMin || 1;
    for (let i = 0; i < n; i++) {
      positions[3 * i] = xyz[3 * i];
      positions[3 * i + 1] = xyz[3 * i + 1];
      positions[3 * i + 2] = xyz[3 * i + 2];
      const c = colormap((temperature[i] - tMin) / span);
      colors[3 * i] = c[0];
      colors[3 * i + 1] = c[1];
      colors[3 * i + 2] = c[2];
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.computeBoundingSphere();
    const material = new THREE.PointsMaterial({ size: 5, sizeAttenuation: false, vertexColors: true });
    this.object = new THREE.Points(geometry, material);
    this.points = { xyz, temperature, nodeIds };
    this.scene.add(this.object);
    this.addAxes(geometry);
    this.addLegend(tMin, tMax, 'Temperature', '°C');
    this.resetView();
  }

  setPointSize(px) {
    if (this.object && this.object.isPoints) {
      this.object.material.size = px;
      this.render();
    }
  }

  addAxes(geometry) {
    const r = geometry.boundingSphere ? geometry.boundingSphere.radius : 1;
    this.axes = new THREE.AxesHelper(r * 0.35);
    const box = new THREE.Box3().setFromBufferAttribute(geometry.getAttribute('position'));
    this.axes.position.copy(box.min);
    this.scene.add(this.axes);
  }

  // Frames the current object while keeping the current viewing direction.
  fitToView() {
    if (!this.object) return;
    const sphere = new THREE.Box3().setFromObject(this.object).getBoundingSphere(new THREE.Sphere());
    const radius = Math.max(sphere.radius, 1e-9);
    const fov = THREE.MathUtils.degToRad(this.camera.fov);
    const distance = (radius / Math.sin(Math.min(fov, fov * this.camera.aspect) / 2)) * 1.08;
    const direction = new THREE.Vector3().subVectors(this.camera.position, this.controls.target).normalize();
    if (direction.lengthSq() === 0 || !Number.isFinite(direction.x)) direction.set(1, -1.2, 0.9).normalize();
    this.controls.target.copy(sphere.center);
    this.camera.position.copy(sphere.center).addScaledVector(direction, distance);
    this.camera.near = distance / 1000;
    this.camera.far = distance * 100;
    this.camera.updateProjectionMatrix();
    this.controls.update();
    this.render();
  }

  resetView() {
    if (!this.object) return;
    this.camera.up.set(0, 0, 1); // engineering convention: Z up
    this.camera.position.set(1, -1.4, 0.9);
    this.controls.target.set(0, 0, 0);
    this.fitToView();
  }

  handleClick(event) {
    if (!this.points || !this.downAt) return;
    const moved = Math.hypot(event.clientX - this.downAt[0], event.clientY - this.downAt[1]);
    if (moved > 4 || event.button !== 0) return; // a drag, not a click
    const rect = this.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.camera);
    // Threshold in world units equivalent to ~6 px at the target distance.
    const dist = this.camera.position.distanceTo(this.controls.target);
    const worldPerPixel = (2 * dist * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2)) / rect.height;
    this.raycaster.params.Points.threshold = worldPerPixel * 6;
    const hits = this.raycaster.intersectObject(this.object);
    if (!hits.length) return;
    hits.sort((a, b) => a.distanceToRay - b.distanceToRay);
    const i = hits[0].index;
    this.showHighlight(i);
    if (this.onPick) {
      const { xyz, temperature, nodeIds } = this.points;
      this.onPick({ index: i, nodeId: nodeIds[i], x: xyz[3 * i], y: xyz[3 * i + 1], z: xyz[3 * i + 2], t: temperature[i] });
    }
  }

  showHighlight(i) {
    if (this.highlight) this.scene.remove(this.highlight);
    const { xyz } = this.points;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute([xyz[3 * i], xyz[3 * i + 1], xyz[3 * i + 2]], 3));
    this.highlight = new THREE.Points(g, new THREE.PointsMaterial({ size: 16, sizeAttenuation: false, color: 0x111111, transparent: true, opacity: 0.45 }));
    this.scene.add(this.highlight);
    this.render();
  }

  setOverlay(text) {
    if (!this.overlay) return;
    this.overlay.hidden = !text;
    this.overlay.textContent = text || '';
  }

  addLegend(min, max, title, unit) {
    this.removeLegend();
    const legend = document.createElement('div');
    legend.className = 'legend';
    const ticks = [];
    for (let k = 4; k >= 0; k--) ticks.push(min + ((max - min) * k) / 4);
    legend.innerHTML = `<div class="legend-title">${title}<br>[${unit}]</div>
      <div class="legend-body"><div class="legend-bar" style="background:${colormapCss()}"></div>
      <div class="legend-ticks">${ticks.map((t) => `<span>${t.toFixed(Math.abs(max - min) < 10 ? 2 : 1)}</span>`).join('')}</div></div>`;
    this.container.appendChild(legend);
    this.legend = legend;
  }

  removeLegend() {
    if (this.legend) {
      this.legend.remove();
      this.legend = null;
    }
  }
}
