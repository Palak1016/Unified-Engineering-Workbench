# results/

Raw numbers and figures used in the report. Everything here can be regenerated
from the C++ command-line tool, so no value in the report is typed by hand.

| Folder / file | Produced by | Contents |
|---|---|---|
| `fea/fea_nodal_temperatures.csv` | `workbench_cli fea` | Nodal FE and exact temperatures for N = 10, 20, 40, 80 |
| `fea/fea_midpoint_errors.csv` | `workbench_cli fea` | FE interpolant vs exact at every element midpoint |
| `fea/fea_convergence.csv` | `workbench_cli fea` | Max nodal and midpoint error per mesh, observed order |
| `fea/fea_exact_curve.csv` | `workbench_cli fea` | 401 samples of the analytical solution, for plotting |
| `performance/benchmark_timings_<tag>.csv` | `workbench_cli benchmark --tag <tag>` or Performance view > Export CSV | Every measured run, median, speedup, efficiency, agreement |
| `performance/benchmark_report_<tag>.json` | `workbench_cli benchmark` | Same data plus machine description |
| `backprop/backprop_gradient_check.csv` | `workbench_cli backprop` | Analytic vs central-difference gradients |
| `backprop/backprop_loss_history.csv` | `workbench_cli backprop` | Parameters and loss for steps 0 to 101 |
| `import_size_tests.csv` | manual run, see header | Largest files tested and their load times |
| `figures/*.png` | `python tools/make_report_figures.py` | Labelled plots used in the report |

Units: metres, degrees Celsius, milliseconds. CSV files may start with `#`
comment lines describing the run; the header row follows them.

## Regenerating (Windows, from the extracted ZIP folder)

```
app\bin\workbench_cli.exe fea --out results\fea
app\bin\workbench_cli.exe backprop --out results\backprop
app\bin\workbench_cli.exe benchmark --out results\performance --tag windows
python tools\make_report_figures.py
```

The benchmark tagged `linux_container` was measured while developing, on a
2-vCPU cloud container. The `windows` tag is intended for the run on the
Windows 11 target machine.
