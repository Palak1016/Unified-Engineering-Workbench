# Example data: provenance, units and schema

Both files were created for this project by `workbench_cli make-examples`
(source: `src/backend/app/cli_main.cpp`, functions `heatSinkStl` and
`syntheticPlateCsv`). Neither file comes from a third party. Both are released
under CC0-1.0.

## geometry/heat_sink_7fin_mm.stl

| Item | Value |
|---|---|
| Format | ASCII STL, one solid named `heat_sink_7fin_mm` |
| Content | Finned heat sink: 60 x 40 x 5 base plate with seven 2 mm thick, 25 mm tall fins at 9 mm pitch |
| Units | millimetres (STL itself carries no unit; select "mm" in the Geometry view) |
| Size | 96 triangles, 11.7 KB |
| Construction | Eight axis-aligned boxes, 12 triangles each, outward normals. Fins sit on the base, so the touching faces are internal; the file is a valid triangle soup for display but not a single watertight shell. |
| Export notes | Equivalent to "Save as STL, ASCII" from any CAD tool. Binary STL is rejected by the importer. |

## results/synthetic_plate_temperatures.csv

**This file is SYNTHETIC. It is not an ANSYS export.** It uses the column
layout of a nodal temperature table exported from ANSYS Mechanical so the
importer can be exercised without a solver licence. The first three lines are
`#` comments that state this, and the viewer shows "SYNTHETIC" when the file is
loaded.

| Item | Value |
|---|---|
| Columns | `node_id,x_m,y_m,z_m,temperature_C` |
| Units | coordinates in metres, temperature in degrees Celsius |
| Nodes | 693 = 21 x 11 x 3 grid at 5 mm spacing |
| Domain | plate 0.10 x 0.05 x 0.01 m |
| Field | T = 25 + 60 exp(-r^2 / (2 * 0.015^2)) + 400 z, with r measured from (0.03, 0.025) m. A made-up hot spot plus a through-thickness gradient; it is not the solution of any heat equation. |
| Range | 25.0 to 89.0 °C |

### How a real ANSYS export would map to this schema

In ANSYS Mechanical, a Temperature result can be exported from the result's
context menu (Export > Text File). The exported table lists node number,
X/Y/Z location and temperature, with units taken from the active unit system.
To use it here: rename the headers to `node_id,x_m,y_m,z_m,temperature_C`,
make sure the unit system is metres and °C (or convert), and save as
comma-separated text. The importer warns when the model extent exceeds 100 m,
which usually means the coordinates are still in millimetres.

## tests/data/

Small hand-written fixtures for the unit tests, most of them deliberately
malformed (NaN, Inf, truncated, binary, duplicate ids, missing columns, ...).
They can also be loaded in the interface to see the error messages.
