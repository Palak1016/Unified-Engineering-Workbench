#!/usr/bin/env bash
# Builds the Windows x64 package on a Linux host with MinGW-w64.
# Packaging only: compiles the existing CMake targets and copies files.
#
#   tools/package_windows.sh <CandidateID>
#
# Output: dist/<CandidateID>_Workbench/ and dist/<CandidateID>_Workbench.zip
set -euo pipefail

ID="${1:-CandidateID}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME="${ID}_Workbench"
DIST="$ROOT/dist/$NAME"

cd "$ROOT"
if [ -n "$(git status --porcelain)" ]; then
    echo "Working tree has uncommitted changes; commit them first so the package matches the history." >&2
    exit 1
fi

echo "== Native build and tests"
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release > /dev/null
cmake --build build -j"$(nproc)"
(cd build && ctest --output-on-failure)

echo "== Windows cross-build"
cmake -S . -B build-win -DCMAKE_TOOLCHAIN_FILE=cmake/mingw-w64-x86_64.cmake \
      -DCMAKE_BUILD_TYPE=Release -DWB_STATIC_RUNTIME=ON > /dev/null
cmake --build build-win -j"$(nproc)"

echo "== Assembling $DIST"
rm -rf "$DIST" "$ROOT/dist/$NAME.zip"
mkdir -p "$DIST"
git archive --format=tar HEAD | tar -x -C "$DIST"      # committed sources only, relative paths

cp build-win/Launch.exe "$DIST/"
cp docs/Report.pdf "$DIST/Technical_Report.pdf"   # copy at the top level so reviewers find it first
mkdir -p "$DIST/app/bin" "$DIST/app/web"
cp build-win/workbench_cli.exe build-win/workbench_tests.exe "$DIST/app/bin/"
cp -r src/frontend/. "$DIST/app/web/"

mkdir -p "$DIST/vcs"
git bundle create "$DIST/vcs/workbench.bundle" --all
git log --date=iso --stat > "$DIST/vcs/commit_log.txt"
git log --date=short --format='%h %ad %s' > "$DIST/vcs/commit_summary.txt"

echo "== Zipping"
(cd "$ROOT/dist" && rm -f "$NAME.zip" && zip -qr -X "$NAME.zip" "$NAME")
ls -l "$ROOT/dist/$NAME.zip"
