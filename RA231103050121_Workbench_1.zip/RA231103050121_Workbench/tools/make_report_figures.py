"""Draws the report figures from the CSV/JSON files in results/.

Report tooling only: it reads numbers produced by the C++ workbench_cli and
does no computation of its own beyond plotting. Run from the project root:

    python tools/make_report_figures.py
"""

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
COLORS = ["#1f5fae", "#d9480f", "#2b8a3e", "#7048e8", "#c2255c"]

plt.rcParams.update({
    "font.size": 9,
    "axes.grid": True,
    "grid.color": "#e3e7ec",
    "axes.edgecolor": "#8a96a5",
    "figure.dpi": 150,
    "savefig.bbox": "tight",
})


def read_csv(path):
    with open(path, newline="") as f:
        rows = [line for line in f if not line.startswith("#")]
    return list(csv.DictReader(rows))


def fea_figures():
    nodal = read_csv(RESULTS / "fea" / "fea_nodal_temperatures.csv")
    exact = read_csv(RESULTS / "fea" / "fea_exact_curve.csv")
    mids = read_csv(RESULTS / "fea" / "fea_midpoint_errors.csv")
    conv = read_csv(RESULTS / "fea" / "fea_convergence.csv")
    meshes = sorted({int(r["mesh_elements"]) for r in nodal})

    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    ax.plot([float(r["x_m"]) for r in exact], [float(r["T_exact_C"]) for r in exact],
            color="#1d2733", lw=2.0, label="exact $T(x)$")
    for i, n in enumerate(meshes):
        rows = [r for r in nodal if int(r["mesh_elements"]) == n]
        ax.plot([float(r["x_m"]) for r in rows], [float(r["T_fe_C"]) for r in rows], ls="--", lw=1.0,
                marker="o" if n <= 20 else None, ms=3, mfc="white", color=COLORS[(i + 1) % len(COLORS)],
                label=f"FE, N = {n}")
    ax.set_xlabel("position $x$ [m]")
    ax.set_ylabel("temperature $T$ [°C]")
    ax.set_title("1D rod: FE solution vs exact (k = 10 W/(m·K), q = 10⁴ W/m³)")
    ax.legend(fontsize=8)
    fig.savefig(FIGURES / "fea_temperature.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    for i, n in enumerate(meshes):
        rows = [r for r in mids if int(r["mesh_elements"]) == n]
        ax.semilogy([float(r["x_mid_m"]) for r in rows], [float(r["abs_error_C"]) for r in rows],
                    marker="o", ms=2.5, lw=1.0, color=COLORS[(i + 1) % len(COLORS)], label=f"N = {n}")
    ax.set_xlabel("element midpoint $x$ [m]")
    ax.set_ylabel("|$T_{FE} - T_{exact}$| [°C]")
    ax.set_title("Error at element midpoints (FE interpolation)")
    ax.legend(fontsize=8, ncol=4)
    fig.savefig(FIGURES / "fea_midpoint_error.png")
    plt.close(fig)

    h = [float(r["h_m"]) for r in conv]
    e = [float(r["max_midpoint_error_C"]) for r in conv]
    en = [max(float(r["max_nodal_error_C"]), 1e-16) for r in conv]
    fig, ax = plt.subplots(figsize=(4.2, 3.2))
    ax.loglog(h, e, "o-", color=COLORS[0], label="max midpoint error")
    ax.loglog(h, [e[0] * (x / h[0]) ** 2 for x in h], "--", color="#868e96", label="slope 2 reference")
    ax.loglog(h, en, "s:", color=COLORS[1], ms=4, label="max nodal error")
    ax.set_xticks(h)
    ax.set_xticklabels([f"{x:g}" for x in h])
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel("element size $h$ [m]")
    ax.set_ylabel("max |error| [°C]")
    ax.set_title("Mesh convergence")
    ax.legend(fontsize=7.5)
    fig.savefig(FIGURES / "fea_convergence.png")
    plt.close(fig)


def benchmark_figures():
    for report_path in sorted((RESULTS / "performance").glob("benchmark_report*.json")):
        report = json.loads(report_path.read_text())
        tag = report_path.stem.replace("benchmark_report", "").strip("_") or "run"
        pool = [r for r in report["rows"] if r["workers"] > 0]
        serial = next(r for r in report["rows"] if r["workers"] == 0)
        p = [r["workers"] for r in pool]

        fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.6, 2.8))
        a1.plot(p, p, "--", color="#868e96", label="ideal")
        a1.plot(p, [r["speedup"] for r in pool], "o-", color=COLORS[0], label="measured")
        a1.set_xlabel("workers $p$")
        a1.set_ylabel("speedup $T_1/T_p$")
        a1.set_xticks(p)
        a1.legend(fontsize=8)
        a2.errorbar(p, [r["medianMs"] for r in pool],
                    yerr=[[r["medianMs"] - r["minMs"] for r in pool], [r["maxMs"] - r["medianMs"] for r in pool]],
                    fmt="o-", color=COLORS[1], capsize=3, label="worker pool (median, min-max)")
        a2.axhline(serial["medianMs"], color=COLORS[2], ls="--", lw=1, label="serial loop")
        a2.set_xlabel("workers $p$")
        a2.set_ylabel("compute time [ms]")
        a2.set_xticks(p)
        a2.set_ylim(bottom=0)
        a2.legend(fontsize=7.5)
        cfg = report["config"]
        fig.suptitle(f"{cfg['cases']} cases × {cfg['elements']} elements, {cfg['measuredRuns']} runs "
                     f"({report['system']['cpuModel']})", fontsize=8.5)
        fig.tight_layout()
        fig.savefig(FIGURES / f"benchmark_{tag}.png")
        plt.close(fig)


def backprop_figure():
    rows = read_csv(RESULTS / "backprop" / "backprop_loss_history.csv")
    steps = [int(r["step"]) for r in rows]
    loss = [float(r["loss"]) for r in rows]
    fig, ax = plt.subplots(figsize=(4.6, 2.8))
    ax.semilogy(steps, loss, "-", color=COLORS[0])
    ax.semilogy(steps[:2], loss[:2], "o", color=COLORS[1], ms=4, label="initial and hand-checked step")
    ax.set_xlabel("gradient-descent step (learning rate 0.1)")
    ax.set_ylabel("loss $J$")
    ax.set_title("Training loss, x = 1, y = 2")
    ax.legend(fontsize=7.5)
    fig.savefig(FIGURES / "backprop_loss.png")
    plt.close(fig)


if __name__ == "__main__":
    FIGURES.mkdir(parents=True, exist_ok=True)
    fea_figures()
    benchmark_figures()
    backprop_figure()
    for path in sorted(FIGURES.glob("*.png")):
        print("wrote", path.relative_to(ROOT).as_posix())
