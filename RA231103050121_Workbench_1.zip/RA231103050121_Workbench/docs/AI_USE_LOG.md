# AI-use log

AI assistance was used heavily in this submission. This log records what was
used, how, what came out, how it was checked, and where the AI got things wrong.

## Tools and models

| Tool | Model | Used for |
|---|---|---|
| Claude, Cowork mode in the Claude desktop app (Anthropic) | Claude Opus 5.5 (`claude-opus-5-5`) | Reading the assignment PDF, planning the architecture, writing the C++ backend, tests, frontend, build and packaging scripts, documentation and the report draft; running the builds, tests and UI checks in a cloud Linux sandbox |

No other AI tools were used for the material in this repository. The Claude
session ID is recorded in the trailer of each commit (`Claude-Session:`), and
every AI-written commit carries `Co-Authored-By: Claude`.

## Representative prompts and refinement

**Prompt 1 (initial request, verbatim, with the assignment PDF attached):**

> This is the project, go through the requirements thouroughly uploaded on the attachtmen and make the project accurately with properly formatted doc and it shouldnt look like it is AI generated. Keep the text professional and with correct formatting while making the doc.

**Clarifying questions asked by the assistant, and the answers given:**

| Question | Answer |
|---|---|
| Candidate name and ID for the ZIP, README and report? | Leave both out for now; to be supplied before the final document. |
| Interface: local browser UI started by Launch.exe, or a native desktop window? | Local browser UI. |
| Report format? | Word and PDF. |

Refinement during the session was driven by test results rather than new
prompts: each failing test or broken screenshot led to a change, listed below.

*(Candidate: add any later prompts you use, for example asking for
explanations of the FEA assembly or the chain rule, below this line.)*

## Relevant outputs

- C++17 core library: STL and CSV readers, 1D FEA solver, worker pool and
  benchmark, device mocks, backprop (`src/backend/core/`).
- HTTP transport, launcher and CLI (`src/backend/server/`, `src/backend/app/`).
- Browser interface (`src/frontend/`), including a small SVG plotting module.
- 53 unit tests and malformed-file fixtures (`tests/`).
- CMake build, MinGW cross-compile toolchain and packaging script.
- README, build guide, embedded design, provenance notes, this log, the report.

## Validation evidence

| Check | How | Result |
|---|---|---|
| Unit tests (Linux build) | `ctest` | 53/53 pass |
| Unit tests (Windows build) | `workbench_tests.exe` under Wine 9.0 | 53/53 pass |
| FEA against theory | midpoint error compared with q h^2 / (8k); observed order | exact match to 1e-9; order 2.0000 |
| Gradients | central differences, epsilon 1e-6 | all four within 1.1e-10 |
| Serial vs parallel | max abs temperature difference over all runs | 0.0 (bitwise identical) |
| Windows binary dependencies | `objdump -p Launch.exe` | system DLLs only |
| Interface | scripted browser walkthrough (Playwright), screenshots checked by eye | `docs/walkthrough/` |
| Large inputs | 66 MB STL (500k triangles), 38 MB CSV (1M nodes) through the UI | accepted, 4.6 s and 2.7 s |

## Incorrect or unsuitable AI output that was caught

1. **Wrong hand-calculated gradient in a test.** The first version of
   `bp_analytic_gradients_hand_values` expected dJ/dv = -0.7106860884 and
   dJ/dw = -1.2094689150. Both were arithmetic slips; the C++ value and the
   central-difference check agreed on -0.7106820475 and -1.2094644752. The test
   failed, the expected values were corrected (commit "Add unit tests and
   malformed-file fixtures").
2. **Form lookup bug in the interface.** Validation read inputs with
   `form.elements[name]`. For the field named `length` this returns the number
   of controls in the form, not the Length input, so the Solve button threw
   "Cannot read properties of undefined". Found in the first browser
   screenshot run; fixed by looking fields up with `querySelector('[name=...]')`.
3. **Tridiagonal solve that ignored the assembled matrix.** The first draft of
   the Thomas algorithm overwrote the off-diagonal array with the modified
   coefficients and then used a hard-coded `-kA/h` for the sub-diagonal. The
   numbers were right only because every element in this problem has the same
   stiffness; a non-uniform mesh or varying k would have broken it silently.
   Rewritten to read the assembled entries and keep the modified coefficients
   in a separate `cprime` array, before the tests were written.
4. **Launch-to-ready on Linux reported 0.0 ms.** `/proc` start times have 10 ms
   resolution, so the difference was often zero. Now the larger of that and the
   time since static initialisation is used. (Windows uses `GetProcessTimes`,
   which does not have this problem.)
5. **Unreadable log axis.** The convergence plot printed a label for every
   decade from 1e-14 to 1e1 and the labels overlapped. Tick labels are now
   thinned to fit the plot height.
6. **Machine-specific path in the log.** The server log printed the absolute
   path of the log file, which would have put a local path into the submitted
   walkthrough. Changed to a path relative to Launch.exe.

## What the candidate is responsible for

AI output was accepted only where it could be checked by a test, a known
analytical result or a visible result in the interface. The candidate should
be able to explain and modify any function in `src/backend/core/`, reproduce
the tests, and must write the backpropagation appendix by hand.

*(Candidate: record your own review, edits and any extra checks here.)*
