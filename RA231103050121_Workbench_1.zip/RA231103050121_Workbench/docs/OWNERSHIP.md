# Ownership statement

## Reused work (not written for this project)

| Component | Origin | Licence | How it is used |
|---|---|---|---|
| `third_party/httplib/httplib.h` | cpp-httplib 0.18.3, Yuji Hirose | MIT | unmodified; HTTP server in the transport layer |
| `third_party/nlohmann/json.hpp` | nlohmann/json 3.11.3, Niels Lohmann | MIT | unmodified; JSON encoding in the transport layer |
| `src/frontend/vendor/three/three.module.min.js`, `OrbitControls.js` | three.js r160 | MIT | unmodified; WebGL rendering and camera controls |
| MinGW-w64 GCC runtime | GCC / MinGW-w64 projects | GPLv3 + GCC Runtime Library Exception; winpthreads MIT | statically linked into the executables |

No code was copied from tutorials, forums or other repositories.

## Original work for this project

Everything else in `src/`, `tests/`, `tools/`, `cmake/`, `.vscode/`, `data/`
and `docs/` was written for this assignment, with substantial AI assistance as
described in `docs/AI_USE_LOG.md`. This includes the STL and CSV parsers, the
FEA solver and its verification, the worker pool and benchmark, the device
mocks, the backpropagation code, the HTTP routes, the interface and plotting
code, the example data, and all documentation.

The handwritten backpropagation appendix is the candidate's own work.
