# Embedded-system integration design

Scope: one microcontroller board, one FPGA board and one JTAG debug adapter,
connected to a Windows host that runs the workbench. Physical wiring, firmware
and FPGA programming are out of scope; the software side is implemented as C++
mock adapters (`src/backend/core/hardware/`) and every value they produce is
labelled SIMULATED.

The board classes below (Cortex-M4 class MCU board, Artix-7 class FPGA board,
FT2232H-class JTAG adapter) were chosen as typical examples. Every pin and
voltage marked *assumed* must be checked against the schematic of the actual
boards before anything is wired.

## 1. Block diagram

![Block diagram](block_diagram.svg)

(`docs/block_diagram.svg`; the same drawing appears in the Hardware view.)

## 2. Interface and pin-voltage table

| # | Link | Signals | Voltage domain | Connector (assumed) | Who drives | Notes |
|---|---|---|---|---|---|---|
| 1 | Host PC to hub | USB 2.0 D+/D-, VBUS, GND | 5 V VBUS, 3.3 V differential data | USB-A or USB-C | host | Powered hub with its own 5 V supply so the boards do not load the PC port. |
| 2 | Hub to MCU board | USB D+/D-, VBUS, GND | 5 V in, on-board LDO to 3.3 V | micro-USB / USB-C | hub (power), host (data) | Enumerates as USB CDC-ACM (virtual COM port). Budget about 100 to 200 mA. |
| 3 | Hub to FPGA board | USB D+/D- to USB-UART bridge, VBUS, GND | 5 V in; board regulators make VCCINT 1.0 V, VCCAUX 1.8 V, VCCO 1.8 or 3.3 V | micro-USB / USB-C; barrel jack if the board needs more than the port can give | hub / external supply | Data-only UART bridge. If the board has a built-in USB-JTAG circuit, see row 6. |
| 4 | Hub to JTAG adapter | USB D+/D-, VBUS, GND | 5 V; adapter I/O buffered to target VREF | USB-B / micro-USB | hub | The adapter is powered by USB and never powers the target. |
| 5 | JTAG adapter to FPGA JTAG header | TCK, TMS, TDI (adapter out); TDO (adapter in); VREF (sense); GND | follows target VREF, typically 3.3 V or 1.8 V (assumed 3.3 V) | 2x7 2.0 mm or 1x6 2.54 mm header, board-specific | adapter drives TCK/TMS/TDI; FPGA drives TDO | VREF comes from the target; no VREF means no target power, so the adapter must not drive. At least one GND pin per signal group. |
| 6 | Signal ownership | TAP signals on the FPGA header | as row 5 | as row 5 | exactly one master | If the FPGA board has an on-board USB-JTAG programmer, it shares the same TAP. Only one of them may drive TCK/TMS/TDI at a time; disable the on-board one (jumper or no USB) before attaching the external adapter. |
| 7 | MCU to FPGA data link | 2 to 4 GPIO or a UART pair (TX/RX) | MCU 3.3 V; FPGA bank VCCO 1.8 V or 3.3 V (assumed 1.8 V) | jumper wires / ribbon to a user header (Pmod-style) | both, one direction per pin | If the bank is at 1.8 V, a level shifter is required (direction-fixed translator for UART, auto-direction for slow GPIO). Series resistors 33 to 100 ohm on each line. |
| 8 | MCU debug header | SWDIO, SWCLK, (SWO), nRESET, VTref, GND | 3.3 V | 10-pin 1.27 mm Cortex debug | a separate SWD probe, not the FPGA's JTAG adapter | Kept out of the TAP chain; listed so nobody plugs the FPGA adapter into it by mistake. |
| 9 | Ground | GND on every cable | 0 V reference | all connectors | n/a | All boards meet the hub ground at one point. Connect ground before signal lines. Avoid extra ground paths through separately mains-powered bench supplies. |

## 3. Why the JTAG adapter is not "another board"

A JTAG adapter is a bridge from USB to the IEEE 1149.1 test access port of
some other device. It shifts bits into and out of the target's TAP when the
host tells it to. It has no workload of its own, no user program, and no useful
state without a target: its I/O voltage even comes from the target's VREF pin.
So it cannot be treated like the MCU or FPGA boards, which run firmware or a
loaded design and produce data.

In the software this shows up as a different capability set. The JTAG mock
reports `role = debug and programming interface only` and a `target`
relationship (currently the FPGA header), and its telemetry describes the scan
chain (VREF, TCK frequency, IDCODE) rather than measurements from an
application. The three devices are also deliberately not assumed to share a
connector, voltage or protocol: the MCU speaks CDC-ACM at 3.3 V, the FPGA
board's data path is a UART bridge with 1.0/1.8/3.3 V rails, and the JTAG
adapter speaks a vendor USB protocol (MPSSE) with I/O that follows the
target.

## 4. Software design (implemented)

```
DeviceAdapter (interface)            HardwareManager
  descriptor()   -> id, kind,          discover()
                    model, link        connect(id)      catches DeviceTimeout,
  capabilities() -> name/value list    disconnect(id)   logs it, returns Faulted
  connect(timeout)                     readTelemetry(id)
  disconnect()                         injectFault(id, kind)   test hook
  readTelemetry(timeout)               events()          last 500 events
  state() / lastError()
  injectFault(kind)

MockMicrocontroller, MockFpga, MockJtagAdapter : DeviceAdapter
```

- States: `disconnected -> connected`, and `connected/disconnected -> faulted`
  on a timeout. `faulted -> connected` on a successful retry, which is logged as
  "recovered".
- Timeouts: 800 ms for connect, 500 ms for a telemetry frame. A simulated delay
  (40 to 90 ms) makes the UI behave like a real link; the lock is released
  while waiting so status queries stay responsive.
- Fault injection: "next connect times out" or "next telemetry read times out".
  The Hardware view shows the fault, the error text, and recovery on retry.
- Tests: `tests/test_hardware.cpp` covers discovery, connect/telemetry/
  disconnect for all three kinds, telemetry without connection, both timeout
  types with recovery, and an unknown device id.

## 5. Safe integration plan (for real hardware)

1. Collect the schematics of the three boards and replace every *assumed* entry
   in the table above with the real pin numbers, header type and bank voltage.
2. Power each board alone from the powered hub. Measure its rails with a
   multimeter before connecting any signal cable.
3. Connect host links one at a time and confirm enumeration (COM port number,
   USB VID/PID). Replace mock discovery with real enumeration (Windows SetupAPI
   for COM ports; libusb or the vendor D2XX library for the adapter).
4. Implement `SerialAdapter` (Win32 `CreateFile` on the COM port, read timeouts
   via `COMMTIMEOUTS`) and `JtagAdapter` (MPSSE through libftdi/D2XX, or
   OpenOCD run as a separate process and driven over its TCL port) behind the
   same `DeviceAdapter` interface. Keep the same timeout and fault states so the
   UI does not change.
5. JTAG bring-up: power the FPGA board, check VREF on the header, connect the
   ribbon cable with the target powered off, power on, and run an IDCODE scan
   only. No programming until the IDCODE matches the expected device.
6. MCU-FPGA link: confirm the bank VCCO. If it is 1.8 V, fit the level shifter
   first. Start with a loopback test at low baud rate, then the real protocol.
7. Telemetry protocol: framed messages with a sequence number and CRC; the host
   treats a missing or bad frame as a timeout and the device as faulted until
   the user reconnects. The host never reprograms a device automatically.

## 6. Limitations

- Everything is simulated: no COM port, USB device or JTAG library is opened,
  and telemetry values are generated.
- Pin numbers and header types are assumptions for typical boards, not a
  verified wiring plan.
- Only one JTAG target is modelled; daisy-chaining several devices on one TAP
  is not covered.
- No electrical protection beyond level shifting and series resistors is
  specified (no ESD diodes, no isolation); fine for a bench, not for a product.
