# Backpropagation: worked solution (reference for the handwritten appendix)

This page is the typed reference used to check the C++ implementation and the
handwritten derivation. **The submitted appendix must be the candidate's own
handwritten working (maximum two pages), scanned or photographed.**

## Setup

Sample x = 1, target y = 2. Parameters w = 0.5, b = 0, v = 1, c = 0. Learning rate 0.1.

    z = w x + b          h = tanh(z)          y_hat = v h + c          J = 0.5 (y_hat - y)^2

## Forward pass

| Quantity | Expression | Value |
|---|---|---|
| z | 0.5 * 1 + 0 | 0.5 |
| h | tanh(0.5) | 0.4621171573 |
| y_hat | 1 * 0.4621171573 + 0 | 0.4621171573 |
| e = y_hat - y | 0.4621171573 - 2 | -1.5378828427 |
| J | 0.5 * e^2 | 1.1825418190 |

## Chain rule

Work backwards from the loss. Each local derivative is simple:

- dJ/dy_hat = e (derivative of 0.5 e^2)
- dy_hat/dc = 1, dy_hat/dv = h, dy_hat/dh = v
- dh/dz = 1 - tanh^2(z) = 1 - h^2
- dz/dw = x, dz/db = 1

So

| Gradient | Expression | Value |
|---|---|---|
| dJ/dc | e | -1.5378828427 |
| dJ/dv | e h | -0.7106820475 |
| dJ/dz | e v (1 - h^2) = -1.5378828427 * 1 * 0.7864477330 | -1.2094644752 |
| dJ/dw | dJ/dz * x | -1.2094644752 |
| dJ/db | dJ/dz * 1 | -1.2094644752 |

(h^2 = 0.2135522670, so 1 - h^2 = 0.7864477330.)

## One simultaneous update

All four gradients above are evaluated at the original parameters, then every
parameter is updated at once: theta_new = theta - 0.1 * dJ/dtheta.

| Parameter | Old | Update | New |
|---|---|---|---|
| w | 0.5 | -0.1 * (-1.2094644752) | 0.6209464475 |
| b | 0 | -0.1 * (-1.2094644752) | 0.1209464475 |
| v | 1 | -0.1 * (-0.7106820475) | 1.0710682047 |
| c | 0 | -0.1 * (-1.5378828427) | 0.1537882843 |

Check: with the new parameters z = 0.7418928950, h = 0.6303..., y_hat = 0.8289...,
J = 0.6857737650, lower than 1.1825418190.

## Direction of the gradients

The prediction 0.462 is well below the target 2, so e is negative and every
gradient is negative. A negative gradient means the loss falls as the parameter
grows, so gradient descent increases all four parameters. c moves the most
because its gradient is the raw error; v is scaled by h < 1; w and b are scaled
by v (1 - h^2) < 1 because tanh is flattening. dJ/dw equals dJ/db only because
x = 1.

## Common slips to avoid

- Using the updated w when computing the gradient for b (the update must be simultaneous).
- Writing dh/dz = 1 - z^2 instead of 1 - tanh^2(z).
- Rounding h too early: with h = 0.462 the third decimal of dJ/dv already moves.
  (While writing the unit test, a first hand value of -0.7106860884 for dJ/dv was
  wrong in the fifth decimal; the central-difference check flagged it.)
