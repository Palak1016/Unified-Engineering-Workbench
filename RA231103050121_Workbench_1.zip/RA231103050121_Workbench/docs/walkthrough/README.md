# Screenshot walkthrough with logs

Timestamped walkthrough of one session, recorded as an alternative to the demonstration video.

**Recording environment:** Linux build of the same source, run in a 2-vCPU development container and driven by
a headless Chromium browser (Playwright) with software WebGL. The Windows package was built from the same commit;
its test suite was run under Wine. The candidate's own Windows 11 recording should replace or accompany this.

The matching server log is in [server_log.txt](server_log.txt) (same clock, local time UTC+0 in the container).
Screenshot timestamps below are UTC, taken right after each action.

| # | Time (UTC) | Screenshot | What it shows | Status bar text |
|---|---|---|---|---|
| 1 | 18:48:43 | [01_start.png](01_start.png) | Interface after Launch: backend online, Geometry view. | Ready. Interface loaded in 343 ms. |
| 2 | 18:48:44 | [02_stl_example.png](02_stl_example.png) | Example STL (heat sink, mm) loaded; triangle count, extents and C++ parse time shown. | Loaded geometry/heat_sink_7fin_mm.stl: 96 triangles (parsed in 0.1 ms). |
| 3 | 18:48:45 | [03_stl_rotated_wireframe.png](03_stl_rotated_wireframe.png) | Rotated with the mouse and switched to wireframe. | Loaded geometry/heat_sink_7fin_mm.stl: 96 triangles (parsed in 0.1 ms). |
| 4 | 18:48:46 | [04_stl_rejected.png](04_stl_rejected.png) | Malformed STL (NaN vertex) rejected with line number; previous model kept on screen. | Could not import nan_vertex.stl: Line 5: non-finite value 'nan' in the vertex. NaN and infinity are rejected. (line 5) |
| 5 | 18:48:48 | [05_fea.png](05_fea.png) | Rod FEA for N = 10, 20, 40, 80 against the exact solution, midpoint error and convergence (order 2). | Solved 4 mesh(es) in 24 ms (round trip). |
| 6 | 18:48:48 | [06_fea_validation.png](06_fea_validation.png) | Invalid input (negative k) caught before the request is sent. | Conductivity k: Must be greater than zero. |
| 7 | 18:48:50 | [07_ansys_points.png](07_ansys_points.png) | Synthetic ANSYS-format CSV as a coloured point cloud with °C legend; a node picked for inspection. | Node 347: 51.667 °C at (0.05, 0.025, 0.005) m |
| 8 | 18:48:51 | [08_csv_rejected.png](08_csv_rejected.png) | CSV with a duplicate node id rejected; message names both lines. | Could not import duplicate_node_id.csv: Line 4: duplicate node_id 1 (first seen on line 2). (line 4) |
| 9 | 18:48:52 | [09_bench_running.png](09_bench_running.png) | Benchmark running on a background thread; progress and Cancel available, UI responsive. | Benchmark running in the background. The interface stays usable. |
| 10 | 18:48:53 | [10_bench_cancelled.png](10_bench_cancelled.png) | Cancelled run: no partial results published. | Benchmark cancelled. Previous results (if any) were left unchanged. |
| 11 | 18:48:57 | [11_bench_done.png](11_bench_done.png) | Completed benchmark: 5 measured runs per configuration, medians, speedup, efficiency, agreement check. | Benchmark finished in 2.9 s. Agreement passed. |
| 12 | 18:48:59 | [12_hw_connected.png](12_hw_connected.png) | All three simulated devices connected with one telemetry message each. | Telemetry #1 from jtag-0 (simulated). |
| 13 | 18:49:01 | [13_hw_timeout.png](13_hw_timeout.png) | Injected telemetry timeout on the JTAG adapter: state faulted, error text and log entry. | jtag-0: Telemetry frame from jtag-0 not received within 500 ms (simulated timeout). Reconnect to recover. |
| 14 | 18:49:02 | [14_hw_recovered.png](14_hw_recovered.png) | Retry connect: device recovered and telemetry resumes. | Telemetry #1 from jtag-0 (simulated). |
| 15 | 18:49:03 | [15_backprop.png](15_backprop.png) | Backprop: forward pass, gradient check (all within 1e-5), first update and loss curve. | Backprop check computed in C++. |

Steps 4 and 8 load deliberately malformed files from `tests/data/`; the HTTP 422 entries in the log at
those times are the expected rejections. Step 10 shows a cancelled benchmark: the log records the cancel
request and that no results were kept, and the next run (step 11) completes normally.
