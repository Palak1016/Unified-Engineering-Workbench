# Building from source

The packaged ZIP already contains a working `Launch.exe`; these steps are only
needed to rebuild it. All targets are defined in the top-level `CMakeLists.txt`.

## Targets

| Target | Output | Purpose |
|---|---|---|
| `wb_core` | static library | numerics, parsers, worker pool, device mocks (no HTTP/JSON) |
| `wb_server` | static library | HTTP routes, JSON mapping, CSV export, background jobs |
| `wb_launcher` | `Launch` / `Launch.exe` | starts the server and opens the browser |
| `workbench_cli` | `workbench_cli` | regenerates `results/` and `data/` without the GUI |
| `workbench_tests` | `workbench_tests` | unit tests, registered with CTest |

Requirements: CMake 3.16 or newer and a C++17 compiler. All third-party code is
header-only and vendored in `third_party/` (C++) and `src/frontend/vendor/`
(JavaScript), so the build does not download anything.

## Windows, Visual Studio 2022 (MSVC)

```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
build\Release\Launch.exe --web-root src\frontend --data-dir data
```

MSVC is expected to work but was not part of the tested configurations.

## Windows, MinGW-w64 (MSYS2 UCRT64 or similar)

```
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DWB_STATIC_RUNTIME=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

## Linux (development build)

```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
./build/Launch            # finds ../src/frontend and ../data automatically
```

## Cross-building the Windows package on Linux

This is how the submitted `Launch.exe` was produced (Ubuntu 24.04,
`g++-mingw-w64-x86-64-posix` 13.2):

```
tools/package_windows.sh <CandidateID>
```

The script configures `build-win/` with `cmake/mingw-w64-x86_64.cmake`, links
the C++ runtime statically (`-DWB_STATIC_RUNTIME=ON`), runs the native tests,
and assembles `dist/<CandidateID>_Workbench/` and the ZIP from the committed
source (`git archive`), so no untracked or machine-specific files are included.

## Notes

- Release builds use the compiler defaults for the build type (`-O3 -DNDEBUG`
  for GCC). The flags are compiled into the binary and shown in the Performance
  view, so the benchmark report always states how the timed code was built.
- `Launch` looks for the frontend in `app/web` next to the executable, then in
  `../src/frontend` and `../../src/frontend` (build folders). Override with
  `--web-root` and `--data-dir`.
- The tests look for `tests/data` and `data` relative to the working directory
  and up to three parent folders, so they run from the project root, from
  `build/`, or from `app/bin/` in the package.
