# Unified Engineering Workbench

PASS Science Works R&D Internship 2026-2027, common technical assignment.
Candidate: Kumari Palak, Candidate ID RA231103050121.

A small engineering workbench with a C++17 backend and a browser interface. It
imports ASCII STL geometry and ANSYS nodal temperature CSV files, solves a 1D
steady thermal problem with linear finite elements, runs a serial vs
multithreaded batch benchmark, drives simulated MCU/FPGA/JTAG adapters, and
checks a hand-derived backpropagation example.

All parsing, numerics, file handling and concurrency are in C++. The browser
only draws what the backend returns.

---

## 1. Prerequisites

To run the packaged application:

- Windows 11 x64 (Windows 10 x64 also works).
- Any current browser (Edge is installed by default; Chrome and Firefox work too).
- Nothing else. No installer, no administrator rights, no internet, no runtime
  packages. Launch.exe is statically linked and only uses DLLs that ship with
  Windows (kernel32, user32, shell32, advapi32, ws2_32, msvcrt).

To build from source, see [docs/BUILD.md](docs/BUILD.md).

## 2. One-click start

1. Extract the ZIP to any folder you can write to (Desktop, Documents, ...).
   Extract the whole archive; Launch.exe needs the `app\` folder beside it.
2. Double-click **Launch.exe**.
3. A small console window opens with the server log, and the interface opens in
   your default browser at `http://127.0.0.1:8765/` (or the next free port up
   to 8799).
4. To stop, click **Exit** in the top-right corner of the interface, or close
   the console window.

If Windows SmartScreen shows "Windows protected your PC" (the executable is not
code-signed), choose **More info > Run anyway**. This does not need
administrator rights.

### From VS Code or Antigravity

Open the extracted folder, select **Run Workbench (packaged)** in the Run and
Debug panel, then press F5. This starts the same Launch.exe. The configuration
uses the `cppvsdbg` launcher, which needs the Microsoft **C/C++** extension
(`ms-vscode.cpptools`); the editor will offer to install it from
`.vscode/extensions.json`. Without any extension, use
**Terminal > Run Task > Run Workbench (packaged)** instead. The standalone
launcher never needs the editor or the internet.

## 3. What each view does

| View | Purpose |
|---|---|
| Geometry | Load an ASCII STL (file picker, drag-and-drop or bundled example). Rotate, pan, zoom, fit to view, wireframe. Shows triangle count, extents and parser warnings. |
| Thermal Analysis > Rod FEA | Solves the rod problem for any set of meshes (default N = 10, 20, 40, 80), plots T(x) against the exact solution, midpoint error and convergence, and exports three CSV files. |
| Thermal Analysis > ANSYS results | Loads a nodal temperature CSV and shows it as a coloured point cloud with a legend in °C. Click any point to read its node id, coordinates and temperature. |
| Performance | Runs the batch benchmark in the background with a progress bar and Cancel. Reports CPU, cores, RAM, compiler and flags, every timed run, median, speedup, efficiency and the serial/parallel agreement check. Exports CSV. |
| Hardware | Discovers the three simulated devices, connects, reads telemetry and injects a timeout to show recovery. Includes the integration block diagram and an event log. |
| Backprop Check | Forward pass, hand-coded gradients vs central differences, the first simultaneous update, and the loss over 100 further steps. Exports CSV. |

Every plot has a **Save SVG** button. Every numeric input is validated before
it is sent, and the backend validates again and returns a readable message.

## 4. Supported file formats

### ASCII STL (`.stl`)

- `solid` / `facet normal` / `outer loop` / 3 x `vertex` / `endloop` / `endfacet` / `endsolid`, any indentation, LF or CRLF, several solids per file.
- STL has no unit field. The viewer lets you choose mm, m or inch for the displayed dimensions.
- Rejected with the line number: binary STL (including binary files whose header starts with `solid`), NaN or infinite values, facets with fewer or more than 3 vertices, missing keywords, truncated files.
- Explained rather than shown: empty files, whitespace-only files, and files with a valid `solid` block but no facets.
- Warnings (file still loads): zero-area triangles, facet normals opposite to the vertex winding.
- Tested limit: 64 MB / 1,000,000 triangles. A 66 MB file with 499,992 triangles parsed in 0.53 s and displayed in 4.6 s end to end (see `results/import_size_tests.csv`).

### Nodal temperature CSV (`.csv`)

```
node_id,x_m,y_m,z_m,temperature_C
1,0.0000,0.0000,0.0000,25.112
...
```

- The five columns are matched by name (case-insensitive, any order). Extra columns are ignored with a warning.
- Coordinates in metres, temperature in degrees Celsius.
- Lines starting with `#` are comments; they are shown in the interface and are used to label synthetic data.
- Rejected with the line number: missing header columns, wrong number of fields, non-numeric values, NaN/Inf, node ids that are not positive integers, duplicate node ids, temperatures below -273.15 °C.
- Explained: empty file, comments only, header with no data rows.
- Tested limit: 64 MB / 1,000,000 nodes (1,000,000 nodes parsed in 0.30 s, displayed in 2.7 s).

Native ANSYS project/result files and native CAD solids are not supported.

## 5. Architecture

```
src/
  backend/
    core/        C++ library: no HTTP, no JSON
      io/          STL and nodal CSV readers, text utilities
      fea/         1D rod FEA, exact solution, error evaluation
      parallel/    worker pool, batch generator, serial/parallel runner, benchmark
      hardware/    DeviceAdapter interface, mock MCU/FPGA/JTAG, HardwareManager
      ml/          backpropagation example
      platform/    CPU/RAM/compiler description
    server/      transport: HTTP routes, JSON mapping, CSV export, background jobs
    app/         Launch.exe entry point, workbench_cli entry point, OS helpers
  frontend/      index.html, css/, js/ (views, plotting, three.js viewer), vendor/three
tests/           unit tests and malformed-file fixtures
data/            example STL and synthetic CSV with provenance
results/         raw CSV output and labelled figures
docs/            report, build guide, embedded design, AI-use log, ownership
tools/           packaging and report-figure scripts (no backend features)
third_party/     cpp-httplib, nlohmann/json (header-only, with licences)
```

Data flow: the browser sends a request to `127.0.0.1`, a route in `server/`
converts it into a call on the `core/` library, and the result goes back as
JSON or CSV. `core/` can be used without the server, which is how the tests and
`workbench_cli` use it. Long jobs (the benchmark) run on a background thread;
the browser polls progress, and a cancelled run never publishes partial
results.

## 6. Tests and command-line tool

The packaged ZIP includes the test and CLI binaries in `app\bin\`. From the
extracted folder:

```
app\bin\workbench_tests.exe          53 positive, negative and numerical tests
app\bin\workbench_cli.exe fea        convergence table and CSV files
app\bin\workbench_cli.exe benchmark --tag windows
app\bin\workbench_cli.exe backprop
app\bin\workbench_cli.exe check-stl data\geometry\heat_sink_7fin_mm.stl
```

From a source build: `ctest --test-dir build -C Release --output-on-failure`.

## 7. Known limitations

- The interface runs in the browser and talks to a local server. Closing the browser tab does not stop the server; use Exit or close the console window.
- If ports 8765 to 8799 are all taken, Launch.exe shows an error. Use `Launch.exe --port <n>` to pick another.
- STL units are not stored in the file, so the displayed unit is the user's choice. Mesh-to-result registration between the STL and the CSV is not done (not required).
- The point cloud is drawn as screen-sized points without interpolation between nodes; it is not a contour plot on a surface.
- Benchmark speedup depends on the machine. The batch keeps every nodal result for the agreement check, so large workloads become memory-bandwidth bound; the input limit is 16 million stored nodes (128 MB per result buffer).
- Hardware support is simulated. No serial port, USB or JTAG library is opened.
- The executable is not code-signed, so SmartScreen may ask for confirmation the first time.
- Built and tested with GCC 13 (Linux) and MinGW-w64 GCC 13 (Windows cross-build, tests also run under Wine). MSVC builds are expected to work but were not tested.

## 8. Further documents

- `docs/Report.pdf` / `docs/Report.docx` - technical report (design, FEA verification, performance, embedded design, tests, limitations)
- `docs/BUILD.md` - CMake build instructions
- `docs/embedded_integration.md` - block diagram, interface and pin-voltage table, integration plan
- `docs/AI_USE_LOG.md` - AI assistance log
- `docs/OWNERSHIP.md` - reused vs original work
- `docs/walkthrough/` - timestamped screenshot walkthrough with logs
- `DEPENDENCIES.md` - versions and licences
- `data/PROVENANCE.md` - origin and units of the example files
