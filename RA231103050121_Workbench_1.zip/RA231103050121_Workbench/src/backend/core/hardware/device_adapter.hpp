#pragma once

#include <chrono>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace wb::hardware {

enum class DeviceKind { Microcontroller, Fpga, JtagAdapter };
enum class ConnectionState { Disconnected, Connected, Faulted };

const char* toString(DeviceKind kind);
const char* toString(ConnectionState state);

// Static description returned by discovery. `simulated` is always true in this
// build; it exists so a real adapter can report false without changing callers.
struct DeviceDescriptor {
    std::string id;           // stable within one discovery, e.g. "mcu-0"
    DeviceKind kind = DeviceKind::Microcontroller;
    std::string model;        // board class, not a specific vendor part
    std::string hostLink;     // how the host talks to it
    std::string port;         // simulated port name
    bool simulated = true;
};

struct Capability {
    std::string name;
    std::string value;
};

struct TelemetryField {
    std::string name;
    double value = 0.0;
    std::string unit;
};

struct TelemetryMessage {
    std::string deviceId;
    std::uint64_t sequence = 0;
    double hostTimeS = 0.0;          // seconds since the adapter connected
    std::vector<TelemetryField> fields;
    std::string note;                // free-text status, e.g. JTAG chain contents
    bool simulated = true;
};

// Raised when the device does not answer in time. Recoverable: the adapter
// moves to Faulted and a later connect() can succeed.
class DeviceTimeout : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

// Raised for misuse such as reading telemetry while disconnected.
class DeviceStateError : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

enum class FaultKind { None, ConnectTimeout, TelemetryTimeout };

// Common interface for anything attached to the workbench. Real
// implementations (serial port, USB/JTAG library) would implement the same
// five operations; the UI and manager only use this interface.
class DeviceAdapter {
public:
    virtual ~DeviceAdapter() = default;

    virtual const DeviceDescriptor& descriptor() const = 0;
    virtual std::vector<Capability> capabilities() const = 0;
    virtual void connect(std::chrono::milliseconds timeout) = 0;
    virtual void disconnect() = 0;
    virtual TelemetryMessage readTelemetry(std::chrono::milliseconds timeout) = 0;
    virtual ConnectionState state() const = 0;
    virtual std::string lastError() const = 0;

    // Test hook: the next connect/read will time out once.
    virtual void injectFault(FaultKind kind) = 0;
};

std::unique_ptr<DeviceAdapter> makeMockMicrocontroller(const std::string& id, std::uint32_t seed);
std::unique_ptr<DeviceAdapter> makeMockFpga(const std::string& id, std::uint32_t seed);
std::unique_ptr<DeviceAdapter> makeMockJtagAdapter(const std::string& id, std::uint32_t seed);

}  // namespace wb::hardware
