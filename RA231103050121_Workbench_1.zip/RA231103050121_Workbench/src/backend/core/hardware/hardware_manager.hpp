#pragma once

#include "core/hardware/device_adapter.hpp"

#include <chrono>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace wb::hardware {

struct DeviceStatus {
    DeviceDescriptor descriptor;
    ConnectionState state = ConnectionState::Disconnected;
    std::string lastError;
    std::vector<Capability> capabilities;
};

struct HardwareEvent {
    double timeS = 0.0;     // since manager start
    std::string deviceId;
    std::string level;      // info | warning | error
    std::string message;
};

// Owns the adapters and turns their exceptions into logged, recoverable
// events. All public methods are thread-safe.
class HardwareManager {
public:
    struct Timeouts {
        std::chrono::milliseconds connect{800};
        std::chrono::milliseconds telemetry{500};
    };

    HardwareManager();  // registers the three simulated devices
    explicit HardwareManager(std::vector<std::unique_ptr<DeviceAdapter>> adapters, Timeouts timeouts);

    std::vector<DeviceStatus> discover();
    DeviceStatus status(const std::string& id) const;

    // These never throw for device-level problems; failures are reported via
    // the returned status and the event log. Unknown ids throw std::out_of_range.
    DeviceStatus connect(const std::string& id);
    DeviceStatus disconnect(const std::string& id);

    struct TelemetryResult {
        bool ok = false;
        TelemetryMessage message;
        DeviceStatus status;
    };
    TelemetryResult readTelemetry(const std::string& id);

    void injectFault(const std::string& id, FaultKind kind);
    std::vector<HardwareEvent> events(std::size_t max = 200) const;

private:
    DeviceAdapter& find(const std::string& id) const;
    DeviceStatus snapshot(const DeviceAdapter& adapter) const;
    void log(const std::string& id, const std::string& level, const std::string& message);

    std::vector<std::unique_ptr<DeviceAdapter>> adapters_;
    Timeouts timeouts_;
    mutable std::mutex logMutex_;
    std::deque<HardwareEvent> events_;
    std::chrono::steady_clock::time_point start_;
};

}  // namespace wb::hardware
