#include "core/hardware/hardware_manager.hpp"

#include <stdexcept>

namespace wb::hardware {

namespace {

std::vector<std::unique_ptr<DeviceAdapter>> defaultAdapters() {
    std::vector<std::unique_ptr<DeviceAdapter>> adapters;
    adapters.push_back(makeMockMicrocontroller("mcu-0", 11));
    adapters.push_back(makeMockFpga("fpga-0", 22));
    adapters.push_back(makeMockJtagAdapter("jtag-0", 33));
    return adapters;
}

constexpr std::size_t kMaxEvents = 500;

}  // namespace

HardwareManager::HardwareManager() : HardwareManager(defaultAdapters(), Timeouts{}) {}

HardwareManager::HardwareManager(std::vector<std::unique_ptr<DeviceAdapter>> adapters, Timeouts timeouts)
    : adapters_(std::move(adapters)), timeouts_(timeouts), start_(std::chrono::steady_clock::now()) {}

std::vector<DeviceStatus> HardwareManager::discover() {
    std::vector<DeviceStatus> list;
    for (const auto& adapter : adapters_) {
        list.push_back(snapshot(*adapter));
    }
    log("", "info", "Discovery found " + std::to_string(list.size()) + " simulated device(s).");
    return list;
}

DeviceStatus HardwareManager::status(const std::string& id) const { return snapshot(find(id)); }

DeviceStatus HardwareManager::connect(const std::string& id) {
    auto& adapter = find(id);
    const bool retry = adapter.state() == ConnectionState::Faulted;
    try {
        adapter.connect(timeouts_.connect);
        log(id, "info", retry ? "Reconnected after fault (recovered)." : "Connected.");
    } catch (const DeviceTimeout& e) {
        log(id, "error", e.what());
    }
    return snapshot(adapter);
}

DeviceStatus HardwareManager::disconnect(const std::string& id) {
    auto& adapter = find(id);
    adapter.disconnect();
    log(id, "info", "Disconnected.");
    return snapshot(adapter);
}

HardwareManager::TelemetryResult HardwareManager::readTelemetry(const std::string& id) {
    auto& adapter = find(id);
    TelemetryResult result;
    try {
        result.message = adapter.readTelemetry(timeouts_.telemetry);
        result.ok = true;
    } catch (const DeviceTimeout& e) {
        log(id, "error", e.what());
    } catch (const DeviceStateError& e) {
        log(id, "warning", e.what());
    }
    result.status = snapshot(adapter);
    return result;
}

void HardwareManager::injectFault(const std::string& id, FaultKind kind) {
    find(id).injectFault(kind);
    const char* what = kind == FaultKind::ConnectTimeout     ? "next connect will time out"
                       : kind == FaultKind::TelemetryTimeout ? "next telemetry read will time out"
                                                             : "fault cleared";
    log(id, "warning", std::string("Fault armed (test): ") + what + ".");
}

std::vector<HardwareEvent> HardwareManager::events(std::size_t max) const {
    std::lock_guard<std::mutex> lock(logMutex_);
    const std::size_t n = std::min(max, events_.size());
    return {events_.end() - static_cast<std::ptrdiff_t>(n), events_.end()};
}

DeviceAdapter& HardwareManager::find(const std::string& id) const {
    for (const auto& adapter : adapters_) {
        if (adapter->descriptor().id == id) return *adapter;
    }
    throw std::out_of_range("Unknown device '" + id + "'. Run discovery to list available devices.");
}

DeviceStatus HardwareManager::snapshot(const DeviceAdapter& adapter) const {
    return {adapter.descriptor(), adapter.state(), adapter.lastError(), adapter.capabilities()};
}

void HardwareManager::log(const std::string& id, const std::string& level, const std::string& message) {
    std::lock_guard<std::mutex> lock(logMutex_);
    const double t = std::chrono::duration<double>(std::chrono::steady_clock::now() - start_).count();
    events_.push_back({t, id, level, message});
    if (events_.size() > kMaxEvents) events_.pop_front();
}

}  // namespace wb::hardware
