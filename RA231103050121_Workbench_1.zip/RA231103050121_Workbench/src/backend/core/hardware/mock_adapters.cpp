// Simulated device adapters. Nothing in this file touches real hardware: all
// values are generated, and every message carries simulated = true.

#include "core/hardware/device_adapter.hpp"

#include <cmath>
#include <mutex>
#include <random>
#include <thread>

namespace wb::hardware {

const char* toString(DeviceKind kind) {
    switch (kind) {
        case DeviceKind::Microcontroller: return "microcontroller";
        case DeviceKind::Fpga: return "fpga";
        case DeviceKind::JtagAdapter: return "jtag-adapter";
    }
    return "unknown";
}

const char* toString(ConnectionState state) {
    switch (state) {
        case ConnectionState::Disconnected: return "disconnected";
        case ConnectionState::Connected: return "connected";
        case ConnectionState::Faulted: return "faulted";
    }
    return "unknown";
}

namespace {

using Clock = std::chrono::steady_clock;

// Shared behaviour: state machine, simulated latency and fault injection.
class MockAdapterBase : public DeviceAdapter {
public:
    MockAdapterBase(DeviceDescriptor descriptor, std::uint32_t seed, std::chrono::milliseconds latency)
        : descriptor_(std::move(descriptor)), rng_(seed), latency_(latency) {}

    const DeviceDescriptor& descriptor() const override { return descriptor_; }

    void connect(std::chrono::milliseconds timeout) override {
        std::unique_lock<std::mutex> lock(mutex_);
        if (state_ == ConnectionState::Connected) return;
        const bool fail = consumeFault(FaultKind::ConnectTimeout);
        // Simulated bus delay happens without holding the lock so status
        // queries from the UI stay responsive.
        lock.unlock();
        waitFor(fail ? timeout : std::min(latency_, timeout));
        lock.lock();
        if (fail) {
            state_ = ConnectionState::Faulted;
            lastError_ = "No response from " + descriptor_.model + " on " + descriptor_.port + " within " +
                         std::to_string(timeout.count()) + " ms (simulated timeout). Check the cable and retry.";
            throw DeviceTimeout(lastError_);
        }
        state_ = ConnectionState::Connected;
        lastError_.clear();
        connectedAt_ = Clock::now();
        sequence_ = 0;
    }

    void disconnect() override {
        std::lock_guard<std::mutex> lock(mutex_);
        state_ = ConnectionState::Disconnected;
    }

    TelemetryMessage readTelemetry(std::chrono::milliseconds timeout) override {
        std::unique_lock<std::mutex> lock(mutex_);
        if (state_ != ConnectionState::Connected) {
            throw DeviceStateError(descriptor_.id + " is " + toString(state_) + "; connect before reading telemetry.");
        }
        const bool fail = consumeFault(FaultKind::TelemetryTimeout);
        lock.unlock();
        waitFor(fail ? timeout : std::min(latency_ / 4, timeout));
        lock.lock();
        if (fail) {
            state_ = ConnectionState::Faulted;
            lastError_ = "Telemetry frame from " + descriptor_.id + " not received within " +
                         std::to_string(timeout.count()) + " ms (simulated timeout). Reconnect to recover.";
            throw DeviceTimeout(lastError_);
        }
        if (state_ != ConnectionState::Connected) {
            throw DeviceStateError(descriptor_.id + " was disconnected while waiting for telemetry.");
        }
        TelemetryMessage msg;
        msg.deviceId = descriptor_.id;
        msg.sequence = ++sequence_;
        msg.hostTimeS = std::chrono::duration<double>(Clock::now() - connectedAt_).count();
        fillTelemetry(msg);
        return msg;
    }

    ConnectionState state() const override {
        std::lock_guard<std::mutex> lock(mutex_);
        return state_;
    }

    std::string lastError() const override {
        std::lock_guard<std::mutex> lock(mutex_);
        return lastError_;
    }

    void injectFault(FaultKind kind) override {
        std::lock_guard<std::mutex> lock(mutex_);
        pendingFault_ = kind;
    }

protected:
    virtual void fillTelemetry(TelemetryMessage& msg) = 0;

    double noise(double amplitude) { return amplitude * (std::uniform_real_distribution<double>(-1.0, 1.0)(rng_)); }
    std::uint64_t sequence() const { return sequence_; }

private:
    bool consumeFault(FaultKind kind) {
        if (pendingFault_ == kind) {
            pendingFault_ = FaultKind::None;
            return true;
        }
        return false;
    }

    static void waitFor(std::chrono::milliseconds duration) {
        if (duration.count() > 0) std::this_thread::sleep_for(duration);
    }

    DeviceDescriptor descriptor_;
    mutable std::mutex mutex_;
    ConnectionState state_ = ConnectionState::Disconnected;
    std::string lastError_;
    FaultKind pendingFault_ = FaultKind::None;
    Clock::time_point connectedAt_{};
    std::uint64_t sequence_ = 0;
    std::mt19937 rng_;
    std::chrono::milliseconds latency_;
};

class MockMicrocontroller final : public MockAdapterBase {
public:
    MockMicrocontroller(const std::string& id, std::uint32_t seed)
        : MockAdapterBase({id, DeviceKind::Microcontroller, "Cortex-M4 class MCU board (simulated)",
                           "USB CDC-ACM virtual COM port, 115200 baud, framed JSON lines", "COM-SIM-1", true},
                          seed, std::chrono::milliseconds(60)) {}

    std::vector<Capability> capabilities() const override {
        return {{"role", "runs firmware; sensor sampling and actuator control"},
                {"io_voltage", "3.3 V (pins not 5 V tolerant unless stated on the board)"},
                {"host_link", descriptor().hostLink},
                {"adc", "12-bit, 0 to 3.3 V reference"},
                {"debug_port", "SWD/JTAG header, owned by the debug adapter when attached"},
                {"telemetry", "die_temp_C, vdd_V, adc0_V, uptime_s"}};
    }

protected:
    void fillTelemetry(TelemetryMessage& msg) override {
        msg.fields = {{"die_temp_C", 36.5 + 0.02 * static_cast<double>(sequence()) + noise(0.3), "C"},
                      {"vdd_V", 3.30 + noise(0.01), "V"},
                      {"adc0_V", 1.65 + 0.4 * std::sin(0.3 * static_cast<double>(sequence())) + noise(0.005), "V"},
                      {"uptime_s", msg.hostTimeS, "s"}};
        msg.note = "SIMULATED firmware heartbeat";
    }
};

class MockFpga final : public MockAdapterBase {
public:
    MockFpga(const std::string& id, std::uint32_t seed)
        : MockAdapterBase({id, DeviceKind::Fpga, "Artix-7 class FPGA board (simulated)",
                           "USB-UART bridge to a soft-core register interface, 921600 baud", "COM-SIM-2", true},
                          seed, std::chrono::milliseconds(90)) {}

    std::vector<Capability> capabilities() const override {
        return {{"role", "configurable logic; user design loaded via JTAG or flash"},
                {"core_voltage", "VCCINT 1.0 V, VCCAUX 1.8 V (board regulators)"},
                {"io_banks", "VCCO 3.3 V on user headers; check bank voltage per header"},
                {"host_link", descriptor().hostLink},
                {"configuration", "JTAG (via debug adapter) or SPI flash at power-up"},
                {"telemetry", "die_temp_C, vccint_V, vccaux_V, done_pin, design_id"}};
    }

protected:
    void fillTelemetry(TelemetryMessage& msg) override {
        msg.fields = {{"die_temp_C", 41.0 + noise(0.5), "C"},
                      {"vccint_V", 1.00 + noise(0.004), "V"},
                      {"vccaux_V", 1.80 + noise(0.006), "V"},
                      {"done_pin", 1.0, ""},
                      {"design_id", 0x0A11, ""}};
        msg.note = "SIMULATED XADC-style readout; design 0x0A11 reported as loaded";
    }
};

class MockJtagAdapter final : public MockAdapterBase {
public:
    MockJtagAdapter(const std::string& id, std::uint32_t seed)
        : MockAdapterBase({id, DeviceKind::JtagAdapter, "FT2232H-class JTAG debug adapter (simulated)",
                           "USB 2.0 high-speed, vendor driver (MPSSE)", "USB-SIM-3", true},
                          seed, std::chrono::milliseconds(40)) {}

    std::vector<Capability> capabilities() const override {
        return {{"role", "debug and programming interface only; does not run user workloads"},
                {"signals", "TCK, TMS, TDI (out); TDO, VREF (in); optional nTRST, nSRST"},
                {"io_voltage", "follows target VREF, 1.8 to 3.3 V (buffered)"},
                {"max_tck", "30 MHz (6 MHz used by default)"},
                {"host_link", descriptor().hostLink},
                {"target", "one JTAG chain at a time; currently the FPGA board header"}};
    }

protected:
    void fillTelemetry(TelemetryMessage& msg) override {
        msg.fields = {{"target_vref_V", 3.29 + noise(0.01), "V"},
                      {"tck_MHz", 6.0, "MHz"},
                      {"chain_devices", 1.0, ""}};
        msg.note = "SIMULATED scan: 1 device, IDCODE 0x0362D093 (example Artix-7 class ID)";
    }
};

}  // namespace

std::unique_ptr<DeviceAdapter> makeMockMicrocontroller(const std::string& id, std::uint32_t seed) {
    return std::make_unique<MockMicrocontroller>(id, seed);
}
std::unique_ptr<DeviceAdapter> makeMockFpga(const std::string& id, std::uint32_t seed) {
    return std::make_unique<MockFpga>(id, seed);
}
std::unique_ptr<DeviceAdapter> makeMockJtagAdapter(const std::string& id, std::uint32_t seed) {
    return std::make_unique<MockJtagAdapter>(id, seed);
}

}  // namespace wb::hardware
