#pragma once

#include <vector>

namespace wb::ml {

// One-hidden-unit regression network:
//   z = w x + b,  h = tanh(z),  y_hat = v h + c,  J = 0.5 (y_hat - y)^2
struct Parameters {
    double w = 0.5;
    double b = 0.0;
    double v = 1.0;
    double c = 0.0;
};

struct Sample {
    double x = 1.0;
    double y = 2.0;
};

struct ForwardPass {
    double z = 0.0;
    double h = 0.0;
    double yHat = 0.0;
    double error = 0.0;  // y_hat - y
    double loss = 0.0;
};

struct Gradients {
    double dw = 0.0;
    double db = 0.0;
    double dv = 0.0;
    double dc = 0.0;
};

ForwardPass forward(const Parameters& p, const Sample& s);

// Hand-derived chain rule (no automatic differentiation):
//   dJ/dc = e,  dJ/dv = e h,  dJ/dz = e v (1 - h^2),  dJ/dw = dJ/dz * x,  dJ/db = dJ/dz
Gradients analyticGradients(const Parameters& p, const Sample& s);

// Central differences: (J(theta + eps) - J(theta - eps)) / (2 eps), one parameter at a time.
Gradients finiteDifferenceGradients(const Parameters& p, const Sample& s, double epsilon);

// Simultaneous update: all four gradients are computed from the same parameters first.
Parameters gradientStep(const Parameters& p, const Gradients& g, double learningRate);

struct TrainingRecord {
    int step = 0;          // 0 = initial parameters, 1 = after the first (hand-checked) update
    Parameters params;
    double loss = 0.0;
};

// Returns steps+1 records: the starting point and the state after each update.
std::vector<TrainingRecord> train(const Parameters& start, const Sample& s, double learningRate, int steps);

}  // namespace wb::ml
