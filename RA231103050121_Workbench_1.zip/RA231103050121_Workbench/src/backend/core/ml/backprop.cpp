#include "core/ml/backprop.hpp"

#include <cmath>
#include <stdexcept>

namespace wb::ml {

ForwardPass forward(const Parameters& p, const Sample& s) {
    ForwardPass f;
    f.z = p.w * s.x + p.b;
    f.h = std::tanh(f.z);
    f.yHat = p.v * f.h + p.c;
    f.error = f.yHat - s.y;
    f.loss = 0.5 * f.error * f.error;
    return f;
}

Gradients analyticGradients(const Parameters& p, const Sample& s) {
    const ForwardPass f = forward(p, s);
    const double dJ_dyHat = f.error;                 // d/dy_hat of 0.5 e^2
    const double dJ_dh = dJ_dyHat * p.v;             // y_hat = v h + c
    const double dJ_dz = dJ_dh * (1.0 - f.h * f.h);  // d tanh(z)/dz = 1 - tanh^2(z)
    Gradients g;
    g.dc = dJ_dyHat;
    g.dv = dJ_dyHat * f.h;
    g.dw = dJ_dz * s.x;
    g.db = dJ_dz;
    return g;
}

Gradients finiteDifferenceGradients(const Parameters& p, const Sample& s, double epsilon) {
    if (!(epsilon > 0.0)) {
        throw std::invalid_argument("Finite-difference step must be positive.");
    }
    auto central = [&](double Parameters::*member) {
        Parameters plus = p, minus = p;
        plus.*member += epsilon;
        minus.*member -= epsilon;
        return (forward(plus, s).loss - forward(minus, s).loss) / (2.0 * epsilon);
    };
    return {central(&Parameters::w), central(&Parameters::b), central(&Parameters::v), central(&Parameters::c)};
}

Parameters gradientStep(const Parameters& p, const Gradients& g, double learningRate) {
    return {p.w - learningRate * g.dw, p.b - learningRate * g.db, p.v - learningRate * g.dv,
            p.c - learningRate * g.dc};
}

std::vector<TrainingRecord> train(const Parameters& start, const Sample& s, double learningRate, int steps) {
    if (steps < 0 || steps > 100000) {
        throw std::invalid_argument("Training steps must be between 0 and 100000.");
    }
    if (!(learningRate > 0.0) || !std::isfinite(learningRate)) {
        throw std::invalid_argument("Learning rate must be a positive finite number.");
    }
    std::vector<TrainingRecord> history;
    history.reserve(static_cast<std::size_t>(steps) + 1);
    Parameters p = start;
    history.push_back({0, p, forward(p, s).loss});
    for (int k = 1; k <= steps; ++k) {
        p = gradientStep(p, analyticGradients(p, s), learningRate);
        history.push_back({k, p, forward(p, s).loss});
    }
    return history;
}

}  // namespace wb::ml
