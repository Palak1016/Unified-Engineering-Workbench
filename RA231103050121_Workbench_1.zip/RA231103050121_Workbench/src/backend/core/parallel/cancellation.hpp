#pragma once

#include <atomic>
#include <functional>
#include <stdexcept>
#include <string>

namespace wb::parallel {

// Thrown when a long-running computation notices a cancellation request.
// Partial results are never published when this is raised.
class Cancelled : public std::runtime_error {
public:
    Cancelled() : std::runtime_error("Cancelled by user") {}
};

class CancelToken {
public:
    void request() noexcept { flag_.store(true, std::memory_order_relaxed); }
    bool requested() const noexcept { return flag_.load(std::memory_order_relaxed); }
    void throwIfRequested() const {
        if (requested()) throw Cancelled();
    }

private:
    std::atomic<bool> flag_{false};
};

// fraction in [0, 1] plus a short human-readable stage description.
using ProgressCallback = std::function<void(double fraction, const std::string& stage)>;

}  // namespace wb::parallel
