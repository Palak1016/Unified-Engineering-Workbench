#include "core/parallel/batch_runner.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <random>
#include <stdexcept>

namespace wb::parallel {

namespace {

using Clock = std::chrono::steady_clock;

double millisecondsSince(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

double unitInterval(std::mt19937_64& rng) {
    // Top 53 bits -> double in [0, 1). Identical on every conforming platform.
    return static_cast<double>(rng() >> 11) * (1.0 / 9007199254740992.0);
}

// Solves case i into its own slice of the output.
void solveOne(const std::vector<fea::RodProblem>& cases, std::size_t i, int elements, fea::SolverWorkspace& work,
              BatchResult& out) {
    double* slice = out.temperatures.data() + i * static_cast<std::size_t>(out.nodesPerCase);
    fea::solveRodInto(cases[i], elements, work, slice);
    out.maxMidpointError[i] = fea::maxMidpointError(cases[i], elements, slice);
}

constexpr std::size_t kChunk = 4;  // cases per atomic fetch; small enough to balance, large enough to limit contention

}  // namespace

void validate(const BatchConfig& c) {
    if (c.caseCount < 1 || c.caseCount > kMaxBatchCases) {
        throw std::invalid_argument("Case count must be between 1 and " + std::to_string(kMaxBatchCases) + ".");
    }
    fea::validateElementCount(c.elements);
    if (static_cast<long long>(c.caseCount) * (c.elements + 1) > kMaxBatchNodes) {
        throw std::invalid_argument("Cases x (elements + 1) must not exceed " + std::to_string(kMaxBatchNodes) +
                                    " nodes (memory limit for storing all results). Reduce the case count or mesh size.");
    }
    if (!(c.kMin > 0.0) || !(c.kMax >= c.kMin) || !std::isfinite(c.kMax)) {
        throw std::invalid_argument("Conductivity range must satisfy 0 < kMin <= kMax.");
    }
    if (!(c.qMin > 0.0) || !(c.qMax >= c.qMin) || !std::isfinite(c.qMax)) {
        throw std::invalid_argument("Heat generation range must satisfy 0 < qMin <= qMax.");
    }
    fea::validate(c.base);
}

std::vector<fea::RodProblem> generateBatch(const BatchConfig& config) {
    validate(config);
    std::mt19937_64 rng(config.seed);
    std::vector<fea::RodProblem> cases(static_cast<std::size_t>(config.caseCount), config.base);
    for (auto& problem : cases) {
        problem.conductivity = config.kMin + (config.kMax - config.kMin) * unitInterval(rng);
        problem.heatGeneration = config.qMin + (config.qMax - config.qMin) * unitInterval(rng);
    }
    return cases;
}

void BatchResult::resize(int cases, int elements) {
    caseCount = cases;
    nodesPerCase = elements + 1;
    temperatures.assign(static_cast<std::size_t>(cases) * static_cast<std::size_t>(nodesPerCase), 0.0);
    maxMidpointError.assign(static_cast<std::size_t>(cases), 0.0);
}

void solveSerial(const std::vector<fea::RodProblem>& cases, int elements, BatchResult& out,
                 const CancelToken* cancel) {
    fea::SolverWorkspace work;
    work.resize(elements);
    for (std::size_t i = 0; i < cases.size(); ++i) {
        if (cancel && (i % kChunk) == 0) cancel->throwIfRequested();
        solveOne(cases, i, elements, work, out);
    }
}

void solveParallel(const std::vector<fea::RodProblem>& cases, int elements, WorkerPool& pool, BatchResult& out,
                   const CancelToken* cancel) {
    // One workspace per worker, allocated before the work starts.
    std::vector<fea::SolverWorkspace> workspaces(pool.size());
    for (auto& w : workspaces) w.resize(elements);

    std::atomic<std::size_t> next{0};
    const std::size_t total = cases.size();
    pool.runOnAll([&](std::size_t worker) {
        auto& work = workspaces[worker];
        while (true) {
            if (cancel && cancel->requested()) return;
            const std::size_t begin = next.fetch_add(kChunk, std::memory_order_relaxed);
            if (begin >= total) return;
            const std::size_t end = std::min(begin + kChunk, total);
            for (std::size_t i = begin; i < end; ++i) {
                solveOne(cases, i, elements, work, out);
            }
        }
    });
    if (cancel) cancel->throwIfRequested();
}

double maxAbsDifference(const BatchResult& a, const BatchResult& b) {
    if (a.temperatures.size() != b.temperatures.size()) {
        throw std::invalid_argument("Cannot compare batch results of different sizes.");
    }
    double worst = 0.0;
    for (std::size_t i = 0; i < a.temperatures.size(); ++i) {
        worst = std::max(worst, std::fabs(a.temperatures[i] - b.temperatures[i]));
    }
    return worst;
}

double median(std::vector<double> values) {
    if (values.empty()) return 0.0;
    std::sort(values.begin(), values.end());
    const std::size_t mid = values.size() / 2;
    return values.size() % 2 ? values[mid] : 0.5 * (values[mid - 1] + values[mid]);
}

void validate(const BenchmarkConfig& c) {
    validate(c.batch);
    if (c.maxWorkers < 1 || c.maxWorkers > 64) {
        throw std::invalid_argument("Maximum workers must be between 1 and 64.");
    }
    if (c.warmupRuns < 0 || c.warmupRuns > 10) {
        throw std::invalid_argument("Warm-up runs must be between 0 and 10.");
    }
    if (c.measuredRuns < 1 || c.measuredRuns > 50) {
        throw std::invalid_argument("Measured runs must be between 1 and 50.");
    }
}

BenchmarkReport runBenchmark(const BenchmarkConfig& config, const ProgressCallback& progress,
                             const CancelToken* cancel) {
    validate(config);
    BenchmarkReport report;
    report.config = config;
    report.system = platform::querySystemInfo();

    const unsigned logical = std::max(1u, report.system.logicalCores);
    const int cap = std::min(config.maxWorkers, static_cast<int>(logical));
    std::vector<int> workerCounts;
    for (int p = 1; p <= cap; ++p) workerCounts.push_back(p);
    report.speedupAssessable = logical > 1;
    if (!report.speedupAssessable) {
        report.notes.push_back("Only one logical CPU is available: the parallel path is exercised with one worker, "
                               "but speedup cannot be assessed on this machine.");
    }
    if (cap < config.maxWorkers) {
        report.notes.push_back("Worker count capped at " + std::to_string(cap) + " (available logical CPUs).");
    }

    const auto genStart = Clock::now();
    const auto cases = generateBatch(config.batch);
    report.generationMs = millisecondsSince(genStart);

    const int elements = config.batch.elements;
    BatchResult reference, trial;
    reference.resize(config.batch.caseCount, elements);
    trial.resize(config.batch.caseCount, elements);

    const int runsPerConfig = config.warmupRuns + config.measuredRuns;
    const int totalRuns = runsPerConfig * static_cast<int>(1 + workerCounts.size());
    int completedRuns = 0;
    auto tick = [&](const std::string& stage) {
        ++completedRuns;
        if (progress) progress(static_cast<double>(completedRuns) / totalRuns, stage);
    };

    // Serial reference.
    TimingRow serialRow;
    serialRow.label = "serial";
    for (int run = 0; run < runsPerConfig; ++run) {
        const bool warm = run < config.warmupRuns;
        const auto start = Clock::now();
        solveSerial(cases, elements, reference, cancel);
        const double ms = millisecondsSince(start);
        if (!warm) serialRow.runMs.push_back(ms);
        tick(std::string("Serial loop, ") + (warm ? "warm-up" : "run " + std::to_string(run - config.warmupRuns + 1)));
    }
    report.rows.push_back(serialRow);

    // Worker pool, p = 1..cap. The pool is constructed outside the timed region.
    for (int p : workerCounts) {
        WorkerPool pool(static_cast<std::size_t>(p));
        TimingRow row;
        row.label = "pool";
        row.workers = p;
        for (int run = 0; run < runsPerConfig; ++run) {
            const bool warm = run < config.warmupRuns;
            std::fill(trial.temperatures.begin(), trial.temperatures.end(), 0.0);
            const auto start = Clock::now();
            solveParallel(cases, elements, pool, trial, cancel);
            const double ms = millisecondsSince(start);
            if (!warm) {
                row.runMs.push_back(ms);
                row.maxAbsDiffC = std::max(row.maxAbsDiffC, maxAbsDifference(reference, trial));
            }
            tick(std::to_string(p) + " worker(s), " +
                 (warm ? "warm-up" : "run " + std::to_string(run - config.warmupRuns + 1)));
        }
        report.rows.push_back(row);
    }

    double t1 = 0.0;
    report.agreementPassed = true;
    for (auto& row : report.rows) {
        row.medianMs = median(row.runMs);
        row.minMs = *std::min_element(row.runMs.begin(), row.runMs.end());
        row.maxMs = *std::max_element(row.runMs.begin(), row.runMs.end());
        if (row.workers == 1) t1 = row.medianMs;
        if (row.maxAbsDiffC > report.agreementToleranceC) report.agreementPassed = false;
    }
    for (auto& row : report.rows) {
        if (row.workers >= 1 && row.medianMs > 0.0 && t1 > 0.0) {
            row.speedup = t1 / row.medianMs;
            row.efficiency = row.speedup / row.workers;
        }
    }
    for (double e : reference.maxMidpointError) report.checksum += e;
    return report;
}

}  // namespace wb::parallel
