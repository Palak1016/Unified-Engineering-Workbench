#include "core/parallel/worker_pool.hpp"

#include <stdexcept>

namespace wb::parallel {

WorkerPool::WorkerPool(std::size_t workerCount) {
    if (workerCount == 0) {
        throw std::invalid_argument("Worker pool needs at least one worker.");
    }
    threads_.reserve(workerCount);
    for (std::size_t i = 0; i < workerCount; ++i) {
        threads_.emplace_back([this, i] { workerLoop(i); });
    }
}

WorkerPool::~WorkerPool() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stopping_ = true;
    }
    wake_.notify_all();
    for (auto& thread : threads_) {
        thread.join();
    }
}

void WorkerPool::runOnAll(const std::function<void(std::size_t)>& task) {
    std::unique_lock<std::mutex> lock(mutex_);
    task_ = &task;
    pending_ = threads_.size();
    firstError_ = nullptr;
    ++generation_;
    wake_.notify_all();
    done_.wait(lock, [this] { return pending_ == 0; });
    task_ = nullptr;
    if (firstError_) {
        std::rethrow_exception(firstError_);
    }
}

void WorkerPool::workerLoop(std::size_t index) {
    std::size_t seenGeneration = 0;
    while (true) {
        const std::function<void(std::size_t)>* task = nullptr;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            wake_.wait(lock, [&] { return stopping_ || generation_ != seenGeneration; });
            if (stopping_) {
                return;
            }
            seenGeneration = generation_;
            task = task_;
        }
        std::exception_ptr error;
        try {
            (*task)(index);
        } catch (...) {
            error = std::current_exception();
        }
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (error && !firstError_) {
                firstError_ = error;
            }
            if (--pending_ == 0) {
                done_.notify_one();
            }
        }
    }
}

}  // namespace wb::parallel
