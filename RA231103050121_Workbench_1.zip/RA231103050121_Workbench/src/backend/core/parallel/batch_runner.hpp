#pragma once

#include "core/fea/rod_fea.hpp"
#include "core/parallel/cancellation.hpp"
#include "core/parallel/worker_pool.hpp"
#include "core/platform/system_info.hpp"

#include <cstdint>
#include <string>
#include <vector>

namespace wb::parallel {

struct BatchConfig {
    std::uint64_t seed = 20260101;
    int caseCount = 800;
    int elements = 10'000;
    // Ranges for the randomised material/load values. L, A and the boundary
    // temperatures come from `base` and are the same for every case.
    double kMin = 2.0, kMax = 50.0;        // W/(m K)
    double qMin = 1.0e3, qMax = 1.0e5;     // W/m^3
    fea::RodProblem base{};
};

constexpr int kMaxBatchCases = 100'000;
constexpr long long kMaxBatchNodes = 16'000'000;  // per result buffer (128 MB of doubles)

void validate(const BatchConfig& config);

// Deterministic across compilers and platforms: uses std::mt19937_64 (whose
// output sequence is fixed by the C++ standard) and maps bits to [0,1) by hand,
// because std::uniform_real_distribution is implementation-defined.
std::vector<fea::RodProblem> generateBatch(const BatchConfig& config);

struct BatchResult {
    int caseCount = 0;
    int nodesPerCase = 0;
    std::vector<double> temperatures;      // caseCount x nodesPerCase, input order
    std::vector<double> maxMidpointError;  // per case, against the analytical solution

    void resize(int cases, int elements);
};

// Plain loop, no threads. Reference result for agreement checks.
void solveSerial(const std::vector<fea::RodProblem>& cases, int elements, BatchResult& out,
                 const CancelToken* cancel = nullptr);

// Same numerical method on a bounded worker pool. Cases are handed out in
// small chunks through an atomic counter; every case writes only to its own
// slice of `out`, so the result order matches the input order regardless of
// which worker solved it.
void solveParallel(const std::vector<fea::RodProblem>& cases, int elements, WorkerPool& pool, BatchResult& out,
                   const CancelToken* cancel = nullptr);

double maxAbsDifference(const BatchResult& a, const BatchResult& b);

struct BenchmarkConfig {
    BatchConfig batch;
    int maxWorkers = 4;     // capped at the number of logical CPUs
    int warmupRuns = 1;
    int measuredRuns = 5;
};

void validate(const BenchmarkConfig& config);

struct TimingRow {
    std::string label;          // "serial" or "pool"
    int workers = 0;            // 0 for the plain serial loop
    std::vector<double> runMs;  // measured repetitions, wall clock
    double medianMs = 0.0;
    double minMs = 0.0;
    double maxMs = 0.0;
    double speedup = 0.0;       // T1 / Tp, T1 = median of the 1-worker pool
    double efficiency = 0.0;    // speedup / p
    double maxAbsDiffC = 0.0;   // against the serial reference, all repetitions
};

struct BenchmarkReport {
    BenchmarkConfig config;
    platform::SystemInfo system;
    double generationMs = 0.0;
    std::vector<TimingRow> rows;
    double agreementToleranceC = 1e-8;
    bool agreementPassed = false;
    bool speedupAssessable = true;   // false on a single-logical-CPU machine
    double checksum = 0.0;           // sum of per-case midpoint errors (sanity value)
    std::vector<std::string> notes;
};

BenchmarkReport runBenchmark(const BenchmarkConfig& config, const ProgressCallback& progress = {},
                             const CancelToken* cancel = nullptr);

double median(std::vector<double> values);

}  // namespace wb::parallel
