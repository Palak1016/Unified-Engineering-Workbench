#pragma once

#include <condition_variable>
#include <cstddef>
#include <exception>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>

namespace wb::parallel {

// Fixed-size pool of worker threads. The pool is created once and reused for
// every measured repetition, so thread start-up cost is not part of the timed
// compute. Work is submitted as a single "run on every worker" job; each worker
// receives its index so it can use its own scratch memory.
class WorkerPool {
public:
    explicit WorkerPool(std::size_t workerCount);
    ~WorkerPool();

    WorkerPool(const WorkerPool&) = delete;
    WorkerPool& operator=(const WorkerPool&) = delete;

    std::size_t size() const noexcept { return threads_.size(); }

    // Runs task(workerIndex) once on every worker and blocks until all return.
    // If a task throws, the first exception is rethrown here after all workers finish.
    void runOnAll(const std::function<void(std::size_t)>& task);

private:
    void workerLoop(std::size_t index);

    std::vector<std::thread> threads_;
    std::mutex mutex_;
    std::condition_variable wake_;
    std::condition_variable done_;
    const std::function<void(std::size_t)>* task_ = nullptr;
    std::size_t generation_ = 0;
    std::size_t pending_ = 0;
    bool stopping_ = false;
    std::exception_ptr firstError_;
};

}  // namespace wb::parallel
