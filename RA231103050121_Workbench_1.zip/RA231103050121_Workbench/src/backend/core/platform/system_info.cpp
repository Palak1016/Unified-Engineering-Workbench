#include "core/platform/system_info.hpp"

#include <thread>

#ifdef _WIN32
#include <windows.h>
#include <vector>
#else
#include <fstream>
#include <set>
#include <sys/utsname.h>
#include <unistd.h>
#include <utility>
#endif

#ifndef WB_RECORDED_FLAGS
#define WB_RECORDED_FLAGS "unknown"
#endif
#ifndef WB_BUILD_TYPE
#define WB_BUILD_TYPE "unknown"
#endif
#ifndef WB_VERSION
#define WB_VERSION "dev"
#endif

namespace wb::platform {

namespace {

std::string compilerDescription() {
#if defined(__clang__)
    return std::string("Clang ") + __clang_version__;
#elif defined(__MINGW64__)
    return std::string("MinGW-w64 GCC ") + __VERSION__;
#elif defined(__GNUC__)
    return std::string("GCC ") + __VERSION__;
#elif defined(_MSC_VER)
    return "MSVC " + std::to_string(_MSC_FULL_VER);
#else
    return "unknown compiler";
#endif
}

#ifdef _WIN32

std::string readCpuName() {
    char buffer[256] = {};
    DWORD size = sizeof(buffer);
    if (RegGetValueA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
                     "ProcessorNameString", RRF_RT_REG_SZ, nullptr, buffer, &size) == ERROR_SUCCESS) {
        std::string name(buffer);
        const auto first = name.find_first_not_of(' ');
        return first == std::string::npos ? name : name.substr(first);
    }
    return "unknown CPU";
}

unsigned countPhysicalCores() {
    DWORD length = 0;
    GetLogicalProcessorInformationEx(RelationProcessorCore, nullptr, &length);
    if (length == 0) {
        return 0;
    }
    std::vector<unsigned char> buffer(length);
    auto* info = reinterpret_cast<SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*>(buffer.data());
    if (!GetLogicalProcessorInformationEx(RelationProcessorCore, info, &length)) {
        return 0;
    }
    unsigned cores = 0;
    for (DWORD offset = 0; offset < length;) {
        auto* entry = reinterpret_cast<SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*>(buffer.data() + offset);
        if (entry->Relationship == RelationProcessorCore) {
            ++cores;
        }
        offset += entry->Size;
    }
    return cores;
}

unsigned countLogicalCores() {
    const DWORD count = GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
    return count > 0 ? static_cast<unsigned>(count) : std::thread::hardware_concurrency();
}

std::uint64_t totalRam() {
    MEMORYSTATUSEX status{};
    status.dwLength = sizeof(status);
    return GlobalMemoryStatusEx(&status) ? status.ullTotalPhys : 0;
}

std::string osDescription() {
    // GetVersionEx is capped by the manifest, so ask ntdll directly.
    using RtlGetVersionFn = LONG(WINAPI*)(PRTL_OSVERSIONINFOW);
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll) {
        auto fn = reinterpret_cast<RtlGetVersionFn>(reinterpret_cast<void*>(GetProcAddress(ntdll, "RtlGetVersion")));
        RTL_OSVERSIONINFOW version{};
        version.dwOSVersionInfoSize = sizeof(version);
        if (fn && fn(&version) == 0) {
            const char* family = version.dwBuildNumber >= 22000 ? "Windows 11" : "Windows 10";
            return std::string(family) + " (build " + std::to_string(version.dwBuildNumber) + ")";
        }
    }
    return "Windows";
}

#else

std::string readCpuName() {
    std::ifstream cpuinfo("/proc/cpuinfo");
    std::string line;
    while (std::getline(cpuinfo, line)) {
        if (line.rfind("model name", 0) == 0) {
            const auto colon = line.find(':');
            if (colon != std::string::npos) {
                return line.substr(line.find_first_not_of(' ', colon + 1));
            }
        }
    }
    return "unknown CPU";
}

unsigned countPhysicalCores() {
    std::ifstream cpuinfo("/proc/cpuinfo");
    std::string line;
    std::set<std::pair<int, int>> cores;
    int physicalId = 0;
    while (std::getline(cpuinfo, line)) {
        const auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        const std::string value = line.substr(colon + 1);
        if (line.rfind("physical id", 0) == 0) {
            physicalId = std::stoi(value);
        } else if (line.rfind("core id", 0) == 0) {
            cores.emplace(physicalId, std::stoi(value));
        }
    }
    return static_cast<unsigned>(cores.size());
}

unsigned countLogicalCores() {
    const long n = sysconf(_SC_NPROCESSORS_ONLN);
    return n > 0 ? static_cast<unsigned>(n) : std::thread::hardware_concurrency();
}

std::uint64_t totalRam() {
    const long pages = sysconf(_SC_PHYS_PAGES);
    const long pageSize = sysconf(_SC_PAGE_SIZE);
    return pages > 0 && pageSize > 0 ? static_cast<std::uint64_t>(pages) * static_cast<std::uint64_t>(pageSize) : 0;
}

std::string osDescription() {
    utsname name{};
    if (uname(&name) == 0) {
        return std::string(name.sysname) + " " + name.release + " " + name.machine;
    }
    return "POSIX";
}

#endif

}  // namespace

SystemInfo querySystemInfo() {
    SystemInfo info;
    info.cpuModel = readCpuName();
    info.logicalCores = countLogicalCores();
    info.physicalCores = countPhysicalCores();
    info.totalRamBytes = totalRam();
    info.operatingSystem = osDescription();
    info.compiler = compilerDescription();
    info.compilerFlags = WB_RECORDED_FLAGS;
    info.buildType = WB_BUILD_TYPE;
    info.appVersion = WB_VERSION;
    return info;
}

}  // namespace wb::platform
