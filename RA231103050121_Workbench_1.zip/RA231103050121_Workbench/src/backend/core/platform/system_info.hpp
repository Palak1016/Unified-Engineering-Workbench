#pragma once

#include <cstdint>
#include <string>

namespace wb::platform {

struct SystemInfo {
    std::string cpuModel;
    unsigned logicalCores = 0;
    unsigned physicalCores = 0;   // 0 if it could not be determined
    std::uint64_t totalRamBytes = 0;
    std::string operatingSystem;
    std::string compiler;
    std::string compilerFlags;
    std::string buildType;
    std::string appVersion;
};

SystemInfo querySystemInfo();

}  // namespace wb::platform
