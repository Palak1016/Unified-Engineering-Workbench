#include "core/io/stl_reader.hpp"

#include "core/io/text_utils.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace wb::io {

void Bounds3::include(double x, double y, double z) noexcept {
    const double p[3] = {x, y, z};
    for (int i = 0; i < 3; ++i) {
        min[i] = std::min(min[i], p[i]);
        max[i] = std::max(max[i], p[i]);
    }
}

std::array<double, 3> Bounds3::size() const noexcept {
    return {max[0] - min[0], max[1] - min[1], max[2] - min[2]};
}

namespace {

// Binary STL files start with an 80-byte header that is allowed to begin with
// "solid", so the first word alone cannot identify ASCII. A NUL byte or a
// file size that exactly matches the binary layout is a reliable signal.
bool looksBinary(std::string_view text) {
    const std::size_t probe = std::min<std::size_t>(text.size(), 4096);
    for (std::size_t i = 0; i < probe; ++i) {
        if (text[i] == '\0') {
            return true;
        }
    }
    if (text.size() >= 84) {
        const auto* bytes = reinterpret_cast<const unsigned char*>(text.data());
        const std::size_t count = static_cast<std::size_t>(bytes[80]) |
                                  (static_cast<std::size_t>(bytes[81]) << 8) |
                                  (static_cast<std::size_t>(bytes[82]) << 16) |
                                  (static_cast<std::size_t>(bytes[83]) << 24);
        if (count > 0 && 84 + 50 * count == text.size() &&
            text.find("facet") == std::string_view::npos) {
            return true;
        }
    }
    return false;
}

enum class State { ExpectSolid, ExpectFacetOrEnd, ExpectOuterLoop, ExpectVertex, ExpectEndLoop, ExpectEndFacet };

const char* expectationText(State state) {
    switch (state) {
        case State::ExpectSolid: return "'solid'";
        case State::ExpectFacetOrEnd: return "'facet normal' or 'endsolid'";
        case State::ExpectOuterLoop: return "'outer loop'";
        case State::ExpectVertex: return "'vertex x y z'";
        case State::ExpectEndLoop: return "'endloop'";
        case State::ExpectEndFacet: return "'endfacet'";
    }
    return "?";
}

double readCoordinate(std::string_view token, std::size_t line, const char* what) {
    const auto value = parseDouble(token);
    if (!value) {
        throw InputError("Line " + std::to_string(line) + ": '" + std::string(token) +
                             "' is not a valid number in the " + what + ".",
                         line);
    }
    if (!std::isfinite(*value)) {
        throw InputError("Line " + std::to_string(line) + ": non-finite value '" + std::string(token) +
                             "' in the " + what + ". NaN and infinity are rejected.",
                         line);
    }
    if (std::fabs(*value) > static_cast<double>(std::numeric_limits<float>::max())) {
        throw InputError("Line " + std::to_string(line) + ": value " + std::string(token) +
                             " is outside single-precision range.",
                         line);
    }
    return *value;
}

}  // namespace

StlMesh parseAsciiStl(std::string_view text, const StlLimits& limits) {
    if (text.empty()) {
        throw InputError("The STL file is empty (0 bytes). Export the geometry again as ASCII STL.");
    }
    if (text.size() > limits.maxBytes) {
        throw InputError("STL file is " + formatBytes(text.size()) + ", above the tested limit of " +
                         formatBytes(limits.maxBytes) + ". Decimate the mesh before importing.");
    }
    if (looksBinary(text)) {
        throw InputError("This looks like a binary STL file. Only ASCII STL is supported; "
                         "re-export with the ASCII/text option enabled.");
    }
    text = stripUtf8Bom(text);
    if (trim(text).empty()) {
        throw InputError("The STL file contains only whitespace, so there is no geometry to show.");
    }

    StlMesh mesh;
    bool boundsInitialised = false;
    State state = State::ExpectSolid;
    float facetNormal[3] = {0, 0, 0};
    double triangle[9] = {};
    int vertexIndex = 0;

    LineCursor cursor(text);
    std::string_view rawLine;
    while (cursor.next(rawLine)) {
        const std::size_t lineNo = cursor.lineNumber();
        const auto tokens = splitWhitespace(rawLine);
        if (tokens.empty()) {
            continue;
        }
        const std::string keyword = toLower(tokens[0]);
        auto unexpected = [&]() {
            return InputError("Line " + std::to_string(lineNo) + ": expected " + expectationText(state) +
                                  " but found '" + std::string(trim(rawLine)).substr(0, 60) + "'.",
                              lineNo);
        };

        switch (state) {
            case State::ExpectSolid: {
                if (keyword != "solid") {
                    throw InputError("Line " + std::to_string(lineNo) +
                                         ": an ASCII STL file must start with 'solid <name>'. "
                                         "Check that this is an STL file.",
                                     lineNo);
                }
                if (mesh.solidCount == 0) {
                    const auto nameStart = trim(rawLine).find_first_of(" \t");
                    if (nameStart != std::string_view::npos) {
                        mesh.solidName = std::string(trim(trim(rawLine).substr(nameStart)));
                    }
                }
                ++mesh.solidCount;
                state = State::ExpectFacetOrEnd;
                break;
            }
            case State::ExpectFacetOrEnd: {
                if (keyword == "endsolid") {
                    state = State::ExpectSolid;
                    break;
                }
                if (keyword != "facet" || tokens.size() != 5 || toLower(tokens[1]) != "normal") {
                    throw unexpected();
                }
                for (int i = 0; i < 3; ++i) {
                    facetNormal[i] = static_cast<float>(readCoordinate(tokens[2 + i], lineNo, "facet normal"));
                }
                state = State::ExpectOuterLoop;
                break;
            }
            case State::ExpectOuterLoop: {
                if (keyword != "outer" || tokens.size() != 2 || toLower(tokens[1]) != "loop") {
                    throw unexpected();
                }
                vertexIndex = 0;
                state = State::ExpectVertex;
                break;
            }
            case State::ExpectVertex: {
                if (keyword != "vertex") {
                    if (keyword == "endloop") {
                        throw InputError("Line " + std::to_string(lineNo) + ": facet has only " +
                                             std::to_string(vertexIndex) + " vertices; exactly 3 are required.",
                                         lineNo);
                    }
                    throw unexpected();
                }
                if (tokens.size() != 4) {
                    throw InputError("Line " + std::to_string(lineNo) + ": a vertex needs exactly 3 coordinates.",
                                     lineNo);
                }
                for (int i = 0; i < 3; ++i) {
                    triangle[vertexIndex * 3 + i] = readCoordinate(tokens[1 + i], lineNo, "vertex");
                }
                if (++vertexIndex == 3) {
                    state = State::ExpectEndLoop;
                }
                break;
            }
            case State::ExpectEndLoop: {
                if (keyword == "vertex") {
                    throw InputError("Line " + std::to_string(lineNo) +
                                         ": facet has more than 3 vertices. Only triangles are valid in STL.",
                                     lineNo);
                }
                if (keyword != "endloop") {
                    throw unexpected();
                }
                state = State::ExpectEndFacet;
                break;
            }
            case State::ExpectEndFacet: {
                if (keyword != "endfacet") {
                    throw unexpected();
                }
                if (mesh.triangleCount() >= limits.maxTriangles) {
                    throw InputError("The mesh has more than " + std::to_string(limits.maxTriangles) +
                                     " triangles, above the tested limit. Decimate it before importing.");
                }
                for (int v = 0; v < 3; ++v) {
                    const double* p = &triangle[v * 3];
                    if (!boundsInitialised) {
                        mesh.bounds.min = mesh.bounds.max = {p[0], p[1], p[2]};
                        boundsInitialised = true;
                    }
                    mesh.bounds.include(p[0], p[1], p[2]);
                    for (int i = 0; i < 3; ++i) {
                        mesh.vertices.push_back(static_cast<float>(p[i]));
                    }
                }
                // Quality checks: zero-area facets and normals that disagree
                // with the right-hand winding. Neither is fatal for display.
                const double ux = triangle[3] - triangle[0], uy = triangle[4] - triangle[1], uz = triangle[5] - triangle[2];
                const double vx = triangle[6] - triangle[0], vy = triangle[7] - triangle[1], vz = triangle[8] - triangle[2];
                const double nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                const double area2 = std::sqrt(nx * nx + ny * ny + nz * nz);
                if (area2 == 0.0) {
                    ++mesh.degenerateTriangles;
                } else {
                    const double dot = nx * facetNormal[0] + ny * facetNormal[1] + nz * facetNormal[2];
                    const bool normalGiven = facetNormal[0] != 0.0f || facetNormal[1] != 0.0f || facetNormal[2] != 0.0f;
                    if (normalGiven && dot < 0.0) {
                        ++mesh.normalMismatches;
                    }
                }
                state = State::ExpectFacetOrEnd;
                break;
            }
        }
    }

    if (state != State::ExpectSolid) {
        throw InputError("Unexpected end of file: expected " + std::string(expectationText(state)) +
                         ". The file may be truncated.");
    }
    if (mesh.triangleCount() == 0) {
        throw InputError("The STL file is structurally valid but contains no facets, so there is nothing to display.");
    }
    if (mesh.degenerateTriangles > 0) {
        mesh.warnings.push_back(std::to_string(mesh.degenerateTriangles) +
                                " zero-area triangle(s) found; they are kept but will not be visible.");
    }
    if (mesh.normalMismatches > 0) {
        mesh.warnings.push_back(std::to_string(mesh.normalMismatches) +
                                " facet normal(s) disagree with the vertex winding; the viewer recomputes normals.");
    }
    if (mesh.solidCount > 1) {
        mesh.warnings.push_back("File contains " + std::to_string(mesh.solidCount) +
                                " solids; they are shown together.");
    }
    return mesh;
}

StlMesh readAsciiStlFile(const std::filesystem::path& path, const StlLimits& limits) {
    const std::string content = readFileLimited(path, limits.maxBytes);
    return parseAsciiStl(content, limits);
}

}  // namespace wb::io
