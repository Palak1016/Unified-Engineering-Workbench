#pragma once

#include "core/io/stl_reader.hpp"  // Bounds3

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>

namespace wb::io {

struct NodalCsvLimits {
    std::size_t maxBytes = 64u * 1024u * 1024u;
    std::size_t maxNodes = 1'000'000;
};

// Nodal temperature results in the column layout
//   node_id,x_m,y_m,z_m,temperature_C
// Coordinates are metres, temperatures degrees Celsius. Stored as structure of
// arrays so it can be handed to the renderer without reshaping.
struct NodalTemperatureField {
    std::vector<std::int64_t> nodeIds;
    std::vector<double> xyz;          // 3 values per node, metres
    std::vector<double> temperature;  // degrees Celsius
    Bounds3 bounds;
    double minTemperature = 0.0;
    double maxTemperature = 0.0;
    std::vector<std::string> comments;  // '#' lines, e.g. provenance notes
    std::vector<std::string> warnings;
    bool declaredSynthetic = false;     // a comment line contains "SYNTHETIC"

    std::size_t size() const noexcept { return nodeIds.size(); }
};

// Parses the CSV text. Rules:
//  - header must contain the five required column names (any order, case-insensitive);
//  - lines starting with '#' are comments; blank lines are ignored;
//  - every value must be numeric and finite; node ids must be positive and unique;
//  - temperatures below absolute zero (-273.15 C) are rejected.
NodalTemperatureField parseNodalTemperatureCsv(std::string_view text, const NodalCsvLimits& limits = {});
NodalTemperatureField readNodalTemperatureCsv(const std::filesystem::path& path, const NodalCsvLimits& limits = {});

}  // namespace wb::io
