#pragma once

#include <array>
#include <cstddef>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>

namespace wb::io {

struct Bounds3 {
    std::array<double, 3> min{0.0, 0.0, 0.0};
    std::array<double, 3> max{0.0, 0.0, 0.0};

    void include(double x, double y, double z) noexcept;
    std::array<double, 3> size() const noexcept;
};

struct StlLimits {
    std::size_t maxBytes = 64u * 1024u * 1024u;   // tested up to this size
    std::size_t maxTriangles = 1'000'000;
};

// Triangle soup read from an ASCII STL file. STL carries no unit; the viewer
// treats coordinates as millimetres unless the user selects otherwise, and the
// unit choice is kept outside this struct on purpose.
struct StlMesh {
    std::string solidName;
    std::size_t solidCount = 0;
    std::vector<float> vertices;     // 9 floats per triangle (v0, v1, v2)
    Bounds3 bounds;
    std::size_t degenerateTriangles = 0;
    std::size_t normalMismatches = 0;  // stored normal disagrees with winding
    std::vector<std::string> warnings;

    std::size_t triangleCount() const noexcept { return vertices.size() / 9; }
};

// Parses ASCII STL text. Throws InputError with a line number on any
// structural or numeric problem (binary data, missing keywords, NaN/Inf, etc.).
StlMesh parseAsciiStl(std::string_view text, const StlLimits& limits = {});
StlMesh readAsciiStlFile(const std::filesystem::path& path, const StlLimits& limits = {});

}  // namespace wb::io
