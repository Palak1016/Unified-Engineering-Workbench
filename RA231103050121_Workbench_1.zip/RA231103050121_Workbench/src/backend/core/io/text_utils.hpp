#pragma once

#include <cstddef>
#include <filesystem>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace wb::io {

// Error raised for any input file problem. The message is written for the
// person using the tool: it says what is wrong and, where possible, what to do.
class InputError : public std::runtime_error {
public:
    InputError(std::string message, std::size_t line = 0)
        : std::runtime_error(std::move(message)), line_(line) {}

    // 1-based line number, or 0 when the problem is not tied to a line.
    std::size_t line() const noexcept { return line_; }

private:
    std::size_t line_;
};

std::string_view trim(std::string_view text) noexcept;

// Splits on runs of spaces/tabs. Empty tokens are never produced.
std::vector<std::string_view> splitWhitespace(std::string_view line);

// Splits on a single delimiter, keeping empty fields.
std::vector<std::string_view> splitDelimited(std::string_view line, char delimiter);

// Locale-independent parse of a whole token. Returns nullopt if the token is
// not entirely a number. Non-finite values (nan, inf) are returned as parsed;
// callers decide whether to accept them.
std::optional<double> parseDouble(std::string_view token) noexcept;
std::optional<long long> parseInteger(std::string_view token) noexcept;

// Reads a whole file into memory, refusing files larger than maxBytes.
std::string readFileLimited(const std::filesystem::path& path, std::size_t maxBytes);

// Iterates over lines, accepting LF and CRLF endings.
class LineCursor {
public:
    explicit LineCursor(std::string_view text) : text_(text) {}
    bool next(std::string_view& line);
    std::size_t lineNumber() const noexcept { return lineNumber_; }

private:
    std::string_view text_;
    std::size_t pos_ = 0;
    std::size_t lineNumber_ = 0;
};

std::string_view stripUtf8Bom(std::string_view text) noexcept;
std::string toLower(std::string_view text);
std::string formatBytes(std::size_t bytes);

}  // namespace wb::io
