#include "core/io/nodal_csv_reader.hpp"

#include "core/io/text_utils.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <unordered_map>

namespace wb::io {

namespace {

constexpr std::array<const char*, 5> kRequiredColumns = {"node_id", "x_m", "y_m", "z_m", "temperature_c"};
constexpr double kAbsoluteZeroC = -273.15;

std::string lineRef(std::size_t line) { return "Line " + std::to_string(line) + ": "; }

}  // namespace

NodalTemperatureField parseNodalTemperatureCsv(std::string_view text, const NodalCsvLimits& limits) {
    if (text.empty()) {
        throw InputError("The CSV file is empty (0 bytes). Expected a header line "
                         "'node_id,x_m,y_m,z_m,temperature_C' followed by one row per node.");
    }
    if (text.size() > limits.maxBytes) {
        throw InputError("CSV file is " + formatBytes(text.size()) + ", above the tested limit of " +
                         formatBytes(limits.maxBytes) + ".");
    }
    text = stripUtf8Bom(text);

    NodalTemperatureField field;
    std::array<int, 5> columnIndex{-1, -1, -1, -1, -1};
    std::size_t columnCount = 0;
    bool headerSeen = false;
    std::unordered_map<std::int64_t, std::size_t> firstLineOfId;

    LineCursor cursor(text);
    std::string_view rawLine;
    while (cursor.next(rawLine)) {
        const std::size_t lineNo = cursor.lineNumber();
        const auto line = trim(rawLine);
        if (line.empty()) {
            continue;
        }
        if (line.front() == '#') {
            std::string comment(trim(line.substr(1)));
            if (toLower(comment).find("synthetic") != std::string::npos) {
                field.declaredSynthetic = true;
            }
            field.comments.push_back(std::move(comment));
            continue;
        }
        if (line.find('\0') != std::string_view::npos) {
            throw InputError(lineRef(lineNo) + "binary data found. This does not look like a text CSV file.", lineNo);
        }

        const auto fields = splitDelimited(line, ',');

        if (!headerSeen) {
            columnCount = fields.size();
            for (std::size_t c = 0; c < fields.size(); ++c) {
                const std::string name = toLower(trim(fields[c]));
                for (std::size_t r = 0; r < kRequiredColumns.size(); ++r) {
                    if (name == kRequiredColumns[r]) {
                        if (columnIndex[r] != -1) {
                            throw InputError(lineRef(lineNo) + "column '" + name + "' appears twice in the header.", lineNo);
                        }
                        columnIndex[r] = static_cast<int>(c);
                    }
                }
            }
            std::string missing;
            for (std::size_t r = 0; r < kRequiredColumns.size(); ++r) {
                if (columnIndex[r] == -1) {
                    missing += missing.empty() ? "" : ", ";
                    missing += r == 4 ? "temperature_C" : kRequiredColumns[r];
                }
            }
            if (!missing.empty()) {
                const bool firstIsNumber = !fields.empty() && parseDouble(fields[0]).has_value();
                throw InputError(lineRef(lineNo) + "header is missing column(s): " + missing + ". " +
                                     (firstIsNumber ? "The first line looks like data; add the header "
                                                      "'node_id,x_m,y_m,z_m,temperature_C'."
                                                    : "Expected 'node_id,x_m,y_m,z_m,temperature_C'."),
                                 lineNo);
            }
            if (columnCount > kRequiredColumns.size()) {
                field.warnings.push_back("Header has " + std::to_string(columnCount - kRequiredColumns.size()) +
                                         " extra column(s); they are ignored.");
            }
            headerSeen = true;
            continue;
        }

        if (fields.size() != columnCount) {
            throw InputError(lineRef(lineNo) + "expected " + std::to_string(columnCount) + " values but found " +
                                 std::to_string(fields.size()) + ". Check for missing or extra commas.",
                             lineNo);
        }
        if (field.size() >= limits.maxNodes) {
            throw InputError("More than " + std::to_string(limits.maxNodes) +
                             " nodes; this is above the tested limit for the point-cloud viewer.");
        }

        const auto idText = trim(fields[static_cast<std::size_t>(columnIndex[0])]);
        auto id = parseInteger(idText);
        if (!id) {
            // Some exporters write node numbers as "12.0".
            const auto asDouble = parseDouble(idText);
            if (asDouble && std::isfinite(*asDouble) && std::floor(*asDouble) == *asDouble) {
                id = static_cast<long long>(*asDouble);
            }
        }
        if (!id) {
            throw InputError(lineRef(lineNo) + "node_id '" + std::string(idText) + "' is not an integer.", lineNo);
        }
        if (*id <= 0) {
            throw InputError(lineRef(lineNo) + "node_id must be a positive integer, found " + std::to_string(*id) + ".",
                             lineNo);
        }
        const auto [it, inserted] = firstLineOfId.emplace(*id, lineNo);
        if (!inserted) {
            throw InputError(lineRef(lineNo) + "duplicate node_id " + std::to_string(*id) + " (first seen on line " +
                                 std::to_string(it->second) + ").",
                             lineNo);
        }

        static const char* const names[] = {"node_id", "x_m", "y_m", "z_m", "temperature_C"};
        double values[4];
        for (int v = 0; v < 4; ++v) {
            const auto token = trim(fields[static_cast<std::size_t>(columnIndex[v + 1])]);
            const auto parsed = parseDouble(token);
            if (!parsed) {
                throw InputError(lineRef(lineNo) + names[v + 1] + " value '" + std::string(token) + "' is not a number.",
                                 lineNo);
            }
            if (!std::isfinite(*parsed)) {
                throw InputError(lineRef(lineNo) + names[v + 1] + " is non-finite ('" + std::string(token) +
                                     "'). NaN and infinity are rejected.",
                                 lineNo);
            }
            values[v] = *parsed;
        }
        if (values[3] < kAbsoluteZeroC) {
            throw InputError(lineRef(lineNo) + "temperature " + std::to_string(values[3]) +
                                 " C is below absolute zero. Check that the column is in Celsius, not another unit.",
                             lineNo);
        }

        if (field.size() == 0) {
            field.bounds.min = field.bounds.max = {values[0], values[1], values[2]};
            field.minTemperature = field.maxTemperature = values[3];
        }
        field.bounds.include(values[0], values[1], values[2]);
        field.minTemperature = std::min(field.minTemperature, values[3]);
        field.maxTemperature = std::max(field.maxTemperature, values[3]);
        field.nodeIds.push_back(*id);
        field.xyz.insert(field.xyz.end(), {values[0], values[1], values[2]});
        field.temperature.push_back(values[3]);
    }

    if (!headerSeen) {
        throw InputError("The CSV file has no header or data (only blank or comment lines). Expected "
                         "'node_id,x_m,y_m,z_m,temperature_C' followed by node rows.");
    }
    if (field.size() == 0) {
        throw InputError("The CSV file has a valid header but no data rows, so there are no nodes to display.");
    }
    const auto extent = field.bounds.size();
    const double largest = std::max({extent[0], extent[1], extent[2]});
    if (largest > 100.0) {
        field.warnings.push_back("Model extent is " + std::to_string(largest) +
                                 " m. If the export was in millimetres, convert coordinates to metres.");
    }
    if (field.maxTemperature == field.minTemperature) {
        field.warnings.push_back("All nodes have the same temperature; the colour scale is flat.");
    }
    return field;
}

NodalTemperatureField readNodalTemperatureCsv(const std::filesystem::path& path, const NodalCsvLimits& limits) {
    const std::string content = readFileLimited(path, limits.maxBytes);
    return parseNodalTemperatureCsv(content, limits);
}

}  // namespace wb::io
