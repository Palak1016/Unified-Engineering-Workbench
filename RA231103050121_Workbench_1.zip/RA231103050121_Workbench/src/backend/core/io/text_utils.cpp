#include "core/io/text_utils.hpp"

#include <cctype>
#include <charconv>
#include <cstdio>
#include <fstream>
#include <system_error>

namespace wb::io {

std::string_view trim(std::string_view text) noexcept {
    const char* whitespace = " \t\r\n\v\f";
    const auto first = text.find_first_not_of(whitespace);
    if (first == std::string_view::npos) {
        return {};
    }
    const auto last = text.find_last_not_of(whitespace);
    return text.substr(first, last - first + 1);
}

std::vector<std::string_view> splitWhitespace(std::string_view line) {
    std::vector<std::string_view> tokens;
    std::size_t i = 0;
    while (i < line.size()) {
        while (i < line.size() && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r')) {
            ++i;
        }
        const std::size_t start = i;
        while (i < line.size() && line[i] != ' ' && line[i] != '\t' && line[i] != '\r') {
            ++i;
        }
        if (i > start) {
            tokens.push_back(line.substr(start, i - start));
        }
    }
    return tokens;
}

std::vector<std::string_view> splitDelimited(std::string_view line, char delimiter) {
    std::vector<std::string_view> fields;
    std::size_t start = 0;
    while (true) {
        const auto end = line.find(delimiter, start);
        if (end == std::string_view::npos) {
            fields.push_back(line.substr(start));
            break;
        }
        fields.push_back(line.substr(start, end - start));
        start = end + 1;
    }
    return fields;
}

std::optional<double> parseDouble(std::string_view token) noexcept {
    token = trim(token);
    if (token.empty()) {
        return std::nullopt;
    }
    // from_chars rejects a leading '+', which some exporters write.
    if (token.front() == '+') {
        token.remove_prefix(1);
    }
    double value = 0.0;
    const auto [end, ec] = std::from_chars(token.data(), token.data() + token.size(), value);
    if (ec != std::errc() || end != token.data() + token.size()) {
        return std::nullopt;
    }
    return value;
}

std::optional<long long> parseInteger(std::string_view token) noexcept {
    token = trim(token);
    if (token.empty()) {
        return std::nullopt;
    }
    if (token.front() == '+') {
        token.remove_prefix(1);
    }
    long long value = 0;
    const auto [end, ec] = std::from_chars(token.data(), token.data() + token.size(), value);
    if (ec != std::errc() || end != token.data() + token.size()) {
        return std::nullopt;
    }
    return value;
}

std::string readFileLimited(const std::filesystem::path& path, std::size_t maxBytes) {
    std::error_code ec;
    if (!std::filesystem::exists(path, ec)) {
        throw InputError("File not found: " + path.filename().string());
    }
    if (!std::filesystem::is_regular_file(path, ec)) {
        throw InputError("Not a regular file: " + path.filename().string());
    }
    const auto size = std::filesystem::file_size(path, ec);
    if (ec) {
        throw InputError("Could not read the size of " + path.filename().string());
    }
    if (size > maxBytes) {
        throw InputError("File is " + formatBytes(static_cast<std::size_t>(size)) +
                         ", above the tested limit of " + formatBytes(maxBytes) + ".");
    }
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        throw InputError("Could not open " + path.filename().string() +
                         " for reading (check that it is not locked by another program).");
    }
    std::string content(static_cast<std::size_t>(size), '\0');
    in.read(content.data(), static_cast<std::streamsize>(size));
    if (!in && !in.eof()) {
        throw InputError("Read error while loading " + path.filename().string());
    }
    return content;
}

bool LineCursor::next(std::string_view& line) {
    if (pos_ >= text_.size()) {
        return false;
    }
    auto end = text_.find('\n', pos_);
    if (end == std::string_view::npos) {
        end = text_.size();
    }
    line = text_.substr(pos_, end - pos_);
    if (!line.empty() && line.back() == '\r') {
        line.remove_suffix(1);
    }
    pos_ = end + 1;
    ++lineNumber_;
    return true;
}

std::string_view stripUtf8Bom(std::string_view text) noexcept {
    if (text.size() >= 3 && static_cast<unsigned char>(text[0]) == 0xEF &&
        static_cast<unsigned char>(text[1]) == 0xBB && static_cast<unsigned char>(text[2]) == 0xBF) {
        text.remove_prefix(3);
    }
    return text;
}

std::string toLower(std::string_view text) {
    std::string out(text);
    for (auto& ch : out) {
        ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    }
    return out;
}

std::string formatBytes(std::size_t bytes) {
    char buffer[32];
    if (bytes >= 1024u * 1024u) {
        std::snprintf(buffer, sizeof(buffer), "%.1f MB", static_cast<double>(bytes) / (1024.0 * 1024.0));
    } else if (bytes >= 1024u) {
        std::snprintf(buffer, sizeof(buffer), "%.1f KB", static_cast<double>(bytes) / 1024.0);
    } else {
        std::snprintf(buffer, sizeof(buffer), "%zu bytes", bytes);
    }
    return buffer;
}

}  // namespace wb::io
