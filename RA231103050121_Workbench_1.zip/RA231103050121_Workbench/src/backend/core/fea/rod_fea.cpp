#include "core/fea/rod_fea.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <stdexcept>

namespace wb::fea {

namespace {

constexpr double kAbsoluteZeroC = -273.15;

void requireFinite(double value, const char* name) {
    if (!std::isfinite(value)) {
        throw std::invalid_argument(std::string(name) + " must be a finite number.");
    }
}

void requirePositive(double value, const char* name, const char* unit) {
    requireFinite(value, name);
    if (value <= 0.0) {
        std::ostringstream out;
        out << name << " must be greater than zero (got " << value << " " << unit << ").";
        throw std::invalid_argument(out.str());
    }
}

}  // namespace

void validate(const RodProblem& p) {
    requirePositive(p.length, "Length L", "m");
    requirePositive(p.area, "Cross-section area A", "m^2");
    requirePositive(p.conductivity, "Conductivity k", "W/(m K)");
    requireFinite(p.heatGeneration, "Heat generation q");
    requireFinite(p.tLeft, "T(0)");
    requireFinite(p.tRight, "T(L)");
    if (p.tLeft < kAbsoluteZeroC || p.tRight < kAbsoluteZeroC) {
        throw std::invalid_argument("Boundary temperatures cannot be below absolute zero (-273.15 C).");
    }
}

void validateElementCount(int elements) {
    if (elements < 1 || elements > kMaxElements) {
        throw std::invalid_argument("Number of elements must be between 1 and " + std::to_string(kMaxElements) +
                                    " (got " + std::to_string(elements) + ").");
    }
}

double exactTemperature(const RodProblem& p, double x) {
    return p.tLeft + (p.tRight - p.tLeft) * x / p.length +
           p.heatGeneration / (2.0 * p.conductivity) * x * (p.length - x);
}

void SolverWorkspace::resize(int elements) {
    const auto n = static_cast<std::size_t>(elements + 1);
    if (diag.size() != n) {
        diag.assign(n, 0.0);
        upper.assign(n, 0.0);
        rhs.assign(n, 0.0);
        cprime.assign(n, 0.0);
    }
}

void solveRodInto(const RodProblem& p, int elements, SolverWorkspace& work, double* T) {
    const int n = elements;
    const double h = p.length / n;
    const double ke = p.conductivity * p.area / h;          // element stiffness factor
    const double fe = p.heatGeneration * p.area * h / 2.0;  // consistent load per node
    work.resize(n);
    double* d = work.diag.data();
    double* u = work.upper.data();   // u[i] = K(i, i+1) = K(i+1, i) (symmetric)
    double* r = work.rhs.data();

    // Assembly: loop over elements and scatter the 2x2 element matrix.
    std::fill(d, d + n + 1, 0.0);
    std::fill(r, r + n + 1, 0.0);
    for (int e = 0; e < n; ++e) {
        d[e] += ke;
        d[e + 1] += ke;
        u[e] = -ke;
        r[e] += fe;
        r[e + 1] += fe;
    }
    u[n] = 0.0;

    // Dirichlet conditions by elimination: move the known column to the
    // right-hand side, then replace the row with T_i = value. This keeps the
    // reduced system symmetric and leaves the reaction terms out of the solve.
    T[0] = p.tLeft;
    T[n] = p.tRight;
    if (n == 1) {
        return;  // both nodes prescribed, nothing to solve
    }
    r[1] -= u[0] * p.tLeft;
    r[n - 1] -= u[n - 1] * p.tRight;

    // Thomas algorithm on the interior nodes 1..n-1. Couplings between interior
    // nodes are K(i, i+1) = u[i] for i = 1..n-2. The matrix is symmetric and
    // diagonally dominant, so no pivoting is needed.
    double* cp = work.cprime.data();
    cp[1] = (n - 1 > 1) ? u[1] / d[1] : 0.0;
    r[1] = r[1] / d[1];
    for (int i = 2; i <= n - 1; ++i) {
        const double sub = u[i - 1];                 // K(i, i-1)
        const double denom = d[i] - sub * cp[i - 1];
        cp[i] = (i < n - 1) ? u[i] / denom : 0.0;
        r[i] = (r[i] - sub * r[i - 1]) / denom;
    }
    T[n - 1] = r[n - 1];
    for (int i = n - 2; i >= 1; --i) {
        T[i] = r[i] - cp[i] * T[i + 1];
    }
}

RodSolution solveRod(const RodProblem& problem, int elements) {
    validate(problem);
    validateElementCount(elements);
    RodSolution s;
    s.elements = elements;
    s.elementLength = problem.length / elements;
    s.x.resize(static_cast<std::size_t>(elements) + 1);
    s.T.resize(static_cast<std::size_t>(elements) + 1);
    for (int i = 0; i <= elements; ++i) {
        s.x[static_cast<std::size_t>(i)] = problem.length * i / elements;
    }
    SolverWorkspace work;
    solveRodInto(problem, elements, work, s.T.data());
    return s;
}

double interpolate(const RodSolution& s, double x) {
    if (s.elements <= 0) {
        throw std::invalid_argument("Cannot interpolate an empty solution.");
    }
    const double length = s.x.back();
    if (x <= 0.0) return s.T.front();
    if (x >= length) return s.T.back();
    int e = static_cast<int>(x / s.elementLength);
    e = std::clamp(e, 0, s.elements - 1);
    const auto i = static_cast<std::size_t>(e);
    const double xi = (x - s.x[i]) / (s.x[i + 1] - s.x[i]);  // local coordinate in [0,1]
    return (1.0 - xi) * s.T[i] + xi * s.T[i + 1];
}

double maxMidpointError(const RodProblem& p, int elements, const double* T) {
    const double h = p.length / elements;
    double worst = 0.0;
    for (int e = 0; e < elements; ++e) {
        const double xm = (e + 0.5) * h;
        const double feValue = 0.5 * (T[e] + T[e + 1]);  // linear shape functions at xi = 1/2
        worst = std::max(worst, std::fabs(feValue - exactTemperature(p, xm)));
    }
    return worst;
}

ErrorSummary evaluateErrors(const RodProblem& p, const RodSolution& s) {
    ErrorSummary out;
    for (std::size_t i = 0; i < s.x.size(); ++i) {
        out.maxNodalError = std::max(out.maxNodalError, std::fabs(s.T[i] - exactTemperature(p, s.x[i])));
    }
    for (int e = 0; e < s.elements; ++e) {
        const double xm = (e + 0.5) * s.elementLength;
        const double err = std::fabs(interpolate(s, xm) - exactTemperature(p, xm));
        if (err > out.maxMidpointError) {
            out.maxMidpointError = err;
            out.xAtMaxMidpointError = xm;
        }
    }
    return out;
}

ConvergenceStudy runConvergenceStudy(const RodProblem& problem, const std::vector<int>& meshes) {
    validate(problem);
    if (meshes.empty()) {
        throw std::invalid_argument("Select at least one mesh size.");
    }
    ConvergenceStudy study;
    study.problem = problem;
    for (std::size_t m = 0; m < meshes.size(); ++m) {
        RodSolution s = solveRod(problem, meshes[m]);
        const ErrorSummary err = evaluateErrors(problem, s);
        ConvergenceRow row;
        row.elements = meshes[m];
        row.h = s.elementLength;
        row.maxNodalError = err.maxNodalError;
        row.maxMidpointError = err.maxMidpointError;
        row.xAtMaxMidpointError = err.xAtMaxMidpointError;
        row.predictedMidpointError = std::fabs(problem.heatGeneration) * row.h * row.h / (8.0 * problem.conductivity);
        if (m > 0) {
            const auto& prev = study.rows.back();
            if (prev.maxMidpointError > 0.0 && row.maxMidpointError > 0.0 && prev.h != row.h) {
                row.observedOrder = std::log(prev.maxMidpointError / row.maxMidpointError) / std::log(prev.h / row.h);
            }
        }
        study.rows.push_back(row);
        study.solutions.push_back(std::move(s));
    }
    return study;
}

}  // namespace wb::fea
