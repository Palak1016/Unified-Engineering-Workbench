#pragma once

#include <string>
#include <vector>

namespace wb::fea {

// Steady 1D conduction in a uniform rod with insulated lateral surface:
//     -d/dx( k A dT/dx ) = q A,   0 < x < L
//     T(0) = tLeft,  T(L) = tRight
// Units: metres, m^2, W/(m K), W/m^3, degrees Celsius.
struct RodProblem {
    double length = 1.0;           // L [m]
    double area = 1.0e-4;          // A [m^2]
    double conductivity = 10.0;    // k [W/(m K)]
    double heatGeneration = 1.0e4; // q [W/m^3]
    double tLeft = 100.0;          // T(0) [C]
    double tRight = 20.0;          // T(L) [C]
};

// Throws std::invalid_argument with a user-facing message if any value is
// non-finite, non-positive where it must be positive, or below absolute zero.
void validate(const RodProblem& problem);
void validateElementCount(int elements);

constexpr int kMaxElements = 2'000'000;

// Closed-form solution for constant k, A, q:
//   T(x) = tLeft + (tRight - tLeft) x / L + q / (2k) * x (L - x)
double exactTemperature(const RodProblem& problem, double x);

struct RodSolution {
    int elements = 0;
    double elementLength = 0.0;
    std::vector<double> x;  // nodal coordinates, N+1 values
    std::vector<double> T;  // nodal temperatures, N+1 values
};

// Reusable scratch memory so the batch runner can solve many rods without
// allocating inside the timed loop.
struct SolverWorkspace {
    std::vector<double> diag, upper, rhs, cprime;
    void resize(int elements);
};

// Assembles the global tridiagonal system from two-node linear elements,
//   k_e = (kA/h) [ 1 -1; -1 1 ],   f_e = (qAh/2) [ 1; 1 ],
// imposes both Dirichlet conditions by elimination, and solves with the Thomas
// algorithm. Writes N+1 nodal temperatures into `temperatures`.
void solveRodInto(const RodProblem& problem, int elements, SolverWorkspace& work, double* temperatures);

RodSolution solveRod(const RodProblem& problem, int elements);

// Linear FE interpolation of the nodal solution at an arbitrary x in [0, L].
double interpolate(const RodSolution& solution, double x);

struct ErrorSummary {
    double maxNodalError = 0.0;     // max |T_h - T_exact| at nodes
    double maxMidpointError = 0.0;  // max |T_h - T_exact| at element midpoints
    double xAtMaxMidpointError = 0.0;
};
ErrorSummary evaluateErrors(const RodProblem& problem, const RodSolution& solution);

// Same midpoint error computed straight from a nodal array (used by the batch runner).
double maxMidpointError(const RodProblem& problem, int elements, const double* temperatures);

struct ConvergenceRow {
    int elements = 0;
    double h = 0.0;
    double maxNodalError = 0.0;
    double maxMidpointError = 0.0;
    double xAtMaxMidpointError = 0.0;
    double observedOrder = 0.0;   // log(e_prev/e)/log(h_prev/h); 0 for the first row
    double predictedMidpointError = 0.0; // q h^2 / (8k), see report section 3
};

struct ConvergenceStudy {
    RodProblem problem;
    std::vector<RodSolution> solutions;
    std::vector<ConvergenceRow> rows;
};

ConvergenceStudy runConvergenceStudy(const RodProblem& problem, const std::vector<int>& meshes);

}  // namespace wb::fea
