#pragma once

#include "core/fea/rod_fea.hpp"
#include "core/ml/backprop.hpp"
#include "core/parallel/batch_runner.hpp"

#include <string>

namespace wb::server {

// All exports use plain comma-separated values with a single header row.
// Metadata, where useful, is written as leading '#' comment lines.

// Nodal values for every mesh: mesh_elements,node,x_m,T_fe_C,T_exact_C,abs_error_C
std::string feaNodalCsv(const fea::ConvergenceStudy& study);
// Element midpoints: mesh_elements,element,x_mid_m,T_fe_C,T_exact_C,abs_error_C
std::string feaMidpointCsv(const fea::ConvergenceStudy& study);
// One row per mesh: elements,h_m,max_nodal_error_C,max_midpoint_error_C,...
std::string feaConvergenceCsv(const fea::ConvergenceStudy& study);

std::string benchmarkCsv(const parallel::BenchmarkReport& report);

std::string backpropHistoryCsv(const std::vector<ml::TrainingRecord>& history);
std::string backpropGradientCsv(const ml::Parameters& p, const ml::Sample& s, double epsilon);

}  // namespace wb::server
