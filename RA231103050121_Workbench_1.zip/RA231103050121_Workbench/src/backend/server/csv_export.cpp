#include "server/csv_export.hpp"

#include <cmath>
#include <cstdio>
#include <sstream>

namespace wb::server {

namespace {

// %.17g keeps full double precision so exported values can be re-checked.
std::string num(double value) {
    char buffer[40];
    std::snprintf(buffer, sizeof(buffer), "%.17g", value);
    return buffer;
}

std::string problemComment(const fea::RodProblem& p) {
    std::ostringstream out;
    out << "# 1D steady conduction, linear 2-node elements\n"
        << "# L_m=" << num(p.length) << " A_m2=" << num(p.area) << " k_W_per_mK=" << num(p.conductivity)
        << " q_W_per_m3=" << num(p.heatGeneration) << " T0_C=" << num(p.tLeft) << " TL_C=" << num(p.tRight) << "\n";
    return out.str();
}

}  // namespace

std::string feaNodalCsv(const fea::ConvergenceStudy& study) {
    std::ostringstream out;
    out << problemComment(study.problem);
    out << "mesh_elements,node,x_m,T_fe_C,T_exact_C,abs_error_C\n";
    for (const auto& s : study.solutions) {
        for (std::size_t i = 0; i < s.x.size(); ++i) {
            const double exact = fea::exactTemperature(study.problem, s.x[i]);
            out << s.elements << ',' << i << ',' << num(s.x[i]) << ',' << num(s.T[i]) << ',' << num(exact) << ','
                << num(std::fabs(s.T[i] - exact)) << '\n';
        }
    }
    return out.str();
}

std::string feaMidpointCsv(const fea::ConvergenceStudy& study) {
    std::ostringstream out;
    out << problemComment(study.problem);
    out << "# T_fe at midpoints uses the linear FE interpolant: (T_i + T_i+1)/2\n";
    out << "mesh_elements,element,x_mid_m,T_fe_C,T_exact_C,abs_error_C\n";
    for (const auto& s : study.solutions) {
        for (int e = 0; e < s.elements; ++e) {
            const double x = (e + 0.5) * s.elementLength;
            const double fe = fea::interpolate(s, x);
            const double exact = fea::exactTemperature(study.problem, x);
            out << s.elements << ',' << e << ',' << num(x) << ',' << num(fe) << ',' << num(exact) << ','
                << num(std::fabs(fe - exact)) << '\n';
        }
    }
    return out.str();
}

std::string feaConvergenceCsv(const fea::ConvergenceStudy& study) {
    std::ostringstream out;
    out << problemComment(study.problem);
    out << "elements,h_m,max_nodal_error_C,max_midpoint_error_C,x_at_max_midpoint_error_m,"
           "predicted_q_h2_over_8k_C,observed_order\n";
    for (const auto& r : study.rows) {
        out << r.elements << ',' << num(r.h) << ',' << num(r.maxNodalError) << ',' << num(r.maxMidpointError) << ','
            << num(r.xAtMaxMidpointError) << ',' << num(r.predictedMidpointError) << ','
            << (r.observedOrder > 0 ? num(r.observedOrder) : "") << '\n';
    }
    return out.str();
}

std::string benchmarkCsv(const parallel::BenchmarkReport& r) {
    std::ostringstream out;
    const auto& s = r.system;
    const auto& b = r.config.batch;
    out << "# cpu=" << s.cpuModel << "\n"
        << "# logical_cores=" << s.logicalCores << " physical_cores=" << s.physicalCores
        << " ram_GiB=" << num(static_cast<double>(s.totalRamBytes) / (1024.0 * 1024.0 * 1024.0)) << "\n"
        << "# os=" << s.operatingSystem << "\n"
        << "# compiler=" << s.compiler << "\n"
        << "# flags=" << s.compilerFlags << " build=" << s.buildType << "\n"
        << "# workload: cases=" << b.caseCount << " elements=" << b.elements << " seed=" << b.seed << " k=[" << b.kMin
        << "," << b.kMax << "] q=[" << b.qMin << "," << b.qMax << "]\n"
        << "# warmup_runs=" << r.config.warmupRuns << " measured_runs=" << r.config.measuredRuns
        << " generation_ms=" << num(r.generationMs) << "\n"
        << "# agreement_tolerance_C=" << num(r.agreementToleranceC)
        << " agreement_passed=" << (r.agreementPassed ? "true" : "false")
        << " speedup_assessable=" << (r.speedupAssessable ? "true" : "false") << "\n";
    out << "config,workers";
    const std::size_t runs = r.rows.empty() ? 0 : r.rows.front().runMs.size();
    for (std::size_t i = 0; i < runs; ++i) out << ",run" << (i + 1) << "_ms";
    out << ",median_ms,min_ms,max_ms,speedup_T1_over_Tp,efficiency,max_abs_diff_vs_serial_C\n";
    for (const auto& row : r.rows) {
        out << row.label << ',' << row.workers;
        for (double ms : row.runMs) out << ',' << num(ms);
        out << ',' << num(row.medianMs) << ',' << num(row.minMs) << ',' << num(row.maxMs) << ','
            << (row.workers ? num(row.speedup) : "") << ',' << (row.workers ? num(row.efficiency) : "") << ','
            << (row.workers ? num(row.maxAbsDiffC) : "") << '\n';
    }
    return out.str();
}

std::string backpropHistoryCsv(const std::vector<ml::TrainingRecord>& history) {
    std::ostringstream out;
    out << "# step 0 = initial parameters; step 1 = the hand-checked update; steps 2.. = subsequent training\n";
    out << "step,w,b,v,c,loss\n";
    for (const auto& rec : history) {
        out << rec.step << ',' << num(rec.params.w) << ',' << num(rec.params.b) << ',' << num(rec.params.v) << ','
            << num(rec.params.c) << ',' << num(rec.loss) << '\n';
    }
    return out.str();
}

std::string backpropGradientCsv(const ml::Parameters& p, const ml::Sample& s, double epsilon) {
    const auto g = ml::analyticGradients(p, s);
    const auto fd = ml::finiteDifferenceGradients(p, s, epsilon);
    std::ostringstream out;
    out << "# central differences, epsilon=" << num(epsilon) << "\n";
    out << "parameter,analytic,finite_difference,abs_error\n";
    const std::pair<const char*, std::pair<double, double>> rows[] = {
        {"w", {g.dw, fd.dw}}, {"b", {g.db, fd.db}}, {"v", {g.dv, fd.dv}}, {"c", {g.dc, fd.dc}}};
    for (const auto& [name, v] : rows) {
        out << name << ',' << num(v.first) << ',' << num(v.second) << ',' << num(std::fabs(v.first - v.second)) << '\n';
    }
    return out.str();
}

}  // namespace wb::server
