#pragma once

// Conversion between core types and the JSON used by the HTTP API. Keeping
// this separate means the core library never depends on a JSON library.

#include "core/fea/rod_fea.hpp"
#include "core/hardware/hardware_manager.hpp"
#include "core/io/nodal_csv_reader.hpp"
#include "core/io/stl_reader.hpp"
#include "core/ml/backprop.hpp"
#include "core/parallel/batch_runner.hpp"
#include "core/platform/system_info.hpp"

#include <nlohmann/json.hpp>

#include <stdexcept>
#include <string>

namespace wb::server {

using nlohmann::json;

// Error that maps directly to an HTTP status and a user-facing message.
class ApiError : public std::runtime_error {
public:
    ApiError(int status, const std::string& message, std::size_t line = 0)
        : std::runtime_error(message), status_(status), line_(line) {}
    int status() const noexcept { return status_; }
    std::size_t line() const noexcept { return line_; }

private:
    int status_;
    std::size_t line_;
};

// Geometry and results. These return serialised text because the vertex
// arrays are large and are written with shortest round-trip formatting.
std::string stlMeshToJsonText(const io::StlMesh& mesh, const std::string& fileName, std::size_t fileBytes,
                              double parseMs);
std::string nodalFieldToJsonText(const io::NodalTemperatureField& field, const std::string& fileName,
                                 std::size_t fileBytes, double parseMs);

fea::RodProblem rodProblemFromJson(const json& body);
std::vector<int> meshListFromJson(const json& body);
json convergenceStudyToJson(const fea::ConvergenceStudy& study, int exactSamples);

parallel::BenchmarkConfig benchmarkConfigFromJson(const json& body);
json benchmarkReportToJson(const parallel::BenchmarkReport& report);
json systemInfoToJson(const platform::SystemInfo& info);

json deviceStatusToJson(const hardware::DeviceStatus& status);
json telemetryToJson(const hardware::TelemetryMessage& message);
json hardwareEventToJson(const hardware::HardwareEvent& event);

struct BackpropRequest {
    ml::Parameters start{};
    ml::Sample sample{};
    double learningRate = 0.1;
    int steps = 100;
    double epsilon = 1e-6;
    double tolerance = 1e-5;
};
BackpropRequest backpropRequestFromJson(const json& body);
json backpropToJson(const BackpropRequest& request);

}  // namespace wb::server
