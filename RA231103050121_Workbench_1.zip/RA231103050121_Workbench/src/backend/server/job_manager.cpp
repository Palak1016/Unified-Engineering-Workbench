#include "server/job_manager.hpp"

#include <stdexcept>

namespace wb::server {

const char* toString(JobState state) {
    switch (state) {
        case JobState::Running: return "running";
        case JobState::Completed: return "completed";
        case JobState::Cancelled: return "cancelled";
        case JobState::Failed: return "failed";
    }
    return "unknown";
}

JobManager::~JobManager() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (current_) current_->cancel.request();
    }
    if (worker_.joinable()) worker_.join();
}

bool JobManager::busy() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return current_ && current_->state == JobState::Running;
}

std::string JobManager::startBenchmark(const parallel::BenchmarkConfig& config) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (current_ && current_->state == JobState::Running) {
        throw std::runtime_error("A benchmark is already running. Wait for it to finish or cancel it first.");
    }
    if (worker_.joinable()) worker_.join();  // previous job has finished; reclaim its thread

    auto job = std::make_shared<Job>();
    job->id = "bench-" + std::to_string(++counter_);
    job->started = std::chrono::steady_clock::now();
    current_ = job;

    worker_ = std::thread([this, job, config] {
        auto progress = [this, job](double fraction, const std::string& stage) {
            std::lock_guard<std::mutex> guard(mutex_);
            job->progress = fraction;
            job->stage = stage;
        };
        try {
            auto report = parallel::runBenchmark(config, progress, &job->cancel);
            std::lock_guard<std::mutex> guard(mutex_);
            job->report = std::move(report);  // published only after the run is complete
            job->state = JobState::Completed;
            job->progress = 1.0;
            job->stage = "Finished";
            job->finished = std::chrono::steady_clock::now();
        } catch (const parallel::Cancelled&) {
            std::lock_guard<std::mutex> guard(mutex_);
            job->state = JobState::Cancelled;
            job->stage = "Cancelled; no partial results were kept";
            job->finished = std::chrono::steady_clock::now();
        } catch (const std::exception& e) {
            std::lock_guard<std::mutex> guard(mutex_);
            job->state = JobState::Failed;
            job->error = e.what();
            job->stage = "Failed";
            job->finished = std::chrono::steady_clock::now();
        }
        if (onFinished_) {
            if (auto snap = snapshot(job->id)) onFinished_(*snap);
        }
    });
    return job->id;
}

std::optional<JobSnapshot> JobManager::snapshot(const std::string& id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!current_ || current_->id != id) return std::nullopt;
    const auto& job = *current_;
    JobSnapshot s;
    s.id = job.id;
    s.state = job.state;
    s.progress = job.progress;
    s.stage = job.stage;
    s.error = job.error;
    const auto end = job.state == JobState::Running ? std::chrono::steady_clock::now() : job.finished;
    s.elapsedS = std::chrono::duration<double>(end - job.started).count();
    s.report = job.report;
    return s;
}

bool JobManager::cancel(const std::string& id) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!current_ || current_->id != id || current_->state != JobState::Running) return false;
    current_->cancel.request();
    current_->stage = "Cancelling";
    return true;
}

}  // namespace wb::server
