#pragma once

#include "core/hardware/hardware_manager.hpp"
#include "server/job_manager.hpp"
#include "server/logger.hpp"

#include <atomic>
#include <filesystem>
#include <memory>
#include <string>

namespace httplib {
class Server;
}

namespace wb::server {

struct ServerOptions {
    std::filesystem::path webRoot;   // static frontend files
    std::filesystem::path dataDir;   // bundled example files
    std::string host = "127.0.0.1";  // loopback only: nothing is exposed to the network
    int firstPort = 8765;
    int lastPort = 8799;
};

// HTTP transport for the workbench. Routes translate requests into calls on
// the core library and back into JSON/CSV; no numerical work lives here.
class ApiServer {
public:
    ApiServer(ServerOptions options, Logger& logger);
    ~ApiServer();

    // Binds to the first free port in [firstPort, lastPort]. Returns false if none is free.
    bool bind();
    int port() const noexcept { return port_; }
    std::string url() const;

    // Blocks until stop() is called (from any thread or from the shutdown route).
    void run();
    void stop();

    void setLaunchToReadyMs(double ms) { launchToReadyMs_ = ms; }

private:
    void registerRoutes();

    ServerOptions options_;
    Logger& logger_;
    std::unique_ptr<httplib::Server> http_;
    hardware::HardwareManager hardware_;
    JobManager jobs_;
    int port_ = 0;
    std::atomic<double> launchToReadyMs_{0.0};
    std::atomic<double> uiReadyMs_{0.0};
};

}  // namespace wb::server
