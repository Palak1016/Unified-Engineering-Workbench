#include "server/api_server.hpp"

#include "core/io/nodal_csv_reader.hpp"
#include "core/io/stl_reader.hpp"
#include "core/io/text_utils.hpp"
#include "core/platform/system_info.hpp"
#include "server/csv_export.hpp"
#include "server/json_mapping.hpp"

#include <httplib/httplib.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <thread>

namespace wb::server {

namespace {

using Clock = std::chrono::steady_clock;

constexpr std::size_t kMaxUploadBytes = 64u * 1024u * 1024u;

void sendJson(httplib::Response& res, const json& body, int status = 200) {
    res.status = status;
    res.set_content(body.dump(), "application/json");
}

void sendError(httplib::Response& res, int status, const std::string& message, std::size_t line = 0) {
    json body = {{"error", message}};
    if (line > 0) body["line"] = line;
    sendJson(res, body, status);
}

void sendCsv(httplib::Response& res, const std::string& csv, const std::string& fileName) {
    res.set_header("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    res.set_content(csv, "text/csv");
}

json parseBody(const httplib::Request& req) {
    if (req.body.empty()) return json::object();
    try {
        return json::parse(req.body);
    } catch (const json::parse_error&) {
        throw ApiError(400, "Request body is not valid JSON.");
    }
}

std::string fileNameParam(const httplib::Request& req) {
    std::string name = req.has_param("name") ? req.get_param_value("name") : "uploaded file";
    if (name.size() > 200) name.resize(200);
    return name;
}

// Wraps a route so every failure becomes a JSON error with a useful status.
template <typename Fn>
auto guarded(Logger& logger, Fn fn) {
    return [&logger, fn](const httplib::Request& req, httplib::Response& res) {
        try {
            fn(req, res);
        } catch (const ApiError& e) {
            sendError(res, e.status(), e.what(), e.line());
        } catch (const io::InputError& e) {
            sendError(res, 422, e.what(), e.line());
        } catch (const std::invalid_argument& e) {
            sendError(res, 400, e.what());
        } catch (const std::out_of_range& e) {
            sendError(res, 404, e.what());
        } catch (const std::exception& e) {
            logger.error(req.method + " " + req.path + " failed: " + e.what());
            sendError(res, 500, std::string("Internal error: ") + e.what());
        }
    };
}

double elapsedMs(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

struct ExampleFile {
    std::string name;  // relative to the data directory, forward slashes
    std::string kind;  // "stl" | "nodal-csv"
    std::uintmax_t bytes = 0;
};

std::vector<ExampleFile> listExamples(const std::filesystem::path& dataDir) {
    std::vector<ExampleFile> files;
    std::error_code ec;
    if (!std::filesystem::is_directory(dataDir, ec)) return files;
    for (auto it = std::filesystem::recursive_directory_iterator(dataDir, ec);
         it != std::filesystem::recursive_directory_iterator(); it.increment(ec)) {
        if (ec || !it->is_regular_file(ec)) continue;
        const std::string ext = io::toLower(it->path().extension().string());
        const char* kind = ext == ".stl" ? "stl" : ext == ".csv" ? "nodal-csv" : nullptr;
        if (!kind) continue;
        files.push_back({std::filesystem::relative(it->path(), dataDir, ec).generic_string(), kind,
                         it->file_size(ec)});
    }
    std::sort(files.begin(), files.end(), [](const auto& a, const auto& b) { return a.name < b.name; });
    return files;
}

// Only names returned by listExamples are accepted, so the client cannot
// read arbitrary paths.
std::filesystem::path resolveExample(const std::filesystem::path& dataDir, const std::string& name,
                                     const std::string& kind) {
    for (const auto& file : listExamples(dataDir)) {
        if (file.name == name && file.kind == kind) return dataDir / std::filesystem::u8path(name);
    }
    throw ApiError(404, "Example '" + name + "' was not found in the data folder.");
}

hardware::FaultKind faultFromString(const std::string& kind) {
    if (kind == "connect-timeout") return hardware::FaultKind::ConnectTimeout;
    if (kind == "telemetry-timeout") return hardware::FaultKind::TelemetryTimeout;
    if (kind == "none") return hardware::FaultKind::None;
    throw ApiError(400, "Unknown fault '" + kind + "'. Use connect-timeout, telemetry-timeout or none.");
}

json jobToJson(const JobSnapshot& s) {
    json body = {{"id", s.id},
                 {"state", toString(s.state)},
                 {"progress", s.progress},
                 {"stage", s.stage},
                 {"elapsedS", s.elapsedS}};
    if (!s.error.empty()) body["error"] = s.error;
    if (s.report) body["report"] = benchmarkReportToJson(*s.report);
    return body;
}

}  // namespace

ApiServer::ApiServer(ServerOptions options, Logger& logger)
    : options_(std::move(options)),
      logger_(logger),
      http_(std::make_unique<httplib::Server>()),
      jobs_([&logger](const JobSnapshot& s) {
          char line[256];
          if (s.state == JobState::Completed && s.report) {
              const auto& rows = s.report->rows;
              std::snprintf(line, sizeof(line), "Benchmark %s completed in %.1f s: serial %.1f ms, p=1 %.1f ms, p=%d %.1f ms "
                            "(speedup %.2f), agreement %s.", s.id.c_str(), s.elapsedS, rows.front().medianMs,
                            rows.size() > 1 ? rows[1].medianMs : 0.0, rows.back().workers, rows.back().medianMs,
                            rows.back().speedup, s.report->agreementPassed ? "passed" : "FAILED");
              logger.info(line);
          } else if (s.state == JobState::Cancelled) {
              logger.warn("Benchmark " + s.id + " cancelled after " + std::to_string(static_cast<int>(s.elapsedS * 1000)) +
                          " ms; no results were kept.");
          } else {
              logger.error("Benchmark " + s.id + " failed: " + s.error);
          }
      }) {
    http_->set_payload_max_length(kMaxUploadBytes + 4096);
    http_->new_task_queue = [] { return new httplib::ThreadPool(8); };
    registerRoutes();
}

ApiServer::~ApiServer() { stop(); }

bool ApiServer::bind() {
    for (int p = options_.firstPort; p <= options_.lastPort; ++p) {
        if (http_->bind_to_port(options_.host, p)) {
            port_ = p;
            return true;
        }
    }
    return false;
}

std::string ApiServer::url() const { return "http://" + options_.host + ":" + std::to_string(port_) + "/"; }

void ApiServer::run() { http_->listen_after_bind(); }

void ApiServer::stop() {
    if (http_) http_->stop();
}

void ApiServer::registerRoutes() {
    auto& svr = *http_;
    Logger& log = logger_;

    if (!svr.set_mount_point("/", options_.webRoot.string())) {
        logger_.error("Frontend folder not found: " + options_.webRoot.string());
    }

    svr.set_logger([&log](const httplib::Request& req, const httplib::Response& res) {
        const bool poll = req.method == "GET" &&
                          (req.path.rfind("/api/jobs/", 0) == 0 || req.path.find("/telemetry") != std::string::npos ||
                           req.path == "/api/hardware/events");
        if (req.path.rfind("/api/", 0) == 0 && (!poll || res.status >= 400)) {
            log.info(req.method + " " + req.path + " -> " + std::to_string(res.status));
        }
    });
    svr.set_error_handler([](const httplib::Request& req, httplib::Response& res) {
        if (req.path.rfind("/api/", 0) == 0 && res.body.empty()) {
            const std::string message = res.status == 413 ? "Upload is larger than the 64 MB limit."
                                                          : "No API route for " + req.method + " " + req.path + ".";
            sendError(res, res.status, message);
        }
    });

    // ---- General -----------------------------------------------------------
    svr.Get("/api/health", guarded(log, [this](const httplib::Request&, httplib::Response& res) {
        sendJson(res, {{"status", "ok"}, {"launchToReadyMs", launchToReadyMs_.load()}, {"uiReadyMs", uiReadyMs_.load()}});
    }));
    svr.Get("/api/system", guarded(log, [this](const httplib::Request&, httplib::Response& res) {
        json body = systemInfoToJson(platform::querySystemInfo());
        body["launchToReadyMs"] = launchToReadyMs_.load();
        body["uiReadyMs"] = uiReadyMs_.load();
        body["logFile"] = logger_.filePath().filename().string();
        sendJson(res, body);
    }));
    svr.Post("/api/ui-ready", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const json body = parseBody(req);
        if (body.contains("ms") && body["ms"].is_number()) {
            uiReadyMs_ = body["ms"].get<double>();
            logger_.info("Frontend reported first interactive render after " + std::to_string(uiReadyMs_.load()) +
                         " ms (page navigation to ready).");
        }
        sendJson(res, {{"ok", true}});
    }));
    svr.Post("/api/shutdown", guarded(log, [this](const httplib::Request&, httplib::Response& res) {
        logger_.info("Shutdown requested from the interface.");
        sendJson(res, {{"ok", true}});
        std::thread([this] {
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
            stop();
        }).detach();
    }));

    // ---- Geometry and imported results -------------------------------------
    svr.Get("/api/examples", guarded(log, [this](const httplib::Request&, httplib::Response& res) {
        json list = json::array();
        for (const auto& f : listExamples(options_.dataDir)) {
            list.push_back({{"name", f.name}, {"kind", f.kind}, {"bytes", f.bytes}});
        }
        sendJson(res, list);
    }));

    auto parseStl = [this](const std::string& text, const std::string& name, httplib::Response& res) {
        const auto start = Clock::now();
        const auto mesh = io::parseAsciiStl(text);
        const double ms = elapsedMs(start);
        logger_.info("STL '" + name + "' parsed: " + std::to_string(mesh.triangleCount()) + " triangles in " +
                     std::to_string(ms) + " ms.");
        res.set_content(stlMeshToJsonText(mesh, name, text.size(), ms), "application/json");
    };
    auto parseNodal = [this](const std::string& text, const std::string& name, httplib::Response& res) {
        const auto start = Clock::now();
        const auto field = io::parseNodalTemperatureCsv(text);
        const double ms = elapsedMs(start);
        logger_.info("Nodal CSV '" + name + "' parsed: " + std::to_string(field.size()) + " nodes in " +
                     std::to_string(ms) + " ms.");
        res.set_content(nodalFieldToJsonText(field, name, text.size(), ms), "application/json");
    };

    svr.Post("/api/geometry/stl", guarded(log, [parseStl](const httplib::Request& req, httplib::Response& res) {
        parseStl(req.body, fileNameParam(req), res);
    }));
    svr.Post("/api/results/nodal", guarded(log, [parseNodal](const httplib::Request& req, httplib::Response& res) {
        parseNodal(req.body, fileNameParam(req), res);
    }));
    svr.Get("/api/examples/stl", guarded(log, [this, parseStl](const httplib::Request& req, httplib::Response& res) {
        const auto name = req.get_param_value("name");
        const auto path = resolveExample(options_.dataDir, name, "stl");
        parseStl(io::readFileLimited(path, kMaxUploadBytes), name, res);
    }));
    svr.Get("/api/examples/nodal", guarded(log, [this, parseNodal](const httplib::Request& req, httplib::Response& res) {
        const auto name = req.get_param_value("name");
        const auto path = resolveExample(options_.dataDir, name, "nodal-csv");
        parseNodal(io::readFileLimited(path, kMaxUploadBytes), name, res);
    }));

    // ---- Thermal FEA --------------------------------------------------------
    svr.Post("/api/fea/solve", guarded(log, [](const httplib::Request& req, httplib::Response& res) {
        const json body = parseBody(req);
        const auto study = fea::runConvergenceStudy(rodProblemFromJson(body), meshListFromJson(body));
        sendJson(res, convergenceStudyToJson(study, 400));
    }));
    svr.Post("/api/fea/export", guarded(log, [](const httplib::Request& req, httplib::Response& res) {
        const json body = parseBody(req);
        const auto study = fea::runConvergenceStudy(rodProblemFromJson(body), meshListFromJson(body));
        const std::string kind = req.has_param("kind") ? req.get_param_value("kind") : "convergence";
        if (kind == "nodal") {
            sendCsv(res, feaNodalCsv(study), "fea_nodal_temperatures.csv");
        } else if (kind == "midpoint") {
            sendCsv(res, feaMidpointCsv(study), "fea_midpoint_errors.csv");
        } else if (kind == "convergence") {
            sendCsv(res, feaConvergenceCsv(study), "fea_convergence.csv");
        } else {
            throw ApiError(400, "Unknown export kind '" + kind + "'.");
        }
    }));

    // ---- Parallel benchmark -------------------------------------------------
    svr.Post("/api/jobs/benchmark", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const auto config = benchmarkConfigFromJson(parseBody(req));
        if (jobs_.busy()) throw ApiError(409, "A benchmark is already running. Wait for it or cancel it first.");
        const std::string id = jobs_.startBenchmark(config);
        logger_.info("Benchmark " + id + " started: " + std::to_string(config.batch.caseCount) + " cases x " +
                     std::to_string(config.batch.elements) + " elements, seed " + std::to_string(config.batch.seed) +
                     ".");
        sendJson(res, {{"id", id}}, 202);
    }));
    svr.Get("/api/jobs/:id", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const auto snap = jobs_.snapshot(req.path_params.at("id"));
        if (!snap) throw ApiError(404, "Job not found. Only the most recent benchmark is kept.");
        sendJson(res, jobToJson(*snap));
    }));
    svr.Post("/api/jobs/:id/cancel", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const bool ok = jobs_.cancel(req.path_params.at("id"));
        if (ok) logger_.warn("Benchmark " + req.path_params.at("id") + " cancel requested.");
        sendJson(res, {{"cancelRequested", ok}});
    }));
    svr.Get("/api/jobs/:id/export", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const auto snap = jobs_.snapshot(req.path_params.at("id"));
        if (!snap || !snap->report) throw ApiError(404, "No completed benchmark to export.");
        sendCsv(res, benchmarkCsv(*snap->report), "benchmark_timings.csv");
    }));

    // ---- Hardware (simulated) ----------------------------------------------
    svr.Get("/api/hardware/devices", guarded(log, [this](const httplib::Request&, httplib::Response& res) {
        json list = json::array();
        for (const auto& d : hardware_.discover()) list.push_back(deviceStatusToJson(d));
        sendJson(res, list);
    }));
    svr.Post("/api/hardware/:id/connect", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const auto status = hardware_.connect(req.path_params.at("id"));
        if (status.state == hardware::ConnectionState::Faulted) logger_.warn(status.lastError);
        else logger_.info(status.descriptor.id + " connected (simulated).");
        sendJson(res, deviceStatusToJson(status));
    }));
    svr.Post("/api/hardware/:id/disconnect", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        sendJson(res, deviceStatusToJson(hardware_.disconnect(req.path_params.at("id"))));
    }));
    svr.Get("/api/hardware/:id/telemetry", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const auto result = hardware_.readTelemetry(req.path_params.at("id"));
        if (!result.ok && !result.status.lastError.empty()) logger_.warn(result.status.lastError);
        json body = {{"ok", result.ok}, {"status", deviceStatusToJson(result.status)}};
        if (result.ok) body["message"] = telemetryToJson(result.message);
        sendJson(res, body);
    }));
    svr.Post("/api/hardware/:id/fault", guarded(log, [this](const httplib::Request& req, httplib::Response& res) {
        const json body = parseBody(req);
        const std::string kind = body.value("kind", std::string("connect-timeout"));
        hardware_.injectFault(req.path_params.at("id"), faultFromString(kind));
        sendJson(res, deviceStatusToJson(hardware_.status(req.path_params.at("id"))));
    }));
    svr.Get("/api/hardware/events", guarded(log, [this](const httplib::Request&, httplib::Response& res) {
        json list = json::array();
        for (const auto& e : hardware_.events(100)) list.push_back(hardwareEventToJson(e));
        sendJson(res, list);
    }));

    // ---- Backpropagation ----------------------------------------------------
    svr.Post("/api/backprop", guarded(log, [](const httplib::Request& req, httplib::Response& res) {
        sendJson(res, backpropToJson(backpropRequestFromJson(parseBody(req))));
    }));
    svr.Post("/api/backprop/export", guarded(log, [](const httplib::Request& req, httplib::Response& res) {
        const auto r = backpropRequestFromJson(parseBody(req));
        const std::string kind = req.has_param("kind") ? req.get_param_value("kind") : "history";
        if (kind == "history") {
            sendCsv(res, backpropHistoryCsv(ml::train(r.start, r.sample, r.learningRate, r.steps + 1)),
                    "backprop_loss_history.csv");
        } else if (kind == "gradients") {
            sendCsv(res, backpropGradientCsv(r.start, r.sample, r.epsilon), "backprop_gradient_check.csv");
        } else {
            throw ApiError(400, "Unknown export kind '" + kind + "'.");
        }
    }));
}

}  // namespace wb::server
