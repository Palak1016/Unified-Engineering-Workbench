#pragma once

#include "core/parallel/batch_runner.hpp"
#include "core/parallel/cancellation.hpp"

#include <chrono>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>

namespace wb::server {

enum class JobState { Running, Completed, Cancelled, Failed };
const char* toString(JobState state);

struct JobSnapshot {
    std::string id;
    JobState state = JobState::Running;
    double progress = 0.0;
    std::string stage;
    std::string error;
    double elapsedS = 0.0;
    // Present only when state == Completed. A cancelled or failed job never
    // exposes partial results.
    std::optional<parallel::BenchmarkReport> report;
};

// Runs one benchmark at a time on a background thread so HTTP handlers (and
// therefore the UI) stay responsive. The most recent finished job is kept so
// its results can be exported.
class JobManager {
public:
    // Called on the worker thread once a job has finished, been cancelled or failed.
    using FinishedCallback = std::function<void(const JobSnapshot&)>;

    explicit JobManager(FinishedCallback onFinished = {}) : onFinished_(std::move(onFinished)) {}
    ~JobManager();

    JobManager(const JobManager&) = delete;
    JobManager& operator=(const JobManager&) = delete;

    // Throws std::runtime_error if a job is already running.
    std::string startBenchmark(const parallel::BenchmarkConfig& config);
    std::optional<JobSnapshot> snapshot(const std::string& id) const;
    bool cancel(const std::string& id);
    bool busy() const;

private:
    struct Job {
        std::string id;
        JobState state = JobState::Running;
        double progress = 0.0;
        std::string stage = "Starting";
        std::string error;
        std::chrono::steady_clock::time_point started;
        std::chrono::steady_clock::time_point finished;
        parallel::CancelToken cancel;
        std::optional<parallel::BenchmarkReport> report;
    };

    mutable std::mutex mutex_;
    std::shared_ptr<Job> current_;
    std::thread worker_;
    unsigned counter_ = 0;
    FinishedCallback onFinished_;
};

}  // namespace wb::server
