#pragma once

#include <chrono>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>

namespace wb::server {

// Minimal thread-safe logger writing to the console window and a log file.
class Logger {
public:
    void openFile(const std::filesystem::path& path) {
        std::lock_guard<std::mutex> lock(mutex_);
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
        file_.open(path, std::ios::app);
        filePath_ = file_ ? path : std::filesystem::path{};
    }

    const std::filesystem::path& filePath() const { return filePath_; }

    void info(const std::string& message) { write("INFO ", message); }
    void warn(const std::string& message) { write("WARN ", message); }
    void error(const std::string& message) { write("ERROR", message); }

private:
    void write(const char* level, const std::string& message) {
        const auto now = std::chrono::system_clock::now();
        const std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm{};
#ifdef _WIN32
        localtime_s(&tm, &t);
#else
        localtime_r(&t, &tm);
#endif
        char stamp[32];
        std::strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", &tm);
        const std::string line = std::string(stamp) + " [" + level + "] " + message;
        std::lock_guard<std::mutex> lock(mutex_);
        std::cout << line << '\n' << std::flush;
        if (file_) {
            file_ << line << '\n' << std::flush;
        }
    }

    std::mutex mutex_;
    std::ofstream file_;
    std::filesystem::path filePath_;
};

}  // namespace wb::server
