#include "server/json_mapping.hpp"

#include <charconv>
#include <cmath>

namespace wb::server {

namespace {

template <typename T>
void appendNumber(std::string& out, T value) {
    char buffer[32];
    const auto result = std::to_chars(buffer, buffer + sizeof(buffer), value);
    out.append(buffer, result.ptr);
}

template <typename T>
void appendArray(std::string& out, const char* key, const std::vector<T>& values) {
    out += ",\"";
    out += key;
    out += "\":[";
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (i) out += ',';
        appendNumber(out, values[i]);
    }
    out += ']';
}

json boundsToJson(const io::Bounds3& b) {
    return {{"min", b.min}, {"max", b.max}, {"size", b.size()}};
}

// Reads an optional number from a request body, rejecting wrong types and
// non-finite values with a message naming the field.
double numberField(const json& body, const char* key, double fallback) {
    if (!body.is_object() || !body.contains(key) || body.at(key).is_null()) return fallback;
    const auto& v = body.at(key);
    if (!v.is_number()) {
        throw ApiError(400, std::string("Field '") + key + "' must be a number.");
    }
    const double d = v.get<double>();
    if (!std::isfinite(d)) {
        throw ApiError(400, std::string("Field '") + key + "' must be finite.");
    }
    return d;
}

int intField(const json& body, const char* key, int fallback) {
    const double d = numberField(body, key, fallback);
    if (std::floor(d) != d || d < -2147483648.0 || d > 2147483647.0) {
        throw ApiError(400, std::string("Field '") + key + "' must be a whole number.");
    }
    return static_cast<int>(d);
}

}  // namespace

std::string stlMeshToJsonText(const io::StlMesh& mesh, const std::string& fileName, std::size_t fileBytes,
                              double parseMs) {
    json meta = {{"fileName", fileName},
                 {"fileBytes", fileBytes},
                 {"solidName", mesh.solidName},
                 {"solidCount", mesh.solidCount},
                 {"triangleCount", mesh.triangleCount()},
                 {"degenerateTriangles", mesh.degenerateTriangles},
                 {"normalMismatches", mesh.normalMismatches},
                 {"bounds", boundsToJson(mesh.bounds)},
                 {"warnings", mesh.warnings},
                 {"parseMs", parseMs},
                 {"unitNote", "STL files carry no unit. Coordinates are shown as stored; select the unit in the view."}};
    std::string out = meta.dump();
    out.pop_back();  // reopen the object to append the large array
    appendArray(out, "vertices", mesh.vertices);
    out += '}';
    return out;
}

std::string nodalFieldToJsonText(const io::NodalTemperatureField& field, const std::string& fileName,
                                 std::size_t fileBytes, double parseMs) {
    json meta = {{"fileName", fileName},
                 {"fileBytes", fileBytes},
                 {"nodeCount", field.size()},
                 {"bounds", boundsToJson(field.bounds)},
                 {"temperatureMinC", field.minTemperature},
                 {"temperatureMaxC", field.maxTemperature},
                 {"comments", field.comments},
                 {"declaredSynthetic", field.declaredSynthetic},
                 {"warnings", field.warnings},
                 {"parseMs", parseMs},
                 {"units", {{"coordinates", "m"}, {"temperature", "C"}}}};
    std::string out = meta.dump();
    out.pop_back();
    appendArray(out, "nodeIds", field.nodeIds);
    appendArray(out, "xyz", field.xyz);
    appendArray(out, "temperature", field.temperature);
    out += '}';
    return out;
}

fea::RodProblem rodProblemFromJson(const json& body) {
    fea::RodProblem p;
    p.length = numberField(body, "length", p.length);
    p.area = numberField(body, "area", p.area);
    p.conductivity = numberField(body, "conductivity", p.conductivity);
    p.heatGeneration = numberField(body, "heatGeneration", p.heatGeneration);
    p.tLeft = numberField(body, "tLeft", p.tLeft);
    p.tRight = numberField(body, "tRight", p.tRight);
    try {
        fea::validate(p);
    } catch (const std::invalid_argument& e) {
        throw ApiError(400, e.what());
    }
    return p;
}

std::vector<int> meshListFromJson(const json& body) {
    std::vector<int> meshes{10, 20, 40, 80};
    if (body.is_object() && body.contains("meshes")) {
        const auto& m = body.at("meshes");
        if (!m.is_array() || m.empty() || m.size() > 12) {
            throw ApiError(400, "'meshes' must be a list of 1 to 12 element counts.");
        }
        meshes.clear();
        for (const auto& v : m) {
            if (!v.is_number_integer()) throw ApiError(400, "Each mesh size must be a whole number.");
            const int n = v.get<int>();
            if (n < 1 || n > 20000) {
                throw ApiError(400, "Mesh sizes in the interactive view must be between 1 and 20000 elements.");
            }
            meshes.push_back(n);
        }
    }
    return meshes;
}

json convergenceStudyToJson(const fea::ConvergenceStudy& study, int exactSamples) {
    const auto& p = study.problem;
    json exact = json::object();
    std::vector<double> ex, et;
    for (int i = 0; i <= exactSamples; ++i) {
        const double x = p.length * i / exactSamples;
        ex.push_back(x);
        et.push_back(fea::exactTemperature(p, x));
    }
    exact["x"] = ex;
    exact["T"] = et;

    json meshes = json::array();
    for (std::size_t m = 0; m < study.solutions.size(); ++m) {
        const auto& s = study.solutions[m];
        std::vector<double> xm, em;
        for (int e = 0; e < s.elements; ++e) {
            const double x = (e + 0.5) * s.elementLength;
            xm.push_back(x);
            em.push_back(std::fabs(fea::interpolate(s, x) - fea::exactTemperature(p, x)));
        }
        meshes.push_back({{"elements", s.elements}, {"x", s.x}, {"T", s.T}, {"midX", xm}, {"midError", em}});
    }

    json rows = json::array();
    for (const auto& r : study.rows) {
        rows.push_back({{"elements", r.elements},
                        {"h", r.h},
                        {"maxNodalError", r.maxNodalError},
                        {"maxMidpointError", r.maxMidpointError},
                        {"xAtMaxMidpointError", r.xAtMaxMidpointError},
                        {"predictedMidpointError", r.predictedMidpointError},
                        {"observedOrder", r.observedOrder}});
    }
    return {{"problem",
             {{"length", p.length},
              {"area", p.area},
              {"conductivity", p.conductivity},
              {"heatGeneration", p.heatGeneration},
              {"tLeft", p.tLeft},
              {"tRight", p.tRight}}},
            {"exact", exact},
            {"meshes", meshes},
            {"convergence", rows},
            {"units", {{"x", "m"}, {"T", "C"}, {"error", "C"}}}};
}

parallel::BenchmarkConfig benchmarkConfigFromJson(const json& body) {
    parallel::BenchmarkConfig c;
    const double seed = numberField(body, "seed", static_cast<double>(c.batch.seed));
    if (seed < 0 || std::floor(seed) != seed || seed > 9007199254740991.0) {
        throw ApiError(400, "Seed must be a non-negative whole number.");
    }
    c.batch.seed = static_cast<std::uint64_t>(seed);
    c.batch.caseCount = intField(body, "cases", c.batch.caseCount);
    c.batch.elements = intField(body, "elements", c.batch.elements);
    c.batch.kMin = numberField(body, "kMin", c.batch.kMin);
    c.batch.kMax = numberField(body, "kMax", c.batch.kMax);
    c.batch.qMin = numberField(body, "qMin", c.batch.qMin);
    c.batch.qMax = numberField(body, "qMax", c.batch.qMax);
    c.maxWorkers = intField(body, "maxWorkers", c.maxWorkers);
    c.warmupRuns = intField(body, "warmupRuns", c.warmupRuns);
    c.measuredRuns = intField(body, "measuredRuns", c.measuredRuns);
    try {
        parallel::validate(c);
    } catch (const std::invalid_argument& e) {
        throw ApiError(400, e.what());
    }
    return c;
}

json systemInfoToJson(const platform::SystemInfo& s) {
    return {{"cpuModel", s.cpuModel},
            {"logicalCores", s.logicalCores},
            {"physicalCores", s.physicalCores},
            {"totalRamBytes", s.totalRamBytes},
            {"totalRamGiB", static_cast<double>(s.totalRamBytes) / (1024.0 * 1024.0 * 1024.0)},
            {"operatingSystem", s.operatingSystem},
            {"compiler", s.compiler},
            {"compilerFlags", s.compilerFlags},
            {"buildType", s.buildType},
            {"appVersion", s.appVersion}};
}

json benchmarkReportToJson(const parallel::BenchmarkReport& r) {
    json rows = json::array();
    for (const auto& row : r.rows) {
        rows.push_back({{"label", row.label},
                        {"workers", row.workers},
                        {"runMs", row.runMs},
                        {"medianMs", row.medianMs},
                        {"minMs", row.minMs},
                        {"maxMs", row.maxMs},
                        {"speedup", row.speedup},
                        {"efficiency", row.efficiency},
                        {"maxAbsDiffC", row.maxAbsDiffC}});
    }
    const auto& b = r.config.batch;
    return {{"config",
             {{"seed", b.seed},
              {"cases", b.caseCount},
              {"elements", b.elements},
              {"kRange", {b.kMin, b.kMax}},
              {"qRange", {b.qMin, b.qMax}},
              {"maxWorkers", r.config.maxWorkers},
              {"warmupRuns", r.config.warmupRuns},
              {"measuredRuns", r.config.measuredRuns}}},
            {"system", systemInfoToJson(r.system)},
            {"generationMs", r.generationMs},
            {"rows", rows},
            {"agreementToleranceC", r.agreementToleranceC},
            {"agreementPassed", r.agreementPassed},
            {"speedupAssessable", r.speedupAssessable},
            {"checksum", r.checksum},
            {"notes", r.notes}};
}

json deviceStatusToJson(const hardware::DeviceStatus& s) {
    json caps = json::array();
    for (const auto& c : s.capabilities) caps.push_back({{"name", c.name}, {"value", c.value}});
    return {{"id", s.descriptor.id},
            {"kind", hardware::toString(s.descriptor.kind)},
            {"model", s.descriptor.model},
            {"hostLink", s.descriptor.hostLink},
            {"port", s.descriptor.port},
            {"simulated", s.descriptor.simulated},
            {"state", hardware::toString(s.state)},
            {"lastError", s.lastError},
            {"capabilities", caps}};
}

json telemetryToJson(const hardware::TelemetryMessage& m) {
    json fields = json::array();
    for (const auto& f : m.fields) fields.push_back({{"name", f.name}, {"value", f.value}, {"unit", f.unit}});
    return {{"deviceId", m.deviceId},
            {"sequence", m.sequence},
            {"hostTimeS", m.hostTimeS},
            {"fields", fields},
            {"note", m.note},
            {"simulated", m.simulated}};
}

json hardwareEventToJson(const hardware::HardwareEvent& e) {
    return {{"timeS", e.timeS}, {"deviceId", e.deviceId}, {"level", e.level}, {"message", e.message}};
}

BackpropRequest backpropRequestFromJson(const json& body) {
    BackpropRequest r;
    r.start.w = numberField(body, "w", r.start.w);
    r.start.b = numberField(body, "b", r.start.b);
    r.start.v = numberField(body, "v", r.start.v);
    r.start.c = numberField(body, "c", r.start.c);
    r.sample.x = numberField(body, "x", r.sample.x);
    r.sample.y = numberField(body, "y", r.sample.y);
    r.learningRate = numberField(body, "learningRate", r.learningRate);
    r.steps = intField(body, "steps", r.steps);
    r.epsilon = numberField(body, "epsilon", r.epsilon);
    if (!(r.learningRate > 0.0) || r.learningRate > 10.0) throw ApiError(400, "Learning rate must be in (0, 10].");
    if (r.steps < 1 || r.steps > 10000) throw ApiError(400, "Subsequent steps must be between 1 and 10000.");
    if (!(r.epsilon > 0.0) || r.epsilon > 1e-2) throw ApiError(400, "Finite-difference epsilon must be in (0, 0.01].");
    return r;
}

json backpropToJson(const BackpropRequest& r) {
    const auto f0 = ml::forward(r.start, r.sample);
    const auto g = ml::analyticGradients(r.start, r.sample);
    const auto fd = ml::finiteDifferenceGradients(r.start, r.sample, r.epsilon);
    const auto p1 = ml::gradientStep(r.start, g, r.learningRate);
    const auto f1 = ml::forward(p1, r.sample);

    auto paramsJson = [](const ml::Parameters& p) { return json{{"w", p.w}, {"b", p.b}, {"v", p.v}, {"c", p.c}}; };
    auto forwardJson = [](const ml::ForwardPass& f) {
        return json{{"z", f.z}, {"h", f.h}, {"yHat", f.yHat}, {"error", f.error}, {"loss", f.loss}};
    };

    json check = json::array();
    const std::pair<const char*, std::pair<double, double>> items[] = {
        {"w", {g.dw, fd.dw}}, {"b", {g.db, fd.db}}, {"v", {g.dv, fd.dv}}, {"c", {g.dc, fd.dc}}};
    bool allPass = true;
    for (const auto& [name, values] : items) {
        const double err = std::fabs(values.first - values.second);
        const bool pass = err <= r.tolerance;
        allPass = allPass && pass;
        check.push_back({{"parameter", name},
                         {"analytic", values.first},
                         {"finiteDifference", values.second},
                         {"absError", err},
                         {"pass", pass}});
    }

    // Step 0 is the starting point, step 1 is the hand-checked update, and the
    // following `steps` updates are the "subsequent" training run.
    const auto history = ml::train(r.start, r.sample, r.learningRate, r.steps + 1);
    std::vector<int> stepIndex;
    std::vector<double> loss;
    for (const auto& rec : history) {
        stepIndex.push_back(rec.step);
        loss.push_back(rec.loss);
    }
    return {{"inputs",
             {{"x", r.sample.x},
              {"y", r.sample.y},
              {"learningRate", r.learningRate},
              {"epsilon", r.epsilon},
              {"tolerance", r.tolerance},
              {"subsequentSteps", r.steps}}},
            {"initial", paramsJson(r.start)},
            {"forward", forwardJson(f0)},
            {"gradientCheck", check},
            {"gradientCheckPassed", allPass},
            {"afterFirstUpdate", paramsJson(p1)},
            {"forwardAfterFirstUpdate", forwardJson(f1)},
            {"history", {{"step", stepIndex}, {"loss", loss}}},
            {"final", paramsJson(history.back().params)},
            {"finalLoss", history.back().loss}};
}

}  // namespace wb::server
