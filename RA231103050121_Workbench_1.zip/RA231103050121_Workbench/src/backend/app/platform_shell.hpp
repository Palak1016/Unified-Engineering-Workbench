#pragma once

#include <filesystem>
#include <functional>
#include <string>

namespace wb::app {

// Folder containing the running executable (not the current directory, which
// differs when launched from Explorer, VS Code or a shortcut).
std::filesystem::path executableDirectory();

// Opens the URL in the user's default browser. Returns false on failure.
bool openInBrowser(const std::string& url);

// Milliseconds since the operating system created this process. Used for the
// launch-to-ready figure, so it includes loader and static-init time.
double millisecondsSinceProcessStart();

void setConsoleTitle(const std::string& title);

// Calls `handler` once on Ctrl+C or when the console window is closed.
void onInterrupt(std::function<void()> handler);

// Shows a blocking error dialog on Windows; prints to stderr elsewhere.
void showFatalError(const std::string& title, const std::string& message);

}  // namespace wb::app
