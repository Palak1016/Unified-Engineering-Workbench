#include "app/platform_shell.hpp"

#include <algorithm>
#include <chrono>
#include <iostream>
#include <utility>

#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#else
#include <csignal>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#endif

namespace wb::app {

namespace {
std::function<void()>& interruptHandler() {
    static std::function<void()> handler;
    return handler;
}

#ifndef _WIN32
// Fallback for platforms without a process creation timestamp we trust.
const auto kStaticInitTime = std::chrono::steady_clock::now();
#endif
}  // namespace

#ifdef _WIN32

std::filesystem::path executableDirectory() {
    std::wstring buffer(MAX_PATH, L'\0');
    while (true) {
        const DWORD len = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (len == 0) return std::filesystem::current_path();
        if (len < buffer.size()) {
            buffer.resize(len);
            break;
        }
        buffer.resize(buffer.size() * 2);
    }
    return std::filesystem::path(buffer).parent_path();
}

bool openInBrowser(const std::string& url) {
    const std::wstring wide(url.begin(), url.end());  // URL is ASCII
    const auto result = reinterpret_cast<INT_PTR>(ShellExecuteW(nullptr, L"open", wide.c_str(), nullptr, nullptr, SW_SHOWNORMAL));
    return result > 32;
}

double millisecondsSinceProcessStart() {
    FILETIME creation{}, exitTime{}, kernel{}, user{};
    if (!GetProcessTimes(GetCurrentProcess(), &creation, &exitTime, &kernel, &user)) return 0.0;
    FILETIME now{};
    GetSystemTimeAsFileTime(&now);
    auto toInt = [](const FILETIME& ft) {
        return (static_cast<unsigned long long>(ft.dwHighDateTime) << 32) | ft.dwLowDateTime;
    };
    return static_cast<double>(toInt(now) - toInt(creation)) / 10000.0;  // 100 ns ticks -> ms
}

void setConsoleTitle(const std::string& title) { SetConsoleTitleA(title.c_str()); }

namespace {
BOOL WINAPI consoleHandler(DWORD) {
    if (interruptHandler()) interruptHandler()();
    return TRUE;
}
}  // namespace

void onInterrupt(std::function<void()> handler) {
    interruptHandler() = std::move(handler);
    SetConsoleCtrlHandler(consoleHandler, TRUE);
}

void showFatalError(const std::string& title, const std::string& message) {
    std::cerr << title << ": " << message << std::endl;
    MessageBoxA(nullptr, message.c_str(), title.c_str(), MB_OK | MB_ICONERROR);
}

#else

std::filesystem::path executableDirectory() {
    std::error_code ec;
    const auto exe = std::filesystem::read_symlink("/proc/self/exe", ec);
    return ec ? std::filesystem::current_path() : exe.parent_path();
}

bool openInBrowser(const std::string& url) {
    const pid_t pid = fork();
    if (pid == 0) {
#ifdef __APPLE__
        execlp("open", "open", url.c_str(), static_cast<char*>(nullptr));
#else
        execlp("xdg-open", "xdg-open", url.c_str(), static_cast<char*>(nullptr));
#endif
        _exit(127);
    }
    return pid > 0;
}

double millisecondsSinceProcessStart() {
    // /proc/self/stat field 22 is the start time in clock ticks after boot;
    // /proc/uptime gives seconds since boot. Both have 10 ms resolution, so
    // the larger of that and the time since static initialisation is used.
    const double sinceInit =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - kStaticInitTime).count();
    std::ifstream statFile("/proc/self/stat");
    std::ifstream uptimeFile("/proc/uptime");
    std::string stat;
    double uptime = 0.0;
    if (std::getline(statFile, stat) && (uptimeFile >> uptime)) {
        const auto close = stat.rfind(')');
        std::istringstream fields(stat.substr(close + 2));
        std::string field;
        for (int i = 3; i <= 22 && (fields >> field); ++i) {
        }
        const double ticks = std::stod(field);
        const double startS = ticks / static_cast<double>(sysconf(_SC_CLK_TCK));
        if (uptime >= startS) return std::max(sinceInit, (uptime - startS) * 1000.0);
    }
    return sinceInit;
}

void setConsoleTitle(const std::string& title) { std::cout << "\033]0;" << title << "\007" << std::flush; }

void onInterrupt(std::function<void()> handler) {
    interruptHandler() = std::move(handler);
    std::signal(SIGINT, [](int) {
        if (interruptHandler()) interruptHandler()();
    });
    std::signal(SIGTERM, [](int) {
        if (interruptHandler()) interruptHandler()();
    });
}

void showFatalError(const std::string& title, const std::string& message) {
    std::cerr << title << ": " << message << std::endl;
}

#endif

}  // namespace wb::app
