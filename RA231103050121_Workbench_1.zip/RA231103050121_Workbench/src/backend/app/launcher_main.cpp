// Launch.exe: starts the local workbench server and opens the interface in
// the default browser. Everything is served from 127.0.0.1; no internet,
// installation or administrator rights are needed.

#include "app/platform_shell.hpp"
#include "core/platform/system_info.hpp"
#include "server/api_server.hpp"
#include "server/logger.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <optional>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

struct Options {
    bool openBrowser = true;
    std::optional<int> port;
    std::optional<fs::path> webRoot;
    std::optional<fs::path> dataDir;
};

Options parseArguments(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto next = [&]() -> std::string {
            if (i + 1 >= argc) throw std::invalid_argument("Missing value after " + arg);
            return argv[++i];
        };
        if (arg == "--no-browser") {
            o.openBrowser = false;
        } else if (arg == "--port") {
            o.port = std::stoi(next());
        } else if (arg == "--web-root") {
            o.webRoot = fs::path(next());
        } else if (arg == "--data-dir") {
            o.dataDir = fs::path(next());
        } else if (arg == "--help" || arg == "-h") {
            std::cout << "Usage: Launch [--no-browser] [--port N] [--web-root DIR] [--data-dir DIR]\n";
            std::exit(0);
        } else {
            throw std::invalid_argument("Unknown option " + arg + " (try --help)");
        }
    }
    return o;
}

// The packaged ZIP keeps the frontend in app/web next to Launch.exe. When the
// launcher is run from a CMake build folder, fall back to the source tree.
std::optional<fs::path> firstExisting(const fs::path& base, const std::vector<fs::path>& candidates,
                                      const char* marker) {
    std::error_code ec;
    for (const auto& c : candidates) {
        const fs::path p = (base / c).lexically_normal();
        if (fs::exists(marker ? p / marker : p, ec)) return p;
    }
    return std::nullopt;
}

fs::path chooseLogFile(const fs::path& base) {
    const fs::path preferred = base / "logs" / "workbench.log";
    std::error_code ec;
    fs::create_directories(preferred.parent_path(), ec);
    if (!ec) {
        std::ofstream probe(preferred, std::ios::app);
        if (probe) return preferred;
    }
    // Read-only location (e.g. extracted under Program Files): use the temp folder.
    return fs::temp_directory_path(ec) / "UnifiedEngineeringWorkbench" / "workbench.log";
}

}  // namespace

int main(int argc, char** argv) {
    wb::app::setConsoleTitle("Unified Engineering Workbench - server log");
    Options options;
    try {
        options = parseArguments(argc, argv);
    } catch (const std::exception& e) {
        wb::app::showFatalError("Unified Engineering Workbench", e.what());
        return 2;
    }

    const fs::path base = wb::app::executableDirectory();
    wb::server::Logger logger;
    logger.openFile(chooseLogFile(base));

    const auto webRoot = options.webRoot
                             ? std::optional<fs::path>(options.webRoot)
                             : firstExisting(base, {"app/web", "../src/frontend", "../../src/frontend", "src/frontend"},
                                             "index.html");
    const auto dataDir = options.dataDir ? std::optional<fs::path>(options.dataDir)
                                         : firstExisting(base, {"data", "../data", "../../data"}, nullptr);
    if (!webRoot) {
        const std::string msg = "The interface files were not found next to Launch.exe (expected app\\web\\index.html). "
                                "Extract the whole ZIP, not just Launch.exe, and try again.";
        logger.error(msg);
        wb::app::showFatalError("Unified Engineering Workbench", msg);
        return 1;
    }
    if (!dataDir) {
        logger.warn("Example data folder not found; the example buttons will be empty.");
    }

    wb::server::ServerOptions serverOptions;
    serverOptions.webRoot = *webRoot;
    serverOptions.dataDir = dataDir.value_or(base / "data");
    if (options.port) {
        serverOptions.firstPort = serverOptions.lastPort = *options.port;
    }

    wb::server::ApiServer server(serverOptions, logger);
    if (!server.bind()) {
        const std::string msg = "Could not open a local port between " + std::to_string(serverOptions.firstPort) +
                                " and " + std::to_string(serverOptions.lastPort) +
                                ". Another program may be using them; close it or pass --port.";
        logger.error(msg);
        wb::app::showFatalError("Unified Engineering Workbench", msg);
        return 1;
    }

    const double readyMs = wb::app::millisecondsSinceProcessStart();
    server.setLaunchToReadyMs(readyMs);
    wb::app::onInterrupt([&server] { server.stop(); });

    logger.info("Unified Engineering Workbench v" + wb::platform::querySystemInfo().appVersion);
    logger.info("Frontend: " + fs::relative(*webRoot, base).generic_string() +
                "   Data: " + fs::relative(serverOptions.dataDir, base).generic_string());
    std::error_code ec;
    const auto relLog = fs::relative(logger.filePath(), base, ec);
    logger.info("Log file: " + (ec || relLog.empty() ? logger.filePath().filename().string() : relLog.generic_string()));
    char readyText[64];
    std::snprintf(readyText, sizeof(readyText), "%.1f ms", readyMs);
    logger.info("Server ready at " + server.url() + " (launch-to-ready " + readyText + ")");
    std::cout << "\nThe workbench is running in your browser. Keep this window open while you use it.\n"
                 "To stop: click 'Exit' in the interface, or close this window.\n\n";

    if (options.openBrowser && !wb::app::openInBrowser(server.url())) {
        logger.warn("Could not open the default browser. Open " + server.url() + " manually.");
    }
    server.run();
    logger.info("Server stopped.");
    return 0;
}
