// workbench_cli: command-line access to the same C++ core used by the
// interface. Used to regenerate everything in results/ and data/ so the
// numbers in the report can be reproduced without the GUI.

#include "core/fea/rod_fea.hpp"
#include "core/io/text_utils.hpp"
#include "core/io/nodal_csv_reader.hpp"
#include "core/io/stl_reader.hpp"
#include "core/ml/backprop.hpp"
#include "core/parallel/batch_runner.hpp"
#include "core/platform/system_info.hpp"
#include "server/csv_export.hpp"
#include "server/json_mapping.hpp"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <string>

namespace fs = std::filesystem;
using Clock = std::chrono::steady_clock;

namespace {

using Args = std::map<std::string, std::string>;

Args parseFlags(int argc, char** argv, int first) {
    Args args;
    for (int i = first; i < argc; ++i) {
        std::string key = argv[i];
        if (key.rfind("--", 0) != 0) {
            args["_positional"] = key;
            continue;
        }
        key = key.substr(2);
        if (i + 1 < argc && std::string(argv[i + 1]).rfind("--", 0) != 0) {
            args[key] = argv[++i];
        } else {
            args[key] = "1";
        }
    }
    return args;
}

std::string get(const Args& a, const std::string& key, const std::string& fallback) {
    const auto it = a.find(key);
    return it == a.end() ? fallback : it->second;
}

void writeText(const fs::path& path, const std::string& text) {
    fs::create_directories(path.parent_path());
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("Cannot write " + path.string());
    out << text;
    std::cout << "  wrote " << path.generic_string() << " (" << text.size() << " bytes)\n";
}

double msSince(Clock::time_point t) { return std::chrono::duration<double, std::milli>(Clock::now() - t).count(); }

// ---------------------------------------------------------------------------

int runFea(const Args& a) {
    const fs::path out = get(a, "out", "results/fea");
    const auto study = wb::fea::runConvergenceStudy(wb::fea::RodProblem{}, {10, 20, 40, 80});
    std::printf("%8s %10s %16s %18s %16s %8s\n", "N", "h [m]", "max nodal [C]", "max midpoint [C]", "q h^2/8k [C]",
                "order");
    for (const auto& r : study.rows) {
        std::printf("%8d %10.5f %16.3e %18.6e %16.6e %8.4f\n", r.elements, r.h, r.maxNodalError, r.maxMidpointError,
                    r.predictedMidpointError, r.observedOrder);
    }
    writeText(out / "fea_nodal_temperatures.csv", wb::server::feaNodalCsv(study));
    writeText(out / "fea_midpoint_errors.csv", wb::server::feaMidpointCsv(study));
    writeText(out / "fea_convergence.csv", wb::server::feaConvergenceCsv(study));

    // Dense samples of the exact solution, for plotting.
    std::string exact = "x_m,T_exact_C\n";
    for (int i = 0; i <= 400; ++i) {
        const double x = i / 400.0;
        char line[64];
        std::snprintf(line, sizeof(line), "%.6f,%.12f\n", x, wb::fea::exactTemperature(study.problem, x));
        exact += line;
    }
    writeText(out / "fea_exact_curve.csv", exact);
    return 0;
}

int runBenchmark(const Args& a) {
    const fs::path out = get(a, "out", "results/performance");
    wb::parallel::BenchmarkConfig c;
    c.batch.caseCount = std::stoi(get(a, "cases", std::to_string(c.batch.caseCount)));
    c.batch.elements = std::stoi(get(a, "elements", std::to_string(c.batch.elements)));
    c.batch.seed = std::stoull(get(a, "seed", std::to_string(c.batch.seed)));
    c.maxWorkers = std::stoi(get(a, "workers", "4"));
    c.measuredRuns = std::stoi(get(a, "runs", "5"));
    c.warmupRuns = std::stoi(get(a, "warmup", "1"));

    std::cout << "Benchmark: " << c.batch.caseCount << " cases x " << c.batch.elements << " elements, seed "
              << c.batch.seed << "\n";
    const auto report = wb::parallel::runBenchmark(c, [](double f, const std::string& stage) {
        std::printf("\r  [%3.0f%%] %-40s", 100.0 * f, stage.c_str());
        std::fflush(stdout);
    });
    std::cout << "\n";
    std::printf("%-8s %7s %11s %9s %10s %14s\n", "config", "workers", "median ms", "speedup", "efficiency",
                "max |dT| [C]");
    for (const auto& row : report.rows) {
        std::printf("%-8s %7d %11.2f %9.3f %10.3f %14.3e\n", row.label.c_str(), row.workers, row.medianMs, row.speedup,
                    row.efficiency, row.maxAbsDiffC);
    }
    std::cout << "Agreement (<= 1e-8 C): " << (report.agreementPassed ? "PASS" : "FAIL") << "\n";
    for (const auto& n : report.notes) std::cout << "Note: " << n << "\n";

    const std::string tag = get(a, "tag", "");
    const std::string suffix = tag.empty() ? "" : "_" + tag;
    writeText(out / ("benchmark_timings" + suffix + ".csv"), wb::server::benchmarkCsv(report));
    writeText(out / ("benchmark_report" + suffix + ".json"),
              wb::server::benchmarkReportToJson(report).dump(2) + "\n");
    return report.agreementPassed ? 0 : 3;
}

int runBackprop(const Args& a) {
    const fs::path out = get(a, "out", "results/backprop");
    const wb::ml::Parameters p0;
    const wb::ml::Sample s;
    const auto f = wb::ml::forward(p0, s);
    const auto g = wb::ml::analyticGradients(p0, s);
    const auto fd = wb::ml::finiteDifferenceGradients(p0, s, 1e-6);
    const auto p1 = wb::ml::gradientStep(p0, g, 0.1);
    std::printf("forward: z=%.10f h=%.10f y_hat=%.10f e=%.10f J=%.10f\n", f.z, f.h, f.yHat, f.error, f.loss);
    std::printf("dJ/dw=%.10f  fd=%.10f\n", g.dw, fd.dw);
    std::printf("dJ/db=%.10f  fd=%.10f\n", g.db, fd.db);
    std::printf("dJ/dv=%.10f  fd=%.10f\n", g.dv, fd.dv);
    std::printf("dJ/dc=%.10f  fd=%.10f\n", g.dc, fd.dc);
    std::printf("after one step: w=%.10f b=%.10f v=%.10f c=%.10f  J=%.10f\n", p1.w, p1.b, p1.v, p1.c,
                wb::ml::forward(p1, s).loss);
    const auto history = wb::ml::train(p0, s, 0.1, 101);
    std::printf("loss after 100 further steps: %.6e\n", history.back().loss);
    writeText(out / "backprop_gradient_check.csv", wb::server::backpropGradientCsv(p0, s, 1e-6));
    writeText(out / "backprop_loss_history.csv", wb::server::backpropHistoryCsv(history));
    return 0;
}

// ---- Example data -----------------------------------------------------------

struct StlWriter {
    std::string text;
    std::size_t triangles = 0;

    void tri(const double a[3], const double b[3], const double c[3]) {
        const double u[3] = {b[0] - a[0], b[1] - a[1], b[2] - a[2]};
        const double v[3] = {c[0] - a[0], c[1] - a[1], c[2] - a[2]};
        double n[3] = {u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]};
        const double len = std::sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
        for (double& x : n) x = len > 0 ? x / len : 0.0;
        char buf[512];
        std::snprintf(buf, sizeof(buf),
                      "  facet normal %g %g %g\n    outer loop\n      vertex %g %g %g\n      vertex %g %g %g\n"
                      "      vertex %g %g %g\n    endloop\n  endfacet\n",
                      n[0], n[1], n[2], a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
        text += buf;
        ++triangles;
    }

    // Axis-aligned box, outward normals, 12 triangles.
    void box(double x0, double y0, double z0, double x1, double y1, double z1) {
        const double p[8][3] = {{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0},
                                {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}};
        const int f[6][4] = {{0, 3, 2, 1}, {4, 5, 6, 7}, {0, 1, 5, 4}, {2, 3, 7, 6}, {1, 2, 6, 5}, {3, 0, 4, 7}};
        for (const auto& q : f) {
            tri(p[q[0]], p[q[1]], p[q[2]]);
            tri(p[q[0]], p[q[2]], p[q[3]]);
        }
    }
};

std::string heatSinkStl() {
    // Finned heat sink, millimetres: 60 x 40 x 5 base with 7 fins 2 mm thick, 25 mm tall.
    StlWriter w;
    w.text = "solid heat_sink_7fin_mm\n";
    w.box(0, 0, 0, 60, 40, 5);
    for (int i = 0; i < 7; ++i) {
        const double x0 = 2.0 + i * 9.0;
        w.box(x0, 0, 5, x0 + 2.0, 40, 30);
    }
    w.text += "endsolid heat_sink_7fin_mm\n";
    return w.text;
}

std::string syntheticPlateCsv() {
    // Plate 0.10 x 0.05 x 0.01 m, 21 x 11 x 3 nodes. A Gaussian hot spot over a
    // 25 C baseline plus a small through-thickness gradient. Made-up field.
    std::string out =
        "# SYNTHETIC DATA - generated by workbench_cli make-examples; NOT an actual ANSYS export.\n"
        "# Layout follows an ANSYS Mechanical nodal temperature table exported to CSV.\n"
        "# Units: coordinates in metres, temperature in degrees Celsius. Licence: CC0-1.0.\n"
        "node_id,x_m,y_m,z_m,temperature_C\n";
    int id = 1;
    for (int k = 0; k < 3; ++k) {
        for (int j = 0; j < 11; ++j) {
            for (int i = 0; i < 21; ++i) {
                const double x = 0.005 * i, y = 0.005 * j, z = 0.005 * k;
                const double r2 = (x - 0.03) * (x - 0.03) + (y - 0.025) * (y - 0.025);
                const double t = 25.0 + 60.0 * std::exp(-r2 / (2 * 0.015 * 0.015)) + 400.0 * z;
                char line[128];
                std::snprintf(line, sizeof(line), "%d,%.4f,%.4f,%.4f,%.3f\n", id++, x, y, z, t);
                out += line;
            }
        }
    }
    return out;
}

int makeExamples(const Args& a) {
    const fs::path out = get(a, "out", "data");
    writeText(out / "geometry" / "heat_sink_7fin_mm.stl", heatSinkStl());
    writeText(out / "results" / "synthetic_plate_temperatures.csv", syntheticPlateCsv());
    return 0;
}

// Large files for documenting tested size limits (not shipped in data/).
int makeStressFiles(const Args& a) {
    const fs::path out = get(a, "out", "build/stress");
    const int triangles = std::stoi(get(a, "triangles", "500000"));
    const int nodes = std::stoi(get(a, "nodes", "1000000"));
    StlWriter w;
    w.text.reserve(static_cast<std::size_t>(triangles) * 260);
    w.text = "solid stress\n";
    const int boxes = triangles / 12;
    const int side = static_cast<int>(std::ceil(std::cbrt(boxes)));
    for (int b = 0; b < boxes; ++b) {
        const double x = b % side, y = (b / side) % side, z = b / (side * side);
        w.box(x, y, z, x + 0.8, y + 0.8, z + 0.8);
    }
    w.text += "endsolid stress\n";
    writeText(out / "stress.stl", w.text);

    std::string csv = "node_id,x_m,y_m,z_m,temperature_C\n";
    csv.reserve(static_cast<std::size_t>(nodes) * 48);
    for (int i = 0; i < nodes; ++i) {
        char line[96];
        std::snprintf(line, sizeof(line), "%d,%.5f,%.5f,%.5f,%.3f\n", i + 1, (i % 100) * 0.001,
                      ((i / 100) % 100) * 0.001, (i / 10000) * 0.001, 20.0 + (i % 997) * 0.1);
        csv += line;
    }
    writeText(out / "stress.csv", csv);
    return 0;
}

int validateFile(const std::string& kind, const Args& a) {
    const fs::path path = get(a, "_positional", "");
    if (path.empty()) throw std::invalid_argument("Give a file path.");
    const auto start = Clock::now();
    if (kind == "stl") {
        const auto mesh = wb::io::readAsciiStlFile(path);
        std::cout << path.generic_string() << ": OK, " << mesh.triangleCount() << " triangles, " << msSince(start)
                  << " ms\n";
        for (const auto& w : mesh.warnings) std::cout << "  warning: " << w << "\n";
    } else {
        const auto field = wb::io::readNodalTemperatureCsv(path);
        std::cout << path.generic_string() << ": OK, " << field.size() << " nodes, T " << field.minTemperature
                  << " to " << field.maxTemperature << " C, " << msSince(start) << " ms\n";
        for (const auto& w : field.warnings) std::cout << "  warning: " << w << "\n";
    }
    return 0;
}

int printSystemInfo() {
    std::cout << wb::server::systemInfoToJson(wb::platform::querySystemInfo()).dump(2) << "\n";
    return 0;
}

void usage() {
    std::cout << "workbench_cli <command> [options]\n\n"
                 "  fea            [--out DIR]           convergence study for N = 10, 20, 40, 80\n"
                 "  benchmark      [--cases N] [--elements N] [--seed S] [--workers P] [--runs R]\n"
                 "                 [--warmup W] [--out DIR] [--tag NAME]\n"
                 "  backprop       [--out DIR]           gradient check and 100-step loss history\n"
                 "  make-examples  [--out DIR]           regenerate the example STL and synthetic CSV\n"
                 "  make-stress    [--triangles N] [--nodes N] [--out DIR]\n"
                 "  check-stl FILE                       parse and report an ASCII STL\n"
                 "  check-csv FILE                       parse and report a nodal temperature CSV\n"
                 "  sysinfo                              CPU, cores, RAM, compiler\n";
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 2) {
        usage();
        return 1;
    }
    const std::string command = argv[1];
    const Args args = parseFlags(argc, argv, 2);
    try {
        if (command == "fea") return runFea(args);
        if (command == "benchmark") return runBenchmark(args);
        if (command == "backprop") return runBackprop(args);
        if (command == "make-examples") return makeExamples(args);
        if (command == "make-stress") return makeStressFiles(args);
        if (command == "check-stl") return validateFile("stl", args);
        if (command == "check-csv") return validateFile("csv", args);
        if (command == "sysinfo") return printSystemInfo();
        usage();
        return 1;
    } catch (const wb::io::InputError& e) {
        std::cerr << "Input error: " << e.what() << "\n";
        return 2;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 2;
    }
}
